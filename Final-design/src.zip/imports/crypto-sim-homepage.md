Design a **premium fintech homepage** for a crypto trading simulator called **CryptoSim**.

The design style should closely match the visual language of the TradingView Lightweight Charts website:

https://in.tradingview.com/lightweight-charts/

The page should look like a **modern trading platform product page**, not a marketing landing page.

Use the same **dark UI style, typography scale, spacing, layout structure, and chart presentation style** seen on the TradingView page.

The homepage should feel **technical, minimal, and extremely clean**.

---

GLOBAL DESIGN SYSTEM

Theme: Premium dark fintech interface

Background color:
Deep black (#000000) or dark navy (#0B0F19)

Text colors:

Primary text: white
Secondary text: light gray
Accent color: blue / purple glow

Charts:

Use green for bullish candles
Use red for bearish candles

---

TYPOGRAPHY

Use a modern fintech font similar to TradingView.

Preferred fonts:

Inter
or
Satoshi
or
IBM Plex Sans

Typography scale:

Hero heading: extremely large bold text
Section headings: bold large titles
Body text: clean minimal paragraphs

Typography should feel **similar to TradingView's layout hierarchy**.

---

NAVBAR

Minimal dark navbar similar to TradingView.

Left side:

CryptoSim logo

Center:

Search bar (rounded)

Right side navigation:

Products
Community
Markets
Leaderboard
More

Profile avatar

Primary button:

Start Trading

Navbar should remain **sticky** with blur background.

---

HERO SECTION

Large hero section similar to TradingView Lightweight Charts page.

Headline example:

Advanced Trading Charts

Subtext:

A powerful trading simulator with real-time market data and professional charting tools.

Buttons:

GitHub
Documentation

Below hero show a **large trading chart preview** using TradingView Lightweight Charts.

---

MAIN CHART PREVIEW

Display a **large candlestick chart card**.

Use TradingView Lightweight Charts.

Chart should include:

Candlesticks
Grid lines
Price scale
Time scale

Chart UI should match TradingView style:

dark grid
bright candles
subtle glow

---

FEATURE CARDS SECTION

Create feature cards similar to the TradingView layout.

Cards include:

Super compact
Streaming updates
Open source

Each card contains:

Icon
Title
Description
Button

Cards should have:

dark background
soft border
rounded corners

---

CHART FEATURE SHOWCASE

Create multiple sections showing chart capabilities.

Each section contains a **live chart preview**.

---

CHART TYPE

Show chart types:

Candlestick
Line
Bars
Area
Baseline

Include toggle buttons above the chart.

---

DATA TOOLTIP

Show chart with hover tooltip.

Tooltip displays:

Open
High
Low
Close
Volume

Tooltip design should match TradingView style.

---

PRICE SCALE

Display chart with right-side price scale.

Show price markers:

maximum
minimum
average

---

SCALE FORMATTING

Show chart with custom formatting.

Examples:

currency formatting
localized price display

---

REALTIME DATA

Show chart demonstrating streaming updates.

Candles update live.

---

CHART FEATURE GRID

Arrange chart modules in a **2 column grid layout**.

Each card contains:

Chart preview
Feature title
Description
"View feature" button

---

TRUST SECTION

Add a section similar to TradingView partner logos.

Headline:

Trusted by traders worldwide

Display logos such as:

Coinbase
Crypto.com
CoinMarketCap
Investopedia
Binance

---

PERFORMANCE SECTION

Large headline:

Top performance, tiny package.

Description:

Fast, lightweight charts built for modern trading platforms.

Primary button:

Explore Charts

---

VISUAL HERO IMAGE

Include a large illustration showing a trader at multiple screens displaying trading charts.

The illustration should use **dark neon lighting similar to fintech promotional images**.

---

FOOTER

Large fintech footer similar to TradingView.

Columns include:

Product
Markets
Community
Documentation
Company

Include social icons and copyright text.

---

LAYOUT RULES

Section spacing: 120px
Card spacing: 32px
Card border radius: 16px

Use large breathing space between sections.

Charts should always be the **visual focus of the page**.

Avoid generic marketing content.

Focus on **charts and trading functionality**.
