Create a **premium fintech homepage design** for a crypto trading simulator called **CryptoSim**.

Use the **uploaded TradingView screenshots as the design reference** for layout, spacing, and structure.

The design should follow the **same visual hierarchy and layout structure**, but replace branding and content with **CryptoSim**.

This homepage is for a **crypto trading simulator platform with real-time charts**.

The UI should look **professional, technical, minimal, and modern**.

The design should feel like a **trading platform landing page**, not a marketing website.

---

GLOBAL DESIGN STYLE

Theme: Dark fintech interface

Background color:
#0B0F19 or pure black

Card background:
#111827

Borders:
1px subtle gray (#1F2937)

Accent colors:

Green = bullish price
Red = bearish price
Blue = UI highlight

Glow effects should be subtle.

Use soft shadows and rounded cards.

Border radius:
16px

---

TYPOGRAPHY

Use modern fintech typography.

Preferred font:

Inter

Typography scale:

Hero title:
80px bold

Section title:
40–48px bold

Card titles:
22px

Body text:
16px

Use strong hierarchy and large spacing.

---

NAVIGATION BAR

Sticky dark navbar.

Left:

CryptoSim logo

Center:

Search bar

Right navigation:

Markets
Leaderboard
Community
Docs

Primary button:

Start Trading

User avatar on the far right.

---

HERO SECTION

Large hero section.

Title:

Trade Crypto. Practice Risk-Free.

Subtitle:

A professional-grade trading simulator with real-time market data and advanced charting tools.

Buttons:

Start Trading Free
View Demo

Below hero place a **large dark trading chart preview**.

The chart preview should resemble **TradingView charts**.

---

FEATURE CARD SECTION

Three large feature cards similar to the TradingView layout.

Cards:

Real-time streaming data
Professional charting tools
Open-source chart engine

Each card includes:

Icon
Title
Short description
Button

Cards should be large with rounded corners and dark backgrounds.

---

MAIN CHART FEATURE GRID

Create a **2 column grid of chart feature cards**.

Each card contains a **chart preview**.

Chart feature examples:

Chart types
Custom themes
Range selector
Legend styles
Series comparison
Indicators and markers
Tooltip interaction
Scale configuration
Price formatting

Each card layout:

Title
Small controls (tabs or buttons)
Chart preview
"View example" button

Charts must look like **TradingView-style charts**.

---

TRUSTED BY SECTION

Large centered headline.

Title:

Trusted by traders worldwide

Display a grid of fintech logos such as:

Coinbase
CoinMarketCap
Crypto.com
Binance
Investopedia

Logos should appear in muted gray.

---

PERFORMANCE SECTION

Large centered section.

Title:

Fast charts. Built for traders.

Description:

Lightning fast charts powered by a lightweight trading engine.

Button:

Explore charts

---

VISUAL SHOWCASE

Large hero illustration.

Show a **trader using multiple monitors with charts**.

Style:

Dark neon lighting
Futuristic
Fintech workspace

---

INFO CARDS SECTION

Three horizontal info cards.

Cards:

Learn trading strategies
Explore market data
Build your trading skills

Each card includes:

Title
Short description
Link button

---

FOOTER

Large dark footer similar to TradingView.

Columns:

Product
Markets
Community
Company
Resources

Include social icons.

Add disclaimer text:

CryptoSim is a trading simulator using virtual funds. No real money is used.

---

LAYOUT SPACING

Section spacing:

120px

Card gap:

32px

Max container width:

1280px

---

CHART PREVIEWS

All chart previews should look like **TradingView charts**.

Charts should include:

candlesticks
grid lines
price axis
time axis

Use green and red candles.

---

FINAL GOAL

The final homepage should feel like a **professional trading platform product page** similar to TradingView but branded as **CryptoSim**.

Charts should be the **main visual element throughout the page**.
