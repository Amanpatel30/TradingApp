Design a **premium dark fintech landing page** for a crypto trading simulator called **CryptoSim**.

The design inspiration should be similar to:

TradingView
Coinbase Advanced
Stripe documentation UI
Modern trading dashboards

The website should feel **technical, powerful, and product-focused**, not like a generic marketing landing page.

The homepage should visually communicate that this platform is a **real trading environment with live charts and market data**.

---

GLOBAL DESIGN STYLE

Theme: Premium dark trading interface

Background color:
#0B0F19 or similar deep dark navy.

Text color:
White (#FFFFFF)

Accent colors:

Neon green for price gains
Red for losses
Purple / blue gradient highlights

UI Style:

Large bold typography
High contrast
Subtle glow effects
Glassmorphism panels
Soft shadows
Rounded corners (16px)

The layout must feel **clean, structured, and professional like TradingView**.

---

NAVBAR

Sticky top navbar with blur background.

Left:

CryptoSim logo

Center:

Search input similar to TradingView search.

Right:

Markets
Leaderboard
Analytics
Sign In
Get Started button

Navbar should feel minimal and modern.

---

LIVE MARKET TICKER

Below navbar add a **scrolling crypto ticker bar**.

Example pairs:

BTC/USDT
ETH/USDT
SOL/USDT
BNB/USDT
ADA/USDT

Each item shows:

Symbol
Price
24h change

Green for positive change
Red for negative change.

---

HERO SECTION

Large hero section.

Left side:

Headline:

Practice Crypto Trading Without Risk

Description:

Learn trading using real-time market prices, simulated order books, and $100,000 virtual capital.

Buttons:

Start Trading Free
Explore Platform

---

FLOATING TRADING PANELS (RIGHT SIDE)

Create a **floating multi-panel trading interface preview** similar to TradingView.

Panels should overlap slightly and float in 3D space.

Panels include:

Main candlestick chart panel
Order book panel
Market watch list
Indicator panel
Mini price chart panel

Panels should have:

dark UI
glow borders
rounded corners
subtle depth shadows

The main chart should display **candlestick trading data**.

---

CHART FEATURE SHOWCASE

Create a section demonstrating the platform's chart capabilities.

Use **real chart previews**.

Include the following chart modules.

---

CHART TYPE

Show a chart module demonstrating different chart types:

Candlestick
Line
Area
Bars

Allow visual toggle buttons above the chart.

---

DATA TOOLTIP

Show chart with a floating tooltip when hovering over a candle.

Tooltip shows:

Open
High
Low
Close
Volume

Tooltip style should be dark with glowing border.

---

PRICE SCALE

Display a chart with a highlighted price scale on the right side.

Show price markers:

Max price
Average price
Minimum price

---

SCALE FORMATTING

Demonstrate custom price formatting.

Examples:

Currency formatting
Localized price display
Custom number formatting

---

LIVE DATA

Show a chart with **live updating candles**.

Include a small glowing indicator showing:

Live market feed.

---

CHART FEATURE GRID

Display all chart features in a **2 column card grid**.

Each card contains:

Chart preview
Feature name
Short description
Learn more button

Cards should look like **TradingView documentation UI blocks**.

---

MARKET OVERVIEW

Create a market grid showing crypto assets.

Cards show:

Asset symbol
Price
24h change
Sparkline mini chart

Assets:

BTC
ETH
SOL
BNB
ADA
LINK

---

PLATFORM FEATURES

Create four premium feature cards.

Real-Time Price Feed
WebSocket powered market updates.

Advanced Order Book
Realistic bid and ask market depth.

Trading Analytics
Track performance, win rate, drawdown.

Virtual Capital
Start with $100,000 simulation balance.

---

SUPPORTED ASSETS

Create two large cards.

Crypto Markets (Live)

BTC
ETH
SOL
BNB
ADA

Stocks (Coming Soon)

AAPL
TSLA
MSFT
NVDA

---

TRADER LEADERBOARD

Create leaderboard table.

Columns:

Rank
Trader
ROI
Trades

Example:

1  TraderAlpha  +42%  132
2  CryptoWolf  +35%  98
3  AlgoNinja  +28%  76

---

FINAL CALL TO ACTION

Large gradient section.

Headline:

Start practicing trading today.

Buttons:

Create Free Account
Explore Dashboard

---

FOOTER

Minimal fintech footer.

Sections:

Product
Documentation
Community
Legal

Include text:

CryptoSim Trading Simulator
No real money involved.

---

LAYOUT RULES

Section spacing: 120px
Card spacing: 32px
Card radius: 16px
Charts should be the visual focus of the page.

Avoid generic marketing sections.

Focus on showing **actual trading tools and charts**.
