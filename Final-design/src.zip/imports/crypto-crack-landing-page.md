Improve and redesign the CryptoCrack landing page while maintaining the existing design system used across the project (colors, typography, spacing, buttons, and components).

This is a **crypto trading simulator platform** that uses real-time market data and virtual trading capital.

The current landing page is too simple and has too much empty space. Improve the layout to make it feel like a professional trading platform homepage.

Focus on showing **product functionality, charts, market data, and platform previews**, not generic marketing sections.

----------------------------------------------------

GLOBAL DESIGN RULES

• Maintain the same visual style used in the dashboard and login pages
• Reduce unnecessary vertical whitespace
• Use tighter spacing between sections
• Replace generic marketing content with product-focused UI previews
• Use charts, market data, and trading visuals where appropriate
• Keep the layout structured and balanced
• Landing page theme = light
• Trading preview = dark mode

----------------------------------------------------

NAVBAR IMPROVEMENTS

Fix navigation behavior.

• Clicking the CryptoCrack logo must navigate to the Home page.
• Navbar should contain:

Logo (left side)
Live indicator with green dot
Sign In button
Get Started Free button

Make navbar height compact and align items properly.

----------------------------------------------------

LIVE MARKET TICKER BAR

Add a scrolling ticker bar at the top of the page.

Display crypto pairs such as:

BTC/USDT  
ETH/USDT  
SOL/USDT  
BNB/USDT  
ADA/USDT  
LINK/USDT  

Each ticker should show:

Symbol  
Price  
24h % change  

Positive changes should be green.
Negative changes should be red.

----------------------------------------------------

HERO SECTION

Left side:

Headline:
Trade Smarter. Risk-Free.

Description:
Practice crypto trading using real market prices, a realistic order book simulation, and $100,000 in virtual capital.

Buttons:

Start Trading Free  
Sign In  

Below buttons show stats:

Active Traders  
Simulated Volume  
Trading Pairs  

Right side:

Display a **dark-themed trading terminal preview**.

The preview should include:

Candlestick chart (TradingView style)  
Order book panel  
Buy/Sell order form  

The preview must look like a professional trading interface.

----------------------------------------------------

LIVE MARKET OVERVIEW

Add a market section showing crypto pairs in cards.

Each card shows:

Symbol  
Current price  
24h change  
Small sparkline chart  

Display around 6–8 assets.

Examples:

BTC/USDT  
ETH/USDT  
SOL/USDT  
BNB/USDT  

----------------------------------------------------

PLATFORM FEATURES

Create feature cards explaining core functionality.

Real-Time Price Feed  
WebSocket-powered tick-by-tick market updates.

Advanced Order Book  
Realistic bid/ask market depth simulation.

Trading Analytics  
Track equity curve, win rate, and drawdowns.

Virtual Trading Capital  
Practice with $100,000 without financial risk.

Display in a compact 2x2 card layout.

----------------------------------------------------

HOW THE PLATFORM WORKS

Three steps:

1 Create Account  
2 Receive Virtual Capital  
3 Trade Using Live Market Data  

Reduce vertical spacing between the steps.

----------------------------------------------------

PLATFORM PREVIEW

Create UI preview cards showing platform capabilities.

Cards:

Trading Dashboard  
Candlestick chart + order book preview

Portfolio Performance  
Equity curve chart

Analytics Dashboard  
Trading metrics and statistics

Each card should resemble the real platform interface.

----------------------------------------------------

TRADER LEADERBOARD

Add a leaderboard section.

Display top traders this week.

Columns:

Rank  
Username  
ROI  
Total Trades  

Example rows:

1  TraderAlpha   +48%   142 trades  
2  CryptoWolf   +36%   98 trades  
3  AlgoNinja   +28%   75 trades  

Use a modern card-style table.

----------------------------------------------------

SUPPORTED MARKETS

Show two cards:

Crypto (Live)

BTC  
ETH  
SOL  
BNB  
ADA  

Stocks (Coming Soon)

AAPL  
TSLA  
MSFT  
NVDA  

Label the stocks section as “Coming Soon”.

----------------------------------------------------

BENEFITS ROW

Add a compact row with icons.

No Real Money Risk  
Live Market Data  
Advanced Analytics  
Free Simulator

----------------------------------------------------

FINAL CALL TO ACTION

Create a large gradient section.

Headline:

Start practising trading risk-free.

Buttons:

Create Free Account  
Sign In  

----------------------------------------------------

FOOTER

Include:

CryptoCrack Simulator  
Educational trading platform.

Links:

Privacy  
Terms  
Support  
Documentation

----------------------------------------------------

QUALITY REQUIREMENTS

• Reduce unnecessary empty space
• Maintain consistent section width
• Align sections with a grid layout
• Ensure spacing between components is balanced
• Use charts and market visuals where possible
• Ensure the page visually represents a real trading platform