Use the existing CryptoSim design system in this file.

Maintain the same:
- Color palette
- Typography
- Component style
- Card layout
- Gradients
- Spacing
- Button styles
- Sidebar + Topbar layout

Do NOT redesign existing pages like Login, Register, Dashboard, Wallet, Exchange, Settings. Only extend the design system.

This project is a **Crypto Trading Simulator** platform with real-time market data and virtual trading capital. The UI should feel like a professional fintech trading platform similar to Binance, Coinbase Pro, or TradingView but using the current clean CryptoSim theme.

Create the following new pages while maintaining the same visual theme:

---------------------------------------------------

1. Landing / Home Page Improvements

Extend the existing landing page with additional sections:

• Live Market Ticker Bar  
Scrolling top bar showing BTC/USDT, ETH/USDT, SOL/USDT prices and percentage change.

• Feature Section  
Cards explaining:
- Real-time price feed
- Order book simulation
- Trading analytics
- Virtual trading capital

• How It Works Section  
3 steps:
1. Create account
2. Get virtual capital
3. Start trading with live prices

• Platform Preview Section  
Show preview cards of:
- Trading dashboard
- Analytics charts
- Portfolio overview

• Supported Assets Section  
Show:
Crypto (Live)
Stocks (Coming Soon)

• Final CTA Section  
Large gradient banner:
"Start practicing trading risk-free."

---------------------------------------------------

2. Open Orders Page

Create a dedicated page to manage open orders.

Table columns:
- Order ID
- Symbol
- Side (Buy/Sell)
- Order Type
- Quantity
- Price
- Filled %
- Status
- Cancel Button

Include:
- Filter by symbol
- Empty state
- Loading skeleton

---------------------------------------------------

3. Trade History Page

Create a trade history page.

Table with:
- Trade ID
- Symbol
- Side
- Quantity
- Price
- Status
- Time

Add:
- Pagination
- Symbol filter
- Date range filter

---------------------------------------------------

4. Portfolio Detail Page

When clicking an asset like BTC.

Top section:
- Asset name
- Current price
- Quantity owned
- Average buy price
- Unrealized PnL
- PnL percentage

Main section:
- Price chart
- Trading history for this asset

---------------------------------------------------

5. Trading Analytics Page

Create a performance analytics dashboard.

Metrics cards:
- ROI %
- Net Profit/Loss
- Total Trades
- Win Rate
- Max Drawdown

Charts:
- Equity curve
- Monthly performance
- Win/Loss ratio
- Drawdown chart

---------------------------------------------------

6. Admin Panel Page

Create an admin monitoring panel.

Tabs:
Users
Trades
Platform Metrics

Users table:
- User ID
- Username
- Email
- Role
- Account Status
- Freeze button

Trades table:
- Trade ID
- User ID
- Symbol
- Side
- Price
- Quantity
- Status

---------------------------------------------------

7. Global Components

Create reusable components matching the existing theme:

- Order execution success notification
- Error notification
- Loading skeletons
- Empty state cards
- WebSocket connection indicator (green dot when connected)

---------------------------------------------------

Important:

• Keep the existing CryptoSim visual identity.
• Do not introduce NFTs, billing, invoices, or blockchain transfers.
• The wallet represents virtual trading capital only.
• Design should be scalable so stocks can be added later.