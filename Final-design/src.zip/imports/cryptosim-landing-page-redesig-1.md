Fix the current CryptoSim landing page design.

The page currently contains **too many chart demo sections** which make it look like a **chart documentation page instead of a product landing page**.

Simplify the layout into a **clean SaaS trading platform landing page**.

Maintain the **existing theme, colors, typography, spacing, and design system**.

Do NOT redesign the entire page — only remove unnecessary sections and improve UX.

---

### REMOVE THESE SECTIONS COMPLETELY

Delete the following sections because they belong to a **chart documentation page**:

Range switcher
Trade legend
Multi asset
Additional options
Data tooltip
Scales formatting
Price scale
Scales config
Live data
Indicators & markers
Custom chart types
Custom plugins

These sections are unnecessary for a landing page.

---

### KEEP THESE SECTIONS

Keep and improve the following sections:

Navbar
Hero section
Hero trading chart preview
Feature cards
Trusted by traders section
Live markets overview
Leaderboard preview
CTA section
Footer

---

### TARGET PAGE STRUCTURE

The final landing page should have this structure:

Navbar
Hero
Trading chart preview
Key features (3 cards)
Live markets overview
Leaderboard preview
Trusted by traders
Call to action
Footer

Keep the layout **clean and minimal**.

---

### TRUSTED BY SECTION FIX

The company logos section currently has **low opacity text even on hover**.

Fix the interaction behavior.

Default state:

Opacity = 40%
Color = muted gray (#9CA3AF)

Hover state:

Opacity = 100%
Color = pure white (#FFFFFF)

Add a smooth hover transition:

200ms ease

---

### CHART USAGE RULE

Only keep **one main chart preview** in the hero section.

The landing page should not contain multiple demo charts.

Charts are used only as **product preview**, not documentation.

---

### DESIGN RULES

Maintain the current design system:

Dark theme
Black background (#0B0F19)
Card background (#111827)
Rounded corners (16px)
Subtle borders (#1F2937)

Typography:

Font = Inter
Hero title = bold and large
Clean spacing between sections

---

### FINAL GOAL

The page should look like a **professional fintech SaaS landing page** for a crypto trading simulator called **CryptoSim**.

The design must feel:

Clean
Professional
Minimal
Product-focused

Not like a **technical chart demo website**.
