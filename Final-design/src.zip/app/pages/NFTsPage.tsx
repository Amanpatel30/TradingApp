import { useState } from "react";
import { Heart, Eye, Grid3x3, List, X } from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "../components/PageHeader";
import { useDS } from "../context/ThemeContext";

const nftsData = [
  { id: 1, title: "Quantum Drift #042",  collection: "Quantum Series",  price: 2.4, eth: "2.4 ETH",  usd: "$8,452",  liked: false, likes: 128, views: 2341, rarity: "Legendary", tag: "owned",     img: "https://images.unsplash.com/photo-1672239272089-250c32c3e2e2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400" },
  { id: 2, title: "Neon Genesis #117",   collection: "CyberPunk DAO",   price: 1.8, eth: "1.8 ETH",  usd: "$6,339",  liked: true,  likes: 94,  views: 1812, rarity: "Epic",      tag: "watchlist", img: "https://images.unsplash.com/photo-1595529470610-9760d097e73c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400" },
  { id: 3, title: "Cosmos Fragment #08", collection: "Astral Beings",   price: 3.1, eth: "3.1 ETH",  usd: "$10,915", liked: false, likes: 214, views: 4230, rarity: "Legendary", tag: "owned",     img: "https://images.unsplash.com/photo-1762441112136-4dfc6edf58e8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400" },
  { id: 4, title: "Liquid Chrome #55",   collection: "Meta Sculptures", price: 0.9, eth: "0.9 ETH",  usd: "$3,169",  liked: true,  likes: 67,  views: 990,  rarity: "Rare",      tag: "watchlist", img: "https://images.unsplash.com/photo-1759047770373-ac478dcc2d3c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400" },
  { id: 5, title: "Signal Wave #23",     collection: "Crypto Waves",    price: 1.5, eth: "1.5 ETH",  usd: "$5,282",  liked: false, likes: 183, views: 3120, rarity: "Epic",      tag: "owned",     img: "https://images.unsplash.com/photo-1764258559704-0b7f0f02cae0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400" },
  { id: 6, title: "Pixel Storm #99",     collection: "Quantum Series",  price: 0.6, eth: "0.6 ETH",  usd: "$2,113",  liked: false, likes: 45,  views: 742,  rarity: "Common",    tag: "watchlist", img: "https://images.unsplash.com/photo-1667984510054-d4562f93621d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400" },
];

const rarityColors: Record<string, { light: {bg:string;text:string}; dark: {bg:string;text:string} }> = {
  Legendary: { light: { bg: "#fef9c3", text: "#ca8a04" }, dark: { bg: "rgba(234,179,8,0.2)",    text: "#fbbf24" } },
  Epic:      { light: { bg: "#ede9fe", text: "#7c3aed" }, dark: { bg: "rgba(139,92,246,0.2)",   text: "#a78bfa" } },
  Rare:      { light: { bg: "#dbeafe", text: "#2563eb" }, dark: { bg: "rgba(59,130,246,0.2)",   text: "#60a5fa" } },
  Common:    { light: { bg: "#f3f4f6", text: "#6b7280" }, dark: { bg: "rgba(107,114,128,0.2)",  text: "#9ca3af" } },
};

const TABS = ["All", "Owned", "Watchlist"] as const;
type Tab = typeof TABS[number];
type SortKey = "recently" | "price_asc" | "price_desc" | "most_liked";

export function NFTsPage() {
  const ds = useDS();
  const [tab, setTab]       = useState<Tab>("All");
  const [liked, setLiked]   = useState<Record<number, boolean>>(Object.fromEntries(nftsData.map((n) => [n.id, n.liked])));
  const [view, setView]     = useState<"grid" | "list">("grid");
  const [sortBy, setSortBy] = useState<SortKey>("recently");
  const [offerNft, setOfferNft] = useState<typeof nftsData[0] | null>(null);
  const [offerAmt, setOfferAmt] = useState("");

  const filtered = nftsData
    .filter((n) => tab === "All" ? true : tab === "Owned" ? n.tag === "owned" : n.tag === "watchlist")
    .sort((a, b) => sortBy === "price_asc" ? a.price - b.price : sortBy === "price_desc" ? b.price - a.price : sortBy === "most_liked" ? b.likes - a.likes : a.id - b.id);

  const getRarityStyle = (rarity: string) => {
    const r = rarityColors[rarity] || rarityColors.Common;
    return ds.isDark ? r.dark : r.light;
  };

  const handleOffer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!offerAmt || parseFloat(offerAmt) <= 0) { toast.error("Enter a valid offer amount"); return; }
    toast.success(`Offer of ${offerAmt} ETH submitted for "${offerNft?.title}"`);
    setOfferNft(null); setOfferAmt("");
  };

  return (
    <>
      <PageHeader title="NFTs" />
      <main className="flex-1 px-6 pb-8 overflow-auto">

        {/* Stats */}
        <div className="grid grid-cols-4 gap-4 mb-5">
          {[
            { label: "Portfolio Value", value: "$28,270" },
            { label: "Items Owned",     value: "3"        },
            { label: "Floor Price",     value: "0.6 ETH"  },
            { label: "Total Volume",    value: "12.4 ETH" },
          ].map(({ label, value }) => (
            <div key={label} className="rounded-2xl px-5 py-4 transition-colors duration-300"
              style={{ background: ds.card, boxShadow: ds.cardShadow }}>
              <p className="text-xs mb-1" style={{ color: ds.textMuted }}>{label}</p>
              <p className="text-xl font-semibold" style={{ color: ds.textPrimary }}>{value}</p>
            </div>
          ))}
        </div>

        {/* Toolbar */}
        <div className="rounded-2xl px-5 py-3 mb-5 flex items-center justify-between transition-colors duration-300"
          style={{ background: ds.card, boxShadow: ds.cardShadow }}>
          <div className="flex gap-1">
            {TABS.map((t) => (
              <button key={t} onClick={() => setTab(t)}
                className="px-4 py-1.5 rounded-xl text-sm transition-all"
                style={tab === t
                  ? { background: "linear-gradient(90deg,#22c55e,#06b6d4)", color: "white" }
                  : { color: ds.textMuted }}>
                {t}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-3">
            <select value={sortBy} onChange={(e) => setSortBy(e.target.value as SortKey)}
              className="text-xs rounded-xl px-3 py-2 outline-none cursor-pointer"
              style={{ background: ds.subBg, border: `1px solid ${ds.border}`, color: ds.textSecondary }}>
              <option value="recently">Recently added</option>
              <option value="price_asc">Price: Low to High</option>
              <option value="price_desc">Price: High to Low</option>
              <option value="most_liked">Most liked</option>
            </select>
            <div className="flex gap-1 rounded-xl p-1" style={{ background: ds.subBg }}>
              {([["grid", Grid3x3], ["list", List]] as const).map(([v, Icon]) => (
                <button key={v} onClick={() => setView(v as "grid" | "list")}
                  className="p-1.5 rounded-lg transition-all"
                  style={view === v ? { background: ds.card, boxShadow: "0 1px 4px rgba(0,0,0,0.1)" } : {}}>
                  <Icon size={15} style={{ color: view === v ? "#06b6d4" : ds.textMuted }}/>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Grid */}
        <div className={`grid gap-4 ${view === "grid" ? "grid-cols-3" : "grid-cols-1"}`}>
          {filtered.map((nft) => (
            <div key={nft.id}
              className={`rounded-2xl overflow-hidden hover:shadow-lg transition-all duration-300 ${view === "list" ? "flex items-center" : ""}`}
              style={{ background: ds.card, boxShadow: ds.cardShadow }}>
              <div className={`relative overflow-hidden shrink-0 ${view === "grid" ? "h-48 w-full" : "h-20 w-20 m-3 rounded-xl"}`}>
                <img src={nft.img} alt={nft.title} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"/>
                <span className="absolute top-2 left-2 text-xs font-medium px-2 py-0.5 rounded-full" style={getRarityStyle(nft.rarity)}>
                  {nft.rarity}
                </span>
                <button onClick={() => setLiked((p) => ({ ...p, [nft.id]: !p[nft.id] }))}
                  className="absolute top-2 right-2 w-7 h-7 rounded-full flex items-center justify-center transition-all hover:scale-110"
                  style={{ background: ds.isDark ? "rgba(17,17,39,0.8)" : "rgba(255,255,255,0.8)", backdropFilter: "blur(4px)" }}>
                  <Heart size={13} fill={liked[nft.id] ? "#ef4444" : "none"} style={{ color: liked[nft.id] ? "#ef4444" : ds.textMuted }}/>
                </button>
              </div>

              <div className={`${view === "grid" ? "p-4" : "flex flex-1 items-center justify-between px-4"}`}>
                {view === "grid" ? (
                  <>
                    <p className="text-xs mb-0.5" style={{ color: ds.textMuted }}>{nft.collection}</p>
                    <p className="text-sm font-semibold mb-3" style={{ color: ds.textPrimary }}>{nft.title}</p>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-xs" style={{ color: ds.textMuted }}>Current price</p>
                        <div className="flex items-center gap-1.5">
                          <span className="text-sm font-semibold" style={{ color: ds.textPrimary }}>{nft.eth}</span>
                          <span className="text-xs" style={{ color: ds.textMuted }}>{nft.usd}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 text-xs" style={{ color: ds.textMuted }}>
                        <span className="flex items-center gap-1"><Heart size={11}/>{nft.likes}</span>
                        <span className="flex items-center gap-1"><Eye size={11}/>{nft.views}</span>
                      </div>
                    </div>
                    <button onClick={() => nft.tag === "owned" ? toast.success(`"${nft.title}" listed for sale!`) : setOfferNft(nft)}
                      className="w-full mt-3 py-2 rounded-xl text-sm font-medium text-white hover:opacity-90 transition-all"
                      style={{ background: "linear-gradient(90deg,#22c55e,#06b6d4)" }}>
                      {nft.tag === "owned" ? "List for Sale" : "Make Offer"}
                    </button>
                  </>
                ) : (
                  <>
                    <div>
                      <p className="text-xs" style={{ color: ds.textMuted }}>{nft.collection}</p>
                      <p className="text-sm font-semibold" style={{ color: ds.textPrimary }}>{nft.title}</p>
                    </div>
                    <div className="flex items-center gap-8">
                      <div className="text-right">
                        <p className="text-xs" style={{ color: ds.textMuted }}>Price</p>
                        <p className="text-sm font-semibold" style={{ color: ds.textPrimary }}>{nft.eth}</p>
                      </div>
                      <div className="flex items-center gap-3 text-xs" style={{ color: ds.textMuted }}>
                        <span className="flex items-center gap-1"><Heart size={11}/>{nft.likes}</span>
                        <span className="flex items-center gap-1"><Eye size={11}/>{nft.views}</span>
                      </div>
                      <button onClick={() => nft.tag === "owned" ? toast.success(`"${nft.title}" listed!`) : setOfferNft(nft)}
                        className="px-4 py-2 rounded-xl text-xs font-medium text-white"
                        style={{ background: "linear-gradient(90deg,#22c55e,#06b6d4)" }}>
                        {nft.tag === "owned" ? "List" : "Offer"}
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      </main>

      {/* Offer Modal */}
      {offerNft && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setOfferNft(null)}/>
          <div className="relative rounded-2xl w-full max-w-sm mx-4 p-6" style={{ background: ds.card, border: `1px solid ${ds.border}`, boxShadow: "0 20px 60px rgba(0,0,0,0.3)" }}>
            <div className="flex items-center justify-between mb-4">
              <p className="text-base font-semibold" style={{ color: ds.textPrimary }}>Make an Offer</p>
              <button onClick={() => setOfferNft(null)} style={{ color: ds.textMuted }}><X size={18}/></button>
            </div>
            <div className="flex items-center gap-3 mb-4 p-3 rounded-xl" style={{ background: ds.subBg }}>
              <img src={offerNft.img} alt={offerNft.title} className="w-12 h-12 rounded-lg object-cover"/>
              <div>
                <p className="text-sm font-semibold" style={{ color: ds.textPrimary }}>{offerNft.title}</p>
                <p className="text-xs" style={{ color: ds.textMuted }}>{offerNft.collection} · Floor: {offerNft.eth}</p>
              </div>
            </div>
            <form onSubmit={handleOffer} className="flex flex-col gap-3">
              <div>
                <label className="text-xs font-medium mb-1 block" style={{ color: ds.textMuted }}>Your Offer (ETH)</label>
                <div className="flex items-center gap-2 rounded-xl px-4 py-2.5" style={{ background: ds.inputBg, border: `1px solid ${ds.inputBorder}` }}>
                  <input type="number" step="0.01" min="0" value={offerAmt} onChange={(e) => setOfferAmt(e.target.value)}
                    placeholder="0.00" className="flex-1 bg-transparent outline-none text-sm" style={{ color: ds.textPrimary }}/>
                  <span className="text-xs font-medium px-2 py-0.5 rounded-md" style={{ background: ds.subBg2, color: ds.textMuted }}>ETH</span>
                </div>
              </div>
              <div className="flex gap-3">
                <button type="button" onClick={() => setOfferNft(null)}
                  className="flex-1 py-2.5 rounded-xl text-sm font-medium transition-colors"
                  style={{ background: ds.subBg, color: ds.textSecondary }}>Cancel</button>
                <button type="submit" className="flex-1 py-2.5 rounded-xl text-sm font-medium text-white"
                  style={{ background: "linear-gradient(90deg,#22c55e,#06b6d4)" }}>Submit Offer</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
