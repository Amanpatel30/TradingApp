import { useState } from "react";
import { ShieldAlert, Users, ArrowLeftRight, BarChart2, Search, RefreshCw, TrendingUp, TrendingDown, Lock, Unlock } from "lucide-react";
import { toast } from "sonner";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer,
} from "recharts";
import { PageHeader } from "../components/PageHeader";
import { WSIndicator } from "../components/WSIndicator";
import { TableSkeleton } from "../components/Skeleton";
import { useDS } from "../context/ThemeContext";

type Role   = "Admin" | "Trader" | "Viewer";
type UStatus = "Active" | "Suspended" | "Pending";
interface User { id:string; name:string; email:string; role:Role; status:UStatus; trades:number; pnl:number; joined:string; }

type TSide   = "Buy"|"Sell";
type TStatus2 = "Filled"|"Partial"|"Cancelled";
interface AdminTrade { id:string; userId:string; symbol:string; side:TSide; price:number; qty:number; status:TStatus2; date:string; }

const USERS: User[] = [
  { id:"U-001", name:"Eden Ellis",     email:"eden@cc.io",    role:"Admin",  status:"Active",    trades:342, pnl:48250,  joined:"Jan 10, 2026" },
  { id:"U-002", name:"Alex Morgan",    email:"alex@cc.io",    role:"Trader", status:"Active",    trades:218, pnl:12840,  joined:"Jan 22, 2026" },
  { id:"U-003", name:"Priya Sharma",   email:"priya@cc.io",   role:"Trader", status:"Active",    trades:174, pnl:-3420,  joined:"Feb 05, 2026" },
  { id:"U-004", name:"Carlos Reyes",   email:"carlos@cc.io",  role:"Trader", status:"Suspended", trades:89,  pnl:2100,   joined:"Feb 14, 2026" },
  { id:"U-005", name:"Zoe Williams",   email:"zoe@cc.io",     role:"Viewer", status:"Active",    trades:0,   pnl:0,      joined:"Feb 20, 2026" },
  { id:"U-006", name:"Liam Chen",      email:"liam@cc.io",    role:"Trader", status:"Pending",   trades:12,  pnl:540,    joined:"Mar 01, 2026" },
  { id:"U-007", name:"Sofia Rossi",    email:"sofia@cc.io",   role:"Trader", status:"Active",    trades:198, pnl:22100,  joined:"Jan 30, 2026" },
];

const TRADES: AdminTrade[] = [
  { id:"T-9901", userId:"U-001", symbol:"BTC/USDT",  side:"Buy",  price:66900,  qty:0.25,  status:"Filled",    date:"Mar 03, 12:22" },
  { id:"T-9900", userId:"U-002", symbol:"ETH/USDT",  side:"Sell", price:3600,   qty:2.50,  status:"Partial",   date:"Mar 03, 11:58" },
  { id:"T-9899", userId:"U-007", symbol:"SOL/USDT",  side:"Buy",  price:172,    qty:15.00, status:"Filled",    date:"Mar 03, 11:40" },
  { id:"T-9898", userId:"U-003", symbol:"BNB/USDT",  side:"Sell", price:590,    qty:3.00,  status:"Cancelled", date:"Mar 03, 11:10" },
  { id:"T-9897", userId:"U-002", symbol:"LINK/USDT", side:"Buy",  price:15.20,  qty:100,   status:"Filled",    date:"Mar 02, 16:55" },
  { id:"T-9896", userId:"U-001", symbol:"BTC/USDT",  side:"Sell", price:68200,  qty:0.10,  status:"Filled",    date:"Mar 02, 14:30" },
  { id:"T-9895", userId:"U-007", symbol:"AVAX/USDT", side:"Buy",  price:37.50,  qty:8.00,  status:"Filled",    date:"Mar 02, 12:08" },
];

const volumeData = [
  {d:"Mon",v:42},{d:"Tue",v:58},{d:"Wed",v:35},{d:"Thu",v:71},{d:"Fri",v:90},{d:"Sat",v:62},{d:"Sun",v:48},
].map((x) => ({...x, v: x.v * 10000}));

const signupData = [
  {d:"Jan",v:120},{d:"Feb",v:185},{d:"Mar",v:142},{d:"Apr",v:210},{d:"May",v:176},{d:"Jun",v:298},
];

const TABS = [
  { id:"users",   label:"Users",            icon:Users      },
  { id:"trades",  label:"Trades",           icon:ArrowLeftRight },
  { id:"metrics", label:"Platform Metrics", icon:BarChart2  },
] as const;
type TabId = typeof TABS[number]["id"];

export function AdminPage() {
  const ds = useDS();
  const [tab,      setTab]       = useState<TabId>("users");
  const [users,    setUsers]     = useState<User[]>(USERS);
  const [search,   setSearch]    = useState("");
  const [loading,  setLoading]   = useState(false);

  const filteredUsers = users.filter((u) =>
    u.name.toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase()) ||
    u.id.toLowerCase().includes(search.toLowerCase())
  );

  const filteredTrades = TRADES.filter((t) =>
    t.id.toLowerCase().includes(search.toLowerCase()) ||
    t.userId.toLowerCase().includes(search.toLowerCase()) ||
    t.symbol.toLowerCase().includes(search.toLowerCase())
  );

  const toggleFreeze = (id: string) => {
    setUsers((p) => p.map((u) => u.id === id
      ? { ...u, status: u.status === "Suspended" ? "Active" : "Suspended" }
      : u));
    const user = users.find((u) => u.id === id);
    toast.success(`User ${user?.name} ${user?.status === "Suspended" ? "un-frozen" : "suspended"}`);
  };

  const refresh = () => {
    setLoading(true);
    setTimeout(() => setLoading(false), 1200);
    toast.info("Data refreshed");
  };

  const statusStyle = (s: UStatus) => {
    if (s === "Active")    return { bg: ds.isDark ? "rgba(34,197,94,0.15)"  : "#dcfce7", text: "#16a34a" };
    if (s === "Suspended") return { bg: ds.isDark ? "rgba(239,68,68,0.15)"  : "#fee2e2", text: "#dc2626" };
    return                        { bg: ds.isDark ? "rgba(234,179,8,0.15)"  : "#fef9c3", text: "#ca8a04" };
  };

  const totalUsers   = users.length;
  const activeUsers  = users.filter((u) => u.status === "Active").length;
  const totalTrades  = TRADES.length;
  const totalVolume  = TRADES.reduce((s, t) => s + t.price * t.qty, 0);

  return (
    <>
      <PageHeader title="Admin Panel" />
      <main className="flex-1 px-6 pb-8 overflow-auto page-enter">

        {/* Admin badge */}
        <div className="flex items-center gap-2 mb-5">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full"
            style={{ background: ds.isDark ? "rgba(239,68,68,0.12)" : "#fee2e2" }}>
            <ShieldAlert size={13} style={{ color: "#ef4444" }}/>
            <span className="text-xs font-semibold" style={{ color: "#ef4444" }}>Admin Access</span>
          </div>
          <WSIndicator />
        </div>

        {/* Platform summary strip */}
        <div className="grid grid-cols-4 gap-4 mb-5">
          {[
            { label:"Total Users",    value:totalUsers,                            icon:Users,          color:"#06b6d4" },
            { label:"Active Users",   value:activeUsers,                           icon:Users,          color:"#22c55e" },
            { label:"Total Trades",   value:totalTrades,                           icon:ArrowLeftRight, color:"#8b5cf6" },
            { label:"Simulated Vol",  value:`$${(totalVolume/1000).toFixed(0)}k`, icon:BarChart2,      color:"#f59e0b" },
          ].map(({ label, value, icon:Icon, color }) => (
            <div key={label} className="rounded-2xl px-5 py-4 transition-colors duration-300"
              style={{ background: ds.card, boxShadow: ds.cardShadow }}>
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs" style={{ color: ds.textMuted }}>{label}</p>
                <Icon size={14} style={{ color }}/>
              </div>
              <p className="text-2xl font-semibold" style={{ color }}>{value}</p>
            </div>
          ))}
        </div>

        {/* Tab nav */}
        <div className="rounded-2xl overflow-hidden transition-colors duration-300"
          style={{ background: ds.card, boxShadow: ds.cardShadow }}>

          <div className="flex items-center justify-between px-5 py-3"
            style={{ borderBottom: `1px solid ${ds.divider}` }}>
            <div className="flex gap-1">
              {TABS.map(({ id, label, icon:Icon }) => (
                <button key={id} onClick={() => setTab(id)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm transition-all"
                  style={tab === id
                    ? { background: "linear-gradient(90deg,#22c55e,#06b6d4)", color: "white" }
                    : { color: ds.textMuted }}>
                  <Icon size={14}/>{label}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-2 rounded-xl px-3 py-1.5"
                style={{ background: ds.subBg, border: `1px solid ${ds.border}` }}>
                <Search size={13} style={{ color: ds.textMuted }}/>
                <input value={search} onChange={(e) => setSearch(e.target.value)}
                  placeholder={tab === "trades" ? "Search trades…" : "Search users…"}
                  className="bg-transparent outline-none text-xs w-32" style={{ color: ds.textSecondary }}/>
              </div>
              <button onClick={refresh}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs"
                style={{ background: ds.subBg, color: ds.textSecondary }}>
                <RefreshCw size={12} className={loading ? "animate-spin" : ""}/> Refresh
              </button>
            </div>
          </div>

          {/* ── USERS TABLE ── */}
          {tab === "users" && (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr style={{ background: ds.subBg }}>
                    {["User ID","Name","Email","Role","Trades","P&L","Status","Joined","Action"].map((h) => (
                      <th key={h} className="text-left text-xs font-medium px-5 py-3 whitespace-nowrap" style={{ color: ds.textMuted }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {loading ? <TableSkeleton rows={5} cols={9}/> :
                    filteredUsers.map((u) => (
                      <tr key={u.id} className="transition-colors"
                        style={{ borderTop: `1px solid ${ds.divider}` }}
                        onMouseEnter={(e) => (e.currentTarget.style.background = ds.hoverBg)}
                        onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}>
                        <td className="px-5 py-3.5 text-xs font-mono" style={{ color: ds.textMuted }}>{u.id}</td>
                        <td className="px-5 py-3.5">
                          <div className="flex items-center gap-2.5">
                            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-pink-300 to-purple-400 flex items-center justify-center text-white text-xs font-bold shrink-0">
                              {u.name.charAt(0)}
                            </div>
                            <span className="text-sm font-medium" style={{ color: ds.textPrimary }}>{u.name}</span>
                          </div>
                        </td>
                        <td className="px-5 py-3.5 text-xs" style={{ color: ds.textSecondary }}>{u.email}</td>
                        <td className="px-5 py-3.5">
                          <span className="text-xs px-2 py-0.5 rounded-full"
                            style={u.role === "Admin"
                              ? { background: ds.isDark ? "rgba(139,92,246,0.15)" : "#ede9fe", color: "#7c3aed" }
                              : u.role === "Trader"
                              ? { background: ds.isDark ? "rgba(6,182,212,0.15)"  : "#ecfeff", color: "#0891b2" }
                              : { background: ds.subBg, color: ds.textMuted }}>
                            {u.role}
                          </span>
                        </td>
                        <td className="px-5 py-3.5 text-xs" style={{ color: ds.textSecondary }}>{u.trades}</td>
                        <td className="px-5 py-3.5">
                          <span className="text-xs font-semibold" style={{ color: u.pnl >= 0 ? "#22c55e" : "#ef4444" }}>
                            {u.pnl >= 0 ? "+" : ""}${u.pnl.toLocaleString()}
                          </span>
                        </td>
                        <td className="px-5 py-3.5">
                          <span className="text-xs font-medium px-2.5 py-1 rounded-full"
                            style={{ background: statusStyle(u.status).bg, color: statusStyle(u.status).text }}>
                            {u.status}
                          </span>
                        </td>
                        <td className="px-5 py-3.5 text-xs" style={{ color: ds.textMuted }}>{u.joined}</td>
                        <td className="px-5 py-3.5">
                          {u.role !== "Admin" ? (
                            <button onClick={() => toggleFreeze(u.id)}
                              className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium transition-all"
                              style={u.status === "Suspended"
                                ? { background: ds.isDark ? "rgba(34,197,94,0.15)"  : "#dcfce7", color: "#16a34a" }
                                : { background: ds.isDark ? "rgba(239,68,68,0.12)"  : "#fee2e2", color: "#ef4444" }}>
                              {u.status === "Suspended" ? <><Unlock size={11}/> Unfreeze</> : <><Lock size={11}/> Freeze</>}
                            </button>
                          ) : (
                            <span className="text-xs" style={{ color: ds.textMuted }}>—</span>
                          )}
                        </td>
                      </tr>
                    ))
                  }
                </tbody>
              </table>
            </div>
          )}

          {/* ── TRADES TABLE ── */}
          {tab === "trades" && (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr style={{ background: ds.subBg }}>
                    {["Trade ID","User ID","Symbol","Side","Price","Quantity","Total","Status","Date"].map((h) => (
                      <th key={h} className="text-left text-xs font-medium px-5 py-3 whitespace-nowrap" style={{ color: ds.textMuted }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {loading ? <TableSkeleton rows={5} cols={9}/> :
                    filteredTrades.map((t) => (
                      <tr key={t.id} className="transition-colors"
                        style={{ borderTop: `1px solid ${ds.divider}` }}
                        onMouseEnter={(e) => (e.currentTarget.style.background = ds.hoverBg)}
                        onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}>
                        <td className="px-5 py-3.5 text-xs font-mono" style={{ color: ds.textMuted }}>{t.id}</td>
                        <td className="px-5 py-3.5 text-xs font-mono" style={{ color: ds.textMuted }}>{t.userId}</td>
                        <td className="px-5 py-3.5 text-sm font-semibold" style={{ color: ds.textPrimary }}>{t.symbol}</td>
                        <td className="px-5 py-3.5">
                          <span className="flex items-center gap-1 text-xs font-semibold"
                            style={{ color: t.side === "Buy" ? "#16a34a" : "#dc2626" }}>
                            {t.side === "Buy" ? <TrendingUp size={11}/> : <TrendingDown size={11}/>}{t.side}
                          </span>
                        </td>
                        <td className="px-5 py-3.5 text-xs font-medium" style={{ color: ds.textPrimary }}>${t.price.toLocaleString()}</td>
                        <td className="px-5 py-3.5 text-xs" style={{ color: ds.textSecondary }}>{t.qty}</td>
                        <td className="px-5 py-3.5 text-xs" style={{ color: ds.textSecondary }}>${(t.price * t.qty).toLocaleString("en-US",{maximumFractionDigits:0})}</td>
                        <td className="px-5 py-3.5">
                          <span className="text-xs px-2.5 py-1 rounded-full"
                            style={t.status === "Filled"    ? { background: ds.isDark ? "rgba(34,197,94,0.15)"  : "#dcfce7", color: "#16a34a" }
                                 : t.status === "Partial"   ? { background: ds.isDark ? "rgba(234,179,8,0.15)"  : "#fef9c3", color: "#ca8a04" }
                                 :                            { background: ds.subBg, color: ds.textMuted }}>
                            {t.status}
                          </span>
                        </td>
                        <td className="px-5 py-3.5 text-xs" style={{ color: ds.textMuted }}>{t.date}</td>
                      </tr>
                    ))
                  }
                </tbody>
              </table>
            </div>
          )}

          {/* ── PLATFORM METRICS ── */}
          {tab === "metrics" && (
            <div className="p-5 grid grid-cols-2 gap-5">
              <div className="rounded-2xl p-5" style={{ border: `1px solid ${ds.border}` }}>
                <p className="text-sm font-semibold mb-1" style={{ color: ds.textPrimary }}>Daily Trading Volume</p>
                <p className="text-xs mb-4" style={{ color: ds.textMuted }}>Simulated USDT volume last 7 days</p>
                <ResponsiveContainer width="100%" height={160}>
                  <BarChart data={volumeData}>
                    <defs>
                      <linearGradient id="adminBarGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop stopColor="#22c55e"/><stop offset="1" stopColor="#06b6d4"/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke={ds.isDark ? "rgba(255,255,255,0.05)" : "#f0f0f5"} vertical={false}/>
                    <XAxis dataKey="d" tick={{ fontSize: 10, fill: ds.textMuted }} axisLine={false} tickLine={false}/>
                    <YAxis tick={{ fontSize: 10, fill: ds.textMuted }} axisLine={false} tickLine={false}
                      tickFormatter={(v) => `$${(v/1000).toFixed(0)}k`}/>
                    <Tooltip
                      contentStyle={{ borderRadius: 10, border: "none", fontSize: 12, background: ds.card, boxShadow: "0 4px 20px rgba(0,0,0,0.16)", color: ds.textPrimary }}
                      formatter={(v: number) => [`$${v.toLocaleString()}`, "Volume"]}
                    />
                    <Bar dataKey="v" radius={[4,4,0,0]} fill="url(#adminBarGrad)"/>
                  </BarChart>
                </ResponsiveContainer>
              </div>

              <div className="rounded-2xl p-5" style={{ border: `1px solid ${ds.border}` }}>
                <p className="text-sm font-semibold mb-1" style={{ color: ds.textPrimary }}>User Signups</p>
                <p className="text-xs mb-4" style={{ color: ds.textMuted }}>New registrations per month</p>
                <ResponsiveContainer width="100%" height={160}>
                  <AreaChart data={signupData}>
                    <defs>
                      <linearGradient id="signupFill" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#8b5cf6" stopOpacity={ds.isDark ? 0.3 : 0.2}/>
                        <stop offset="100%" stopColor="#8b5cf6" stopOpacity={0.01}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke={ds.isDark ? "rgba(255,255,255,0.05)" : "#f0f0f5"} vertical={false}/>
                    <XAxis dataKey="d" tick={{ fontSize: 10, fill: ds.textMuted }} axisLine={false} tickLine={false}/>
                    <YAxis tick={{ fontSize: 10, fill: ds.textMuted }} axisLine={false} tickLine={false}/>
                    <Tooltip
                      contentStyle={{ borderRadius: 10, border: "none", fontSize: 12, background: ds.card, boxShadow: "0 4px 20px rgba(0,0,0,0.16)", color: ds.textPrimary }}
                      formatter={(v: number) => [v, "Signups"]}
                    />
                    <Area type="monotone" dataKey="v" stroke="#8b5cf6" strokeWidth={2} fill="url(#signupFill)" dot={false}/>
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              {/* Platform stats */}
              {[
                [{ label:"Avg Trades / User", value:"48.9" },{ label:"Avg Portfolio Size", value:"$112,400" }],
                [{ label:"Peak Concurrent Users", value:"842" },{ label:"Uptime (30d)", value:"99.98%" }],
              ].map((row, ri) => (
                <div key={ri} className="grid grid-cols-2 gap-4">
                  {row.map(({ label, value }) => (
                    <div key={label} className="rounded-xl p-4" style={{ background: ds.subBg }}>
                      <p className="text-xs mb-1" style={{ color: ds.textMuted }}>{label}</p>
                      <p className="text-xl font-semibold" style={{ color: ds.textPrimary }}>{value}</p>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </>
  );
}