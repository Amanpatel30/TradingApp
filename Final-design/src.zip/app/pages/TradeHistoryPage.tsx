import { useState, useMemo } from "react";
import { Download, Filter, History } from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "../components/PageHeader";
import { EmptyState } from "../components/EmptyState";
import { TableSkeleton } from "../components/Skeleton";
import { useDS } from "../context/ThemeContext";

type Side   = "Buy" | "Sell";
type Status = "Filled" | "Partial" | "Cancelled";

interface Trade {
  id: string; symbol: string; side: Side; qty: number; price: number;
  fee: number; pnl: number; status: Status; date: string; time: string;
}

const ALL_TRADES: Trade[] = [
  { id:"TH-0142", symbol:"BTC/USDT",  side:"Buy",  qty:0.50,   price:62000, fee:31.00,  pnl:0,       status:"Filled",    date:"2026-03-01", time:"09:14:22" },
  { id:"TH-0141", symbol:"ETH/USDT",  side:"Sell", qty:3.00,   price:3450,  fee:10.35,  pnl:+612,    status:"Filled",    date:"2026-03-01", time:"08:55:10" },
  { id:"TH-0140", symbol:"SOL/USDT",  side:"Buy",  qty:20.00,  price:165,   fee:3.30,   pnl:0,       status:"Filled",    date:"2026-02-28", time:"08:22:44" },
  { id:"TH-0139", symbol:"BNB/USDT",  side:"Sell", qty:5.00,   price:582,   fee:2.91,   pnl:-43,     status:"Filled",    date:"2026-02-27", time:"16:41:08" },
  { id:"TH-0138", symbol:"LINK/USDT", side:"Buy",  qty:80.00,  price:14.20, fee:1.14,   pnl:0,       status:"Filled",    date:"2026-02-27", time:"15:30:01" },
  { id:"TH-0137", symbol:"AVAX/USDT", side:"Buy",  qty:10.00,  price:36.50, fee:0.37,   pnl:0,       status:"Cancelled", date:"2026-02-26", time:"14:20:55" },
  { id:"TH-0136", symbol:"BTC/USDT",  side:"Sell", qty:0.25,   price:68200, fee:17.05,  pnl:+3050,   status:"Filled",    date:"2026-02-25", time:"11:08:32" },
  { id:"TH-0135", symbol:"ETH/USDT",  side:"Buy",  qty:2.00,   price:3200,  fee:6.40,   pnl:0,       status:"Filled",    date:"2026-02-24", time:"10:47:19" },
  { id:"TH-0134", symbol:"SOL/USDT",  side:"Sell", qty:15.00,  price:182,   fee:2.73,   pnl:+255,    status:"Filled",    date:"2026-02-24", time:"09:34:06" },
  { id:"TH-0133", symbol:"DOT/USDT",  side:"Buy",  qty:100.00, price:7.40,  fee:0.74,   pnl:0,       status:"Partial",   date:"2026-02-23", time:"08:59:48" },
  { id:"TH-0132", symbol:"BNB/USDT",  side:"Buy",  qty:4.00,   price:575,   fee:2.30,   pnl:0,       status:"Filled",    date:"2026-02-22", time:"16:22:37" },
  { id:"TH-0131", symbol:"LINK/USDT", side:"Sell", qty:50.00,  price:15.50, fee:0.78,   pnl:+65,     status:"Filled",    date:"2026-02-21", time:"14:11:29" },
];

const SYMBOLS = ["All","BTC/USDT","ETH/USDT","SOL/USDT","BNB/USDT","LINK/USDT","AVAX/USDT","DOT/USDT"];
const STATUS_FILTERS = ["All","Filled","Partial","Cancelled"] as const;
const PAGE_SIZE = 7;

export function TradeHistoryPage() {
  const ds = useDS();
  const [symbol,    setSymbol]    = useState("All");
  const [status,    setStatus]    = useState<"All"|Status>("All");
  const [dateFrom,  setDateFrom]  = useState("");
  const [dateTo,    setDateTo]    = useState("");
  const [page,      setPage]      = useState(1);
  const [loading]                 = useState(false);

  const filtered = useMemo(() => {
    return ALL_TRADES.filter((t) => {
      if (symbol !== "All" && t.symbol !== symbol) return false;
      if (status !== "All" && t.status !== status) return false;
      if (dateFrom && t.date < dateFrom) return false;
      if (dateTo   && t.date > dateTo)   return false;
      return true;
    });
  }, [symbol, status, dateFrom, dateTo]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paginated  = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const totalPnl   = filtered.filter((t) => t.status === "Filled").reduce((s, t) => s + t.pnl, 0);
  const totalFees  = filtered.filter((t) => t.status === "Filled").reduce((s, t) => s + t.fee, 0);
  const wins       = filtered.filter((t) => t.status === "Filled" && t.pnl > 0).length;
  const filled     = filtered.filter((t) => t.status === "Filled").length;

  const inputStyle = { background: ds.inputBg, border: `1px solid ${ds.inputBorder}`, borderRadius: "10px", padding: "6px 12px", fontSize: "12px", color: ds.textSecondary, outline: "none" };

  return (
    <>
      <PageHeader title="Trade History" />
      <main className="flex-1 px-6 pb-8 overflow-auto page-enter">

        {/* Summary cards */}
        <div className="grid grid-cols-4 gap-4 mb-5">
          {[
            { label: "Net P&L",      value: `${totalPnl >= 0 ? "+" : ""}$${totalPnl.toLocaleString()}`, color: totalPnl >= 0 ? "#22c55e" : "#ef4444" },
            { label: "Total Trades", value: filtered.length,                                              color: ds.textPrimary },
            { label: "Win Rate",     value: filled > 0 ? `${Math.round((wins/filled)*100)}%` : "—",      color: "#06b6d4"      },
            { label: "Total Fees",   value: `$${totalFees.toFixed(2)}`,                                   color: ds.textMuted   },
          ].map(({ label, value, color }) => (
            <div key={label} className="rounded-2xl px-5 py-4 transition-colors duration-300"
              style={{ background: ds.card, boxShadow: ds.cardShadow }}>
              <p className="text-xs mb-1" style={{ color: ds.textMuted }}>{label}</p>
              <p className="text-xl font-semibold" style={{ color }}>{value}</p>
            </div>
          ))}
        </div>

        <div className="rounded-2xl overflow-hidden transition-colors duration-300"
          style={{ background: ds.card, boxShadow: ds.cardShadow }}>

          {/* Filters */}
          <div className="flex items-center flex-wrap gap-3 px-5 py-4" style={{ borderBottom: `1px solid ${ds.divider}` }}>
            <div className="flex items-center gap-2 rounded-xl px-3 py-1.5"
              style={{ background: ds.subBg, border: `1px solid ${ds.border}` }}>
              <Filter size={13} style={{ color: ds.textMuted }}/>
              <select value={symbol} onChange={(e) => { setSymbol(e.target.value); setPage(1); }}
                className="bg-transparent outline-none text-xs cursor-pointer" style={{ color: ds.textSecondary }}>
                {SYMBOLS.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div className="flex gap-1 rounded-xl p-1" style={{ background: ds.subBg }}>
              {STATUS_FILTERS.map((f) => (
                <button key={f} onClick={() => { setStatus(f as "All"|Status); setPage(1); }}
                  className="text-xs px-3 py-1.5 rounded-lg transition-all"
                  style={status === f
                    ? { background: "linear-gradient(90deg,#22c55e,#06b6d4)", color: "white" }
                    : { color: ds.textMuted }}>
                  {f}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-2">
              <label className="text-xs" style={{ color: ds.textMuted }}>From</label>
              <input type="date" value={dateFrom} onChange={(e) => { setDateFrom(e.target.value); setPage(1); }} style={inputStyle}/>
              <label className="text-xs" style={{ color: ds.textMuted }}>To</label>
              <input type="date" value={dateTo} onChange={(e) => { setDateTo(e.target.value); setPage(1); }} style={inputStyle}/>
            </div>
            <div className="ml-auto">
              <button onClick={() => toast.success("Exporting CSV…")}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs transition-colors"
                style={{ background: ds.subBg, color: ds.textSecondary }}>
                <Download size={12}/> Export CSV
              </button>
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr style={{ background: ds.subBg }}>
                  {["Trade ID","Symbol","Side","Quantity","Price","Fee","P&L","Status","Date","Time"].map((h) => (
                    <th key={h} className="text-left text-xs font-medium px-5 py-3 whitespace-nowrap" style={{ color: ds.textMuted }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <TableSkeleton rows={7} cols={10}/>
                ) : paginated.length === 0 ? (
                  <tr><td colSpan={10}>
                    <EmptyState
                      icon={History}
                      title="No trades found"
                      description="Adjust your filters or start trading to see your history here."
                    />
                  </td></tr>
                ) : (
                  paginated.map((t) => (
                    <tr key={t.id} className="transition-colors"
                      style={{ borderTop: `1px solid ${ds.divider}` }}
                      onMouseEnter={(e) => (e.currentTarget.style.background = ds.hoverBg)}
                      onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}>
                      <td className="px-5 py-3.5 text-xs font-mono" style={{ color: ds.textMuted }}>{t.id}</td>
                      <td className="px-5 py-3.5 text-sm font-semibold" style={{ color: ds.textPrimary }}>{t.symbol}</td>
                      <td className="px-5 py-3.5">
                        <span className="text-xs font-semibold px-2.5 py-1 rounded-full"
                          style={t.side === "Buy"
                            ? { background: ds.isDark ? "rgba(34,197,94,0.15)"  : "#dcfce7", color: "#16a34a" }
                            : { background: ds.isDark ? "rgba(239,68,68,0.15)"  : "#fee2e2", color: "#dc2626" }}>
                          {t.side}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-xs" style={{ color: ds.textSecondary }}>{t.qty.toFixed(4)}</td>
                      <td className="px-5 py-3.5 text-xs font-medium" style={{ color: ds.textPrimary }}>${t.price.toLocaleString()}</td>
                      <td className="px-5 py-3.5 text-xs" style={{ color: ds.textMuted }}>${t.fee.toFixed(2)}</td>
                      <td className="px-5 py-3.5">
                        {t.pnl === 0 ? (
                          <span className="text-xs" style={{ color: ds.textMuted }}>—</span>
                        ) : (
                          <span className="text-xs font-semibold" style={{ color: t.pnl > 0 ? "#22c55e" : "#ef4444" }}>
                            {t.pnl > 0 ? "+" : ""}${t.pnl.toLocaleString()}
                          </span>
                        )}
                      </td>
                      <td className="px-5 py-3.5">
                        <span className="text-xs px-2.5 py-1 rounded-full"
                          style={t.status === "Filled"    ? { background: ds.isDark ? "rgba(34,197,94,0.15)"  : "#dcfce7", color: "#16a34a" }
                               : t.status === "Partial"   ? { background: ds.isDark ? "rgba(234,179,8,0.15)"  : "#fef9c3", color: "#ca8a04" }
                               :                            { background: ds.isDark ? "rgba(107,114,128,0.15)": "#f3f4f6", color: "#6b7280" }}>
                          {t.status}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-xs" style={{ color: ds.textMuted }}>{t.date}</td>
                      <td className="px-5 py-3.5 text-xs font-mono" style={{ color: ds.textMuted }}>{t.time}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-between px-5 py-4" style={{ borderTop: `1px solid ${ds.divider}` }}>
            <p className="text-xs" style={{ color: ds.textMuted }}>
              Showing {Math.min((page - 1) * PAGE_SIZE + 1, filtered.length)}–{Math.min(page * PAGE_SIZE, filtered.length)} of {filtered.length} trades
            </p>
            <div className="flex gap-1">
              <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1}
                className="w-7 h-7 rounded-lg text-xs font-medium"
                style={{ background: ds.subBg, color: page === 1 ? ds.textMuted : ds.textSecondary }}>‹</button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                <button key={p} onClick={() => setPage(p)}
                  className="w-7 h-7 rounded-lg text-xs font-medium transition-all"
                  style={p === page
                    ? { background: "linear-gradient(90deg,#22c55e,#06b6d4)", color: "white" }
                    : { background: ds.subBg, color: ds.textSecondary }}>
                  {p}
                </button>
              ))}
              <button onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page === totalPages}
                className="w-7 h-7 rounded-lg text-xs font-medium"
                style={{ background: ds.subBg, color: page === totalPages ? ds.textMuted : ds.textSecondary }}>›</button>
            </div>
          </div>
        </div>
      </main>
    </>
  );
}
