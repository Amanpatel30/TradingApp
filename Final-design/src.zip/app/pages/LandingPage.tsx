import { useState } from "react";
import { useNavigate } from "react-router";
import {
  TrendingUp, TrendingDown, ArrowRight, Search,
  Zap, Trophy, Code, ExternalLink, Activity, ChevronRight,
} from "lucide-react";
import {
  AreaChart, Area, ResponsiveContainer, LineChart, Line,
  BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid,
} from "recharts";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

/* ── Palette ─────────────────────────────────────────────────────────── */
const D = {
  bg:           "#000000",
  bg2:          "#080808",
  card:         "#0F0F0F",
  cardAlt:      "#111111",
  border:       "#1F2937",
  borderBright: "#374151",
  divider:      "#111111",
  txt1:         "#FFFFFF",
  txt2:         "#9CA3AF",
  muted:        "#4B5563",
  green:        "#00D97E",
  greenGlow:    "rgba(0,217,126,0.15)",
  red:          "#F23645",
  redGlow:      "rgba(242,54,69,0.15)",
  purple:       "#7C3AED",
  blue:         "#2962FF",
  cyan:         "#06B6D4",
  amber:        "#F59E0B",
  glass:        "rgba(255,255,255,0.04)",
};

/* ── Mock data ───────────────────────────────────────────────────────── */
const TICKERS = [
  { sym:"BTC/USDT",  price:"$67,482.50", change:"+2.34%", up:true  },
  { sym:"ETH/USDT",  price:"$3,521.80",  change:"-1.12%", up:false },
  { sym:"SOL/USDT",  price:"$178.42",    change:"+5.67%", up:true  },
  { sym:"BNB/USDT",  price:"$592.30",    change:"+0.88%", up:true  },
  { sym:"ADA/USDT",  price:"$0.6124",    change:"+1.44%", up:true  },
  { sym:"LINK/USDT", price:"$14.72",     change:"-2.45%", up:false },
  { sym:"AVAX/USDT", price:"$38.91",     change:"+4.12%", up:true  },
  { sym:"DOT/USDT",  price:"$7.81",      change:"+1.80%", up:true  },
  { sym:"MATIC/USDT",price:"$0.892",     change:"-3.21%", up:false },
  { sym:"ATOM/USDT", price:"$8.93",      change:"+2.80%", up:true  },
];

const CANDLES = [
  {o:60,h:64,l:58,c:63,up:true },{o:63,h:66,l:61,c:62,up:false},{o:62,h:68,l:61,c:67,up:true },
  {o:67,h:70,l:65,c:66,up:false},{o:66,h:69,l:64,c:68,up:true },{o:68,h:73,l:67,c:72,up:true },
  {o:72,h:74,l:69,c:70,up:false},{o:70,h:73,l:68,c:71,up:true },{o:71,h:76,l:70,c:75,up:true },
  {o:75,h:77,l:72,c:73,up:false},{o:73,h:75,l:71,c:74,up:true },{o:74,h:79,l:73,c:78,up:true },
  {o:78,h:80,l:75,c:76,up:false},{o:76,h:78,l:74,c:77,up:true },{o:77,h:82,l:76,c:81,up:true },
  {o:81,h:83,l:78,c:79,up:false},{o:79,h:82,l:77,c:80,up:true },{o:80,h:84,l:79,c:83,up:true },
];

const CHART_DATA = [
  {t:"Jan",v:100},{t:"Feb",v:108},{t:"Mar",v:104},{t:"Apr",v:115},{t:"May",v:110},
  {t:"Jun",v:122},{t:"Jul",v:118},{t:"Aug",v:131},{t:"Sep",v:128},{t:"Oct",v:140},
  {t:"Nov",v:136},{t:"Dec",v:155},
].map(d => ({ ...d, o: d.v - 3, h: d.v + 5, l: d.v - 6, c: d.v + 1 }));

const MARKET = [
  { sym:"BTC", pair:"BTC/USDT", price:"$67,482", chg:"+2.34%", up:true,  color:"#F59E0B", spark:[58,62,60,65,63,68,66,71,69,72,70,74] },
  { sym:"ETH", pair:"ETH/USDT", price:"$3,521",  chg:"-1.12%", up:false, color:"#8B5CF6", spark:[42,40,44,41,39,43,40,38,41,39,37,36] },
  { sym:"SOL", pair:"SOL/USDT", price:"$178.42", chg:"+5.67%", up:true,  color:"#06B6D4", spark:[30,28,33,35,32,37,35,40,38,43,41,45] },
  { sym:"BNB", pair:"BNB/USDT", price:"$592.30", chg:"+0.88%", up:true,  color:"#F59E0B", spark:[50,52,51,54,53,56,55,57,56,58,57,59] },
  { sym:"ADA", pair:"ADA/USDT", price:"$0.6124", chg:"+1.44%", up:true,  color:"#22C55E", spark:[20,22,21,24,23,25,24,26,25,27,26,28] },
  { sym:"LINK",pair:"LNK/USDT", price:"$14.72",  chg:"-2.45%", up:false, color:"#3B82F6", spark:[40,38,42,39,37,40,36,38,35,37,34,33] },
];

const LEADERS = [
  { rank:1, name:"TraderAlpha", roi:"+42%", trades:132, badge:"🥇" },
  { rank:2, name:"CryptoWolf",  roi:"+35%", trades:98,  badge:"🥈" },
  { rank:3, name:"AlgoNinja",   roi:"+28%", trades:76,  badge:"🥉" },
  { rank:4, name:"BitSurfer",   roi:"+21%", trades:110, badge:""   },
  { rank:5, name:"HodlKing",    roi:"+17%", trades:63,  badge:""   },
];

const PARTNERS = [
  "Coinbase","Binance","Crypto.com","CoinMarketCap","Investopedia",
  "Kraken","OKX","KuCoin","Bybit","Gemini",
  "Gate.io","Bitfinex","Huobi","MEXC","CoinGecko",
];

/* ── Types ───────────────────────────────────────────────────────────── */
type ChartType = "candlestick" | "line" | "area" | "bars";

interface ChartCardDef {
  title: string;
  tabs: string[];
  chartTypes: ChartType[];
  uid: string;
}

/* ── Chart showcase sections data ───────────────────────────────────── */
const SECTION1_CARDS: ChartCardDef[] = [
  { title:"Chart type",   tabs:["Candles","Line","Area","Bars"],        chartTypes:["candlestick","line","area","bars"], uid:"s1c1" },
  { title:"Custom theme", tabs:["Dark","Teal","Colorful"],              chartTypes:["bars","line","area"],               uid:"s1c2" },
];
const SECTION2_CARDS: ChartCardDef[] = [
  { title:"Range switcher",       tabs:["1D","1W","1M","1Y"],                    chartTypes:["line","area","bars","candlestick"],  uid:"s2c1" },
  { title:"Trade legend",         tabs:["1-line legend","3-line legend"],         chartTypes:["line","area"],                      uid:"s2c2" },
  { title:"Multi-asset",          tabs:["1 series","2 series","3 series"],        chartTypes:["line","area","bars"],               uid:"s2c3" },
  { title:"Additional options",   tabs:["Go to realtime","Custom watermark"],     chartTypes:["area","line"],                      uid:"s2c4" },
];
const SECTION3_CARDS: ChartCardDef[] = [
  { title:"Data tooltip",      tabs:["Floating tooltip","Tracking tooltip","Magnifier"],         chartTypes:["area","line","bars"],          uid:"s3c1" },
  { title:"Scales formatting", tabs:["Custom price formatter","Custom locale","Custom font"],     chartTypes:["candlestick","line","area"],   uid:"s3c2" },
  { title:"Price scale",       tabs:["Regular","Log scale","Indexed to 100"],                    chartTypes:["line","area","candlestick"],   uid:"s3c3" },
  { title:"Scales config",     tabs:["1 scale","2 scales","Pin to right"],                       chartTypes:["area","line","bars"],          uid:"s3c4" },
];
const SECTION4_CARDS: ChartCardDef[] = [
  { title:"Live data",          tabs:["Realtime updates","Whitespaces","Infinite history"],   chartTypes:["candlestick","line","bars"],   uid:"s4c1" },
  { title:"Indicators & markers",tabs:["Volume","Series markers","Moving average"],           chartTypes:["bars","candlestick","line"],   uid:"s4c2" },
  { title:"Custom chart types", tabs:["Stacked area","Heatmap","HLC area"],                  chartTypes:["area","bars","line"],          uid:"s4c3" },
  { title:"Custom plugins",     tabs:["Bands indicator","Partial price line","Price alerts"], chartTypes:["area","line","candlestick"],   uid:"s4c4" },
];

/* ── MiniCandles ─────────────────────────────────────────────────────── */
function MiniCandles({ data, height = 80 }: { data: typeof CANDLES; height?: number }) {
  const minV = 56, range = 30;
  return (
    <div className="flex items-end gap-0.5" style={{ height }}>
      {data.map((c, i) => {
        const bodyH   = Math.max(2, (Math.abs(c.c - c.o) / range) * height * 0.85);
        const bodyBot = ((Math.min(c.c, c.o) - minV) / range) * height * 0.85;
        const wickH   = ((c.h - c.l) / range) * height * 0.85;
        const wickBot = ((c.l - minV) / range) * height * 0.85;
        const col     = c.up ? D.green : D.red;
        return (
          <div key={i} className="flex-1 relative" style={{ height }}>
            <div className="absolute left-1/2 -translate-x-1/2" style={{ bottom: wickBot, width: 1, height: wickH, background: col, opacity: 0.6 }}/>
            <div className="absolute rounded-sm" style={{ bottom: bodyBot, left:"18%", right:"18%", height: bodyH, minHeight: 2, background: col }}/>
          </div>
        );
      })}
    </div>
  );
}

/* ── ChartRenderer ───────────────────────────────────────────────────── */
function ChartRenderer({ type, uid, height = 200 }: { type: ChartType; uid: string; height?: number }) {
  const tooltipStyle = {
    borderRadius: 8, border: `1px solid ${D.border}`, fontSize: 11,
    background: "#131722", color: D.txt1, boxShadow: "0 4px 16px rgba(0,0,0,0.5)",
  };
  const areaId = `aFill-${uid}`;
  const barId  = `bFill-${uid}`;
  const grid   = <CartesianGrid strokeDasharray="2 4" stroke="rgba(255,255,255,0.06)" vertical={false}/>;
  const xAxis  = <XAxis dataKey="t" tick={{ fontSize: 10, fill: D.muted }} axisLine={false} tickLine={false}/>;
  const yAxis  = <YAxis tick={{ fontSize: 10, fill: D.muted }} axisLine={false} tickLine={false} domain={["auto","auto"]} width={36}/>;

  if (type === "candlestick") {
    return (
      <div className="relative" style={{ height }}>
        {/* Fake axes */}
        <div className="absolute left-0 bottom-5 right-0 flex justify-between px-2 pointer-events-none">
          {["Jan","Mar","May","Jul","Sep","Nov"].map(m => (
            <span key={m} style={{ fontSize: 9, color: D.muted }}>{m}</span>
          ))}
        </div>
        <div className="absolute top-1 right-0 bottom-5 flex flex-col justify-between pointer-events-none" style={{ width: 32 }}>
          {["155","140","125","110","95"].map(v => (
            <span key={v} style={{ fontSize: 9, color: D.muted }}>{v}</span>
          ))}
        </div>
        {/* Grid lines */}
        <div className="absolute inset-0 bottom-5 right-8 pointer-events-none">
          {[0.2,0.4,0.6,0.8].map(p => (
            <div key={p} className="absolute w-full" style={{ top: `${p * 100}%`, borderTop: "1px solid rgba(255,255,255,0.06)" }}/>
          ))}
        </div>
        <div className="absolute inset-0 bottom-5 right-8 overflow-hidden">
          <MiniCandles data={CANDLES} height={height - 22}/>
        </div>
      </div>
    );
  }
  if (type === "line") {
    return (
      <ResponsiveContainer width="100%" height={height}>
        <LineChart data={CHART_DATA}>
          <defs/>
          {grid}{xAxis}{yAxis}
          <Tooltip contentStyle={tooltipStyle} formatter={(value) => [`$${Number(value)}k`, "Price"]}/>
          <Line type="monotone" dataKey="v" stroke={D.cyan} strokeWidth={2} dot={false}/>
        </LineChart>
      </ResponsiveContainer>
    );
  }
  if (type === "area") {
    return (
      <ResponsiveContainer width="100%" height={height}>
        <AreaChart data={CHART_DATA}>
          <defs>
            <linearGradient id={areaId} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={D.purple} stopOpacity={0.4}/>
              <stop offset="100%" stopColor={D.purple} stopOpacity={0}/>
            </linearGradient>
          </defs>
          {grid}{xAxis}{yAxis}
          <Tooltip contentStyle={tooltipStyle} formatter={(value) => [`$${Number(value)}k`, "Price"]}/>
          <Area type="monotone" dataKey="v" stroke={D.purple} strokeWidth={2} fill={`url(#${areaId})`} dot={false}/>
        </AreaChart>
      </ResponsiveContainer>
    );
  }
  /* bars */
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={CHART_DATA}>
        <defs>
          <linearGradient id={barId} x1="0" y1="0" x2="0" y2="1">
            <stop stopColor={D.green}/><stop offset="1" stopColor={D.cyan}/>
          </linearGradient>
        </defs>
        {grid}{xAxis}{yAxis}
        <Tooltip contentStyle={tooltipStyle} formatter={(value) => [`$${Number(value)}k`, "Volume"]}/>
        <Bar dataKey="v" radius={[3,3,0,0]} fill={`url(#${barId})`}/>
      </BarChart>
    </ResponsiveContainer>
  );
}

/* ── ChartFeatureCard ────────────────────────────────────────────────── */
function ChartFeatureCard({ title, tabs, chartTypes, uid }: ChartCardDef) {
  const navigate = useNavigate();
  const [activeIdx, setActiveIdx] = useState(0);
  const type = chartTypes[Math.min(activeIdx, chartTypes.length - 1)];
  return (
    <div style={{ background: D.card, border: `1px solid ${D.border}`, borderRadius: 16, overflow: "hidden" }}>
      <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between", padding:"24px 24px 0" }}>
        <h3 style={{ fontSize: 22, fontWeight: 700, color: D.txt1, letterSpacing: "-0.01em" }}>{title}</h3>
        <button onClick={() => navigate("/dashboard")}
          style={{ fontSize: 11, color: D.txt2, border: `1px solid ${D.border}`, borderRadius: 8,
            padding: "5px 12px", cursor:"pointer", background:"transparent", display:"flex", alignItems:"center", gap: 5,
            flexShrink: 0, marginLeft: 12 }}>
          <Code size={11}/> Get this chart
        </button>
      </div>
      <div style={{ display:"flex", gap:4, padding:"14px 24px 0", flexWrap:"wrap" }}>
        {tabs.map((tab, i) => (
          <button key={`${uid}-t${i}`} onClick={() => setActiveIdx(i)}
            style={{
              padding:"4px 14px", borderRadius:6, fontSize:12, fontWeight:600,
              background: activeIdx === i ? D.txt1 : "transparent",
              color: activeIdx === i ? "#000" : D.muted,
              border:"none", cursor:"pointer", transition:"all 0.15s",
            }}>
            {tab}
          </button>
        ))}
      </div>
      <div style={{ padding:"16px 12px 16px" }}>
        <ChartRenderer type={type} uid={uid} height={220}/>
      </div>
    </div>
  );
}

/* ── Hero Chart Preview ──────────────────────────────────────────────── */
function HeroChartPreview() {
  const tooltipStyle = {
    borderRadius: 8, border:`1px solid ${D.border}`, fontSize:11,
    background:"#131722", color:D.txt1, boxShadow:"0 4px 16px rgba(0,0,0,0.5)",
  };
  return (
    <div style={{ background: D.card, border:`1px solid ${D.border}`, borderRadius:16, overflow:"hidden" }}>
      {/* Chart titlebar */}
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"14px 20px", borderBottom:`1px solid ${D.border}`, background:"#080808" }}>
        <div style={{ display:"flex", alignItems:"center", gap:12 }}>
          <div style={{ display:"flex", gap:6 }}>
            <span style={{ width:10, height:10, borderRadius:"50%", background:"#ef4444", display:"inline-block" }}/>
            <span style={{ width:10, height:10, borderRadius:"50%", background:"#f59e0b", display:"inline-block" }}/>
            <span style={{ width:10, height:10, borderRadius:"50%", background:D.green, display:"inline-block" }}/>
          </div>
          <span style={{ fontSize:13, fontWeight:700, color:D.txt1 }}>BTC/USDT · 1H</span>
          <span style={{ fontSize:14, fontWeight:800, color:D.green }}>$67,482.50</span>
          <span style={{ fontSize:12, color:D.green }}>▲ +2.34%</span>
        </div>
        <div style={{ display:"flex", gap:12 }}>
          {["5m","15m","1h","4h","1D","1W"].map(t => (
            <span key={t} style={{ fontSize:11, color: t==="1h" ? D.txt1 : D.muted, fontWeight: t==="1h" ? 700 : 400, cursor:"pointer" }}>{t}</span>
          ))}
        </div>
      </div>
      {/* Chart */}
      <div style={{ padding:"8px 16px 0" }}>
        <ResponsiveContainer width="100%" height={280}>
          <AreaChart data={CHART_DATA}>
            <defs>
              <linearGradient id="heroChartGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={D.green} stopOpacity={0.25}/>
                <stop offset="100%" stopColor={D.green} stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="2 4" stroke="rgba(255,255,255,0.06)" vertical={false}/>
            <XAxis dataKey="t" tick={{ fontSize:11, fill:D.muted }} axisLine={false} tickLine={false}/>
            <YAxis tick={{ fontSize:11, fill:D.muted }} axisLine={false} tickLine={false} domain={["auto","auto"]} width={36} tickFormatter={(v) => `$${v}k`}/>
            <Tooltip contentStyle={tooltipStyle} formatter={(value) => [`$${Number(value) * 674}`, "BTC Price"]}/>
            <Area type="monotone" dataKey="v" stroke={D.green} strokeWidth={2.5} fill="url(#heroChartGrad)" dot={false}/>
          </AreaChart>
        </ResponsiveContainer>
      </div>
      {/* OHLCV bar */}
      <div style={{ display:"flex", gap:24, padding:"8px 20px 16px", borderTop:`1px solid ${D.divider}` }}>
        {[{l:"O",v:"$67,240"},{l:"H",v:"$68,150"},{l:"L",v:"$66,890"},{l:"C",v:"$67,482"},{l:"Vol",v:"2.41B"}].map(({l,v}) => (
          <div key={l} style={{ display:"flex", alignItems:"baseline", gap:6 }}>
            <span style={{ fontSize:11, color:D.muted }}>{l}</span>
            <span style={{ fontSize:12, fontWeight:700, color:D.txt1 }}>{v}</span>
          </div>
        ))}
        <div style={{ marginLeft:"auto", display:"flex", alignItems:"center", gap:6, padding:"3px 10px", borderRadius:20,
          background:D.greenGlow, border:`1px solid rgba(0,217,126,0.3)` }}>
          <span style={{ width:6, height:6, borderRadius:"50%", background:D.green, display:"inline-block" }}/>
          <span style={{ fontSize:10, color:D.green, fontWeight:600 }}>Live</span>
        </div>
      </div>
    </div>
  );
}

/* ── Main component ──────────────────────────────────────────────────── */
export function LandingPage() {
  const navigate = useNavigate();
  const [searchVal, setSearchVal] = useState("");

  return (
    <div style={{ background: D.bg, color: D.txt1, minHeight:"100vh", fontFamily:"Inter, sans-serif" }}>
      <style>{`
        @keyframes marquee { 0% { transform:translateX(0) } 100% { transform:translateX(-50%) } }
        .ticker-scroll { animation: marquee 45s linear infinite; }
        .ticker-scroll:hover { animation-play-state: paused; }
        .tab-active { background: #fff !important; color: #000 !important; }
        .cs-card-hover:hover { border-color: rgba(255,255,255,0.2) !important; }
      `}</style>

      {/* ── NAVBAR ────────────────────────────────────────────────────── */}
      <nav style={{
        position:"sticky", top:0, zIndex:50,
        display:"flex", alignItems:"center", gap:16,
        padding:"0 32px", height:52,
        background:"rgba(0,0,0,0.92)", backdropFilter:"blur(20px)",
        borderBottom:`1px solid ${D.border}`,
      }}>
        {/* Logo */}
        <button onClick={() => navigate("/")} style={{ display:"flex", alignItems:"center", gap:8, flexShrink:0, cursor:"pointer", background:"none", border:"none" }}>
          <div style={{ width:28, height:28, borderRadius:6, background:"linear-gradient(135deg,#7C3AED,#06B6D4)", display:"flex", alignItems:"center", justifyContent:"center" }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
              <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <span style={{ fontSize:15, fontWeight:800, color:D.txt1 }}>CryptoSim</span>
        </button>

        {/* Search */}
        <div style={{ flex:1, display:"flex", justifyContent:"center" }}>
          <div style={{ display:"flex", alignItems:"center", gap:8, padding:"6px 14px", borderRadius:8, width:280, background:D.glass, border:`1px solid ${D.border}` }}>
            <Search size={13} style={{ color:D.muted }}/>
            <input value={searchVal} onChange={e => setSearchVal(e.target.value)}
              placeholder="Search markets…"
              style={{ background:"transparent", border:"none", outline:"none", fontSize:13, color:D.txt2, width:"100%" }}/>
            <span style={{ fontSize:10, color:D.muted, background:"#111", border:`1px solid ${D.border}`, borderRadius:4, padding:"1px 5px", flexShrink:0 }}>⌘K</span>
          </div>
        </div>

        {/* Right nav */}
        <div style={{ display:"flex", alignItems:"center", gap:4, flexShrink:0 }}>
          {[
            { label:"Markets",     path:"/dashboard" },
            { label:"Leaderboard", path:"/dashboard" },
            { label:"Analytics",   path:"/analytics" },
            { label:"Docs",        path:"/dashboard"  },
          ].map(({label, path}) => (
            <button key={label} onClick={() => navigate(path)}
              style={{ padding:"5px 12px", borderRadius:6, fontSize:13, color:D.txt2, background:"transparent", border:"none", cursor:"pointer" }}>
              {label}
            </button>
          ))}
          <div style={{ width:1, height:16, background:D.border, margin:"0 4px" }}/>
          <button onClick={() => navigate("/signup")}
            style={{ display:"flex", alignItems:"center", gap:6, padding:"6px 16px", borderRadius:8,
              fontSize:13, fontWeight:700, color:"#fff", background:"linear-gradient(90deg,#7C3AED,#06B6D4)",
              border:"none", cursor:"pointer" }}>
            Start Trading
          </button>
          <div style={{ width:30, height:30, borderRadius:"50%", background:"linear-gradient(135deg,#7C3AED,#06B6D4)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:12, fontWeight:700, color:"#fff", marginLeft:4, flexShrink:0 }}>
            A
          </div>
        </div>
      </nav>

      {/* ── TICKER BAR ────────────────────────────────────────────────── */}
      <div style={{ overflow:"hidden", background:"#000", borderBottom:`1px solid ${D.border}` }}>
        <div className="ticker-scroll" style={{ display:"flex", width:"max-content" }}>
          {[...TICKERS, ...TICKERS].map((t, i) => (
            <div key={i} style={{ display:"flex", alignItems:"center", gap:10, padding:"7px 20px", flexShrink:0, borderRight:`1px solid ${D.border}` }}>
              <span style={{ fontSize:11, fontWeight:600, color:D.muted }}>{t.sym}</span>
              <span style={{ fontSize:11, fontWeight:700, color:D.txt1 }}>{t.price}</span>
              <span style={{ fontSize:11, fontWeight:600, color:t.up ? D.green : D.red, display:"flex", alignItems:"center", gap:2 }}>
                {t.up ? <TrendingUp size={9}/> : <TrendingDown size={9}/>}{t.change}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* ── HERO ──────────────────────────────────────────────────────── */}
      <section style={{ padding:"80px 64px 60px", textAlign:"center", background:"#000", position:"relative", overflow:"hidden" }}>
        {/* ambient glow */}
        <div style={{ position:"absolute", inset:0, pointerEvents:"none",
          backgroundImage:"radial-gradient(ellipse 60% 40% at 50% -10%, rgba(124,58,237,0.15), transparent 70%)" }}/>
        <div style={{ position:"relative", maxWidth:800, margin:"0 auto" }}>
          <h1 style={{ fontSize:"clamp(3.5rem,8vw,6rem)", fontWeight:900, lineHeight:1.0, letterSpacing:"-0.03em", marginBottom:20, color:D.txt1 }}>
            Trade Crypto.<br/>
            <span style={{ backgroundImage:`linear-gradient(90deg,${D.green},${D.cyan})`, WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" }}>
              Practice Risk-Free.
            </span>
          </h1>
          <p style={{ fontSize:18, color:D.txt2, lineHeight:1.7, maxWidth:540, margin:"0 auto 40px" }}>
            A professional-grade trading simulator with real-time market data and advanced charting tools.
          </p>

          {/* CTA boxes — TradingView style */}
          <div style={{ display:"flex", gap:12, justifyContent:"center", flexWrap:"wrap" }}>
            <button onClick={() => navigate("/signup")}
              style={{ display:"flex", alignItems:"center", justifyContent:"space-between", gap:24,
                padding:"16px 22px", borderRadius:10, background:D.card, border:`1px solid ${D.borderBright}`,
                cursor:"pointer", minWidth:220, textAlign:"left" }}>
              <div>
                <div style={{ fontSize:15, fontWeight:700, color:D.green, marginBottom:3 }}>Start Trading Free</div>
                <div style={{ fontSize:12, color:D.muted }}>Create your account</div>
              </div>
              <ExternalLink size={14} style={{ color:D.muted, flexShrink:0 }}/>
            </button>
            <button onClick={() => navigate("/dashboard")}
              style={{ display:"flex", alignItems:"center", justifyContent:"space-between", gap:24,
                padding:"16px 22px", borderRadius:10, background:D.card, border:`1px solid ${D.border}`,
                cursor:"pointer", minWidth:220, textAlign:"left" }}>
              <div>
                <div style={{ fontSize:15, fontWeight:700, color:D.cyan, marginBottom:3 }}>View Dashboard</div>
                <div style={{ fontSize:12, color:D.muted }}>Explore the platform</div>
              </div>
              <ExternalLink size={14} style={{ color:D.muted, flexShrink:0 }}/>
            </button>
          </div>
        </div>

        {/* Hero chart */}
        <div style={{ maxWidth:1000, margin:"60px auto 0", textAlign:"left" }}>
          <HeroChartPreview/>
        </div>
      </section>

      {/* ── FEATURE CARDS ─────────────────────────────────────────────── */}
      <section style={{ padding:"100px 64px", background:"#000" }}>
        <div style={{ maxWidth:1280, margin:"0 auto" }}>
          <div style={{ textAlign:"center", marginBottom:60 }}>
            <h2 style={{ fontSize:"clamp(2rem,4vw,3rem)", fontWeight:900, color:D.txt1, letterSpacing:"-0.03em", lineHeight:1.1, marginBottom:14 }}>
              Free, open-source,<br/>and feature-rich
            </h2>
            <p style={{ fontSize:17, color:D.txt2, maxWidth:520, margin:"0 auto" }}>
              Your dream of powerful, yet lightweight, interactive charts is now a reality.
            </p>
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:24 }}>
            {[
              {
                Icon: Zap,
                iconBg: "#1A1A1A",
                title: "Super compact",
                desc: "Canvas-powered charts mean our simulator is faster than any other web-based trading platform.",
                btn: "Get started",
                btnColor: D.txt1,
              },
              {
                Icon: Activity,
                iconBg: "#1A1A1A",
                title: "Streaming updates",
                desc: "Most recent data is displayed in real-time via WebSocket without having to reload the page.",
                btn: "Get started",
                btnColor: D.txt1,
              },
              {
                Icon: Code,
                iconBg: "#1A1A1A",
                title: "Open platform",
                desc: "Open API with full documentation. Build your own indicators, strategies and trading bots.",
                btn: "Get started",
                btnColor: D.txt1,
              },
            ].map(({ Icon, iconBg, title, desc, btn, btnColor }) => (
              <div key={title} className="cs-card-hover"
                style={{ background:D.card, border:`1px solid ${D.border}`, borderRadius:16, overflow:"hidden", transition:"border-color 0.2s" }}>
                {/* Icon illustration area */}
                <div style={{ height:200, background:iconBg, display:"flex", alignItems:"center", justifyContent:"center", position:"relative", overflow:"hidden" }}>
                  <div style={{ width:88, height:88, borderRadius:22, background:"#1A1A1A", border:`1px solid ${D.border}`, display:"flex", alignItems:"center", justifyContent:"center",
                    boxShadow:"0 0 40px rgba(255,255,255,0.05)" }}>
                    <Icon size={40} style={{ color:D.txt1 }}/>
                  </div>
                  {/* Subtle radial glow behind icon */}
                  <div style={{ position:"absolute", inset:0, background:"radial-gradient(ellipse 60% 60% at 50% 60%, rgba(255,255,255,0.04), transparent 70%)", pointerEvents:"none" }}/>
                </div>
                {/* Content */}
                <div style={{ padding:"28px 28px 32px" }}>
                  <h3 style={{ fontSize:22, fontWeight:700, color:D.txt1, marginBottom:12, letterSpacing:"-0.01em" }}>{title}</h3>
                  <p style={{ fontSize:14, color:D.txt2, lineHeight:1.7, marginBottom:24 }}>{desc}</p>
                  <button onClick={() => navigate("/signup")}
                    style={{ display:"flex", alignItems:"center", gap:6, padding:"9px 20px", borderRadius:8,
                      background:D.cardAlt, border:`1px solid ${D.border}`, color:btnColor, fontSize:13, fontWeight:600, cursor:"pointer" }}>
                    {btn} <ChevronRight size={14}/>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CHART SHOWCASE 1 ──────────────────────────────────────────── */}
      <section style={{ padding:"100px 64px", background:"#000", borderTop:`1px solid ${D.border}` }}>
        <div style={{ maxWidth:1280, margin:"0 auto" }}>
          <div style={{ textAlign:"center", marginBottom:60 }}>
            <h2 style={{ fontSize:"clamp(2rem,4vw,3rem)", fontWeight:900, color:D.txt1, letterSpacing:"-0.03em", lineHeight:1.1, marginBottom:14 }}>
              Finance at the heart<br/>of it all
            </h2>
            <p style={{ fontSize:17, color:D.txt2, maxWidth:600, margin:"0 auto" }}>
              CryptoSim charts are trusted by traders learning to navigate real markets — so you can be sure we've included all the important stuff.
            </p>
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(2,1fr)", gap:20 }}>
            {SECTION1_CARDS.map(card => (
              <ChartFeatureCard key={card.uid} {...card}/>
            ))}
          </div>
        </div>
      </section>

      {/* ── CHART SHOWCASE 2 ──────────────────────────────────────────── */}
      <section style={{ padding:"0 64px 100px", background:"#000" }}>
        <div style={{ maxWidth:1280, margin:"0 auto" }}>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(2,1fr)", gap:20 }}>
            {SECTION2_CARDS.map(card => (
              <ChartFeatureCard key={card.uid} {...card}/>
            ))}
          </div>
        </div>
      </section>

      {/* ── CHART SHOWCASE 3 ──────────────────────────────────────────── */}
      <section style={{ padding:"0 64px 100px", background:"#000" }}>
        <div style={{ maxWidth:1280, margin:"0 auto" }}>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(2,1fr)", gap:20 }}>
            {SECTION3_CARDS.map(card => (
              <ChartFeatureCard key={card.uid} {...card}/>
            ))}
          </div>
        </div>
      </section>

      {/* ── CHART SHOWCASE 4 ──────────────────────────────────────────── */}
      <section style={{ padding:"0 64px 100px", background:"#000" }}>
        <div style={{ maxWidth:1280, margin:"0 auto" }}>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(2,1fr)", gap:20 }}>
            {SECTION4_CARDS.map(card => (
              <ChartFeatureCard key={card.uid} {...card}/>
            ))}
          </div>
        </div>
      </section>

      {/* ── PARTNERS ──────────────────────────────────────────────────── */}
      <section style={{ padding:"100px 64px", background:"#000", borderTop:`1px solid ${D.border}` }}>
        <div style={{ maxWidth:1280, margin:"0 auto", textAlign:"center" }}>
          <h2 style={{ fontSize:"clamp(2rem,4vw,3rem)", fontWeight:900, color:D.txt1, letterSpacing:"-0.03em", lineHeight:1.1, marginBottom:14 }}>
            Trusted by traders worldwide
          </h2>
          <p style={{ fontSize:17, color:D.txt2, marginBottom:60 }}>
            Platforms and communities that rely on CryptoSim to power their trading education.
          </p>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(5,1fr)", gap:0 }}>
            {PARTNERS.map((name, i) => (
              <div key={name} style={{ padding:"28px 16px", borderTop:`1px solid ${D.border}`,
                borderLeft: i % 5 === 0 ? `1px solid ${D.border}` : "none",
                borderRight:`1px solid ${D.border}`,
                borderBottom: i >= 10 ? `1px solid ${D.border}` : "none",
                display:"flex", alignItems:"center", justifyContent:"center" }}>
                <span style={{ fontSize:16, fontWeight:800, color:D.muted, letterSpacing:"-0.01em",
                  filter:"grayscale(1)", opacity:0.55, transition:"opacity 0.2s" }}
                  onMouseEnter={e => (e.currentTarget.style.opacity = "1")}
                  onMouseLeave={e => (e.currentTarget.style.opacity = "0.55")}>
                  {name}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── PERFORMANCE ───────────────────────────────────────────────── */}
      <section style={{ padding:"100px 64px 0", background:"#000", borderTop:`1px solid ${D.border}` }}>
        <div style={{ maxWidth:1280, margin:"0 auto", textAlign:"center" }}>
          <h2 style={{ fontSize:"clamp(2.5rem,5vw,4rem)", fontWeight:900, color:D.txt1, letterSpacing:"-0.03em", lineHeight:1.05, marginBottom:20 }}>
            Fast charts.<br/>Built for traders.
          </h2>
          <p style={{ fontSize:17, color:D.txt2, maxWidth:480, margin:"0 auto 36px", lineHeight:1.7 }}>
            Get easy-to-use charts, bountiful in features, and take your trading skills to the next level.
          </p>
          <button onClick={() => navigate("/dashboard")}
            style={{ display:"inline-flex", alignItems:"center", gap:8, padding:"14px 32px", borderRadius:100,
              background:D.txt1, color:"#000", fontSize:15, fontWeight:700, border:"none", cursor:"pointer", marginBottom:60 }}>
            Explore charts <ArrowRight size={15}/>
          </button>
          <div style={{ borderRadius:16, overflow:"hidden", border:`1px solid ${D.border}` }}>
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1621361356099-704eb70d9f0f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtdWx0aXBsZSUyMHRyYWRpbmclMjBtb25pdG9ycyUyMGRhcmslMjByb29tJTIwbmVvbiUyMGdsb3d8ZW58MXx8fHwxNzcyNzg1NjMxfDA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Trading monitors"
              style={{ width:"100%", height:440, objectFit:"cover", display:"block" }}
            />
          </div>
        </div>
      </section>

      {/* ── MARKET OVERVIEW ───────────────────────────────────────────── */}
      <section style={{ padding:"100px 64px 0", background:"#000" }}>
        <div style={{ maxWidth:1280, margin:"0 auto" }}>
          <div style={{ display:"flex", alignItems:"flex-end", justifyContent:"space-between", marginBottom:32 }}>
            <div>
              <p style={{ fontSize:11, fontWeight:700, letterSpacing:"0.12em", color:D.cyan, textTransform:"uppercase", marginBottom:8 }}>Live Markets</p>
              <h2 style={{ fontSize:"2rem", fontWeight:900, color:D.txt1, letterSpacing:"-0.02em" }}>Real-time price overview</h2>
            </div>
            <button onClick={() => navigate("/dashboard")}
              style={{ display:"flex", alignItems:"center", gap:6, fontSize:13, fontWeight:600, color:D.cyan, background:"transparent", border:"none", cursor:"pointer" }}>
              View all markets <ArrowRight size={13}/>
            </button>
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:16 }}>
            {MARKET.map(m => {
              const sd = m.spark.map((v, i) => ({ i, v }));
              return (
                <div key={m.sym} className="cs-card-hover"
                  style={{ background:D.card, border:`1px solid ${D.border}`, borderRadius:16, padding:20, cursor:"pointer", transition:"border-color 0.2s" }}
                  onMouseEnter={e => (e.currentTarget.style.borderColor = m.up ? "rgba(0,217,126,0.3)" : "rgba(242,54,69,0.3)")}
                  onMouseLeave={e => (e.currentTarget.style.borderColor = D.border)}>
                  <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:12 }}>
                    <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                      <div style={{ width:36, height:36, borderRadius:10, display:"flex", alignItems:"center", justifyContent:"center", fontWeight:700, fontSize:13,
                        background: m.color + "22", color: m.color, border:`1px solid ${m.color}33` }}>
                        {m.sym[0]}
                      </div>
                      <div>
                        <div style={{ fontSize:13, fontWeight:700, color:D.txt1 }}>{m.sym}</div>
                        <div style={{ fontSize:10, color:D.muted }}>{m.pair}</div>
                      </div>
                    </div>
                    <span style={{ fontSize:12, fontWeight:600, padding:"3px 8px", borderRadius:20,
                      background: m.up ? D.greenGlow : D.redGlow, color: m.up ? D.green : D.red,
                      display:"flex", alignItems:"center", gap:3 }}>
                      {m.up ? <TrendingUp size={10}/> : <TrendingDown size={10}/>}{m.chg}
                    </span>
                  </div>
                  <div style={{ fontSize:20, fontWeight:800, color:D.txt1, marginBottom:10 }}>{m.price}</div>
                  <ResponsiveContainer width="100%" height={48}>
                    <AreaChart data={sd}>
                      <defs>
                        <linearGradient id={`mktSpk-${m.sym}`} x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor={m.up ? D.green : D.red} stopOpacity={0.2}/>
                          <stop offset="100%" stopColor={m.up ? D.green : D.red} stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <Area type="monotone" dataKey="v" stroke={m.up ? D.green : D.red} strokeWidth={1.5}
                        fill={`url(#mktSpk-${m.sym})`} dot={false}/>
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── LEADERBOARD ───────────────────────────────────────────────── */}
      <section style={{ padding:"100px 64px", background:"#000" }}>
        <div style={{ maxWidth:1280, margin:"0 auto" }}>
          <div style={{ display:"flex", alignItems:"flex-end", justifyContent:"space-between", marginBottom:32 }}>
            <div>
              <p style={{ fontSize:11, fontWeight:700, letterSpacing:"0.12em", color:D.amber, textTransform:"uppercase", marginBottom:8 }}>Leaderboard</p>
              <h2 style={{ fontSize:"2rem", fontWeight:900, color:D.txt1, letterSpacing:"-0.02em" }}>Top traders this week</h2>
            </div>
            <div style={{ display:"flex", alignItems:"center", gap:6, padding:"5px 12px", borderRadius:20,
              background:D.greenGlow, border:"1px solid rgba(0,217,126,0.3)" }}>
              <span style={{ width:6, height:6, borderRadius:"50%", background:D.green, display:"inline-block" }}/>
              <span style={{ fontSize:11, fontWeight:600, color:D.green }}>Live rankings</span>
            </div>
          </div>
          <div style={{ background:D.card, border:`1px solid ${D.border}`, borderRadius:16, overflow:"hidden" }}>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 2fr 1fr 1fr", padding:"12px 28px",
              borderBottom:`1px solid ${D.border}`, background:"rgba(255,255,255,0.02)" }}>
              {["Rank","Trader","ROI (7d)","Total Trades"].map(h => (
                <span key={h} style={{ fontSize:11, fontWeight:600, color:D.muted }}>{h}</span>
              ))}
            </div>
            {LEADERS.map((l, i) => (
              <div key={l.rank} style={{
                display:"grid", gridTemplateColumns:"1fr 2fr 1fr 1fr", alignItems:"center",
                padding:"20px 28px", cursor:"pointer",
                borderTop: i === 0 ? "none" : `1px solid ${D.divider}`,
                transition:"background 0.15s",
              }}
                onMouseEnter={e => (e.currentTarget.style.background = "rgba(255,255,255,0.02)")}
                onMouseLeave={e => (e.currentTarget.style.background = "transparent")}>
                <div>
                  {l.badge
                    ? <span style={{ fontSize:22 }}>{l.badge}</span>
                    : <div style={{ width:32, height:32, borderRadius:8, display:"flex", alignItems:"center", justifyContent:"center",
                        background:D.glass, border:`1px solid ${D.border}`, fontSize:13, fontWeight:700, color:D.muted }}>
                        {l.rank}
                      </div>
                  }
                </div>
                <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                  <div style={{ width:36, height:36, borderRadius:"50%", display:"flex", alignItems:"center", justifyContent:"center",
                    fontWeight:700, fontSize:13, color:"#fff", background:`hsl(${l.rank * 67},65%,45%)` }}>
                    {l.name[0]}
                  </div>
                  <span style={{ fontSize:14, fontWeight:600, color:D.txt1 }}>{l.name}</span>
                </div>
                <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                  <TrendingUp size={14} style={{ color:D.green }}/>
                  <span style={{ fontSize:18, fontWeight:800, color:D.green }}>{l.roi}</span>
                </div>
                <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                  <Trophy size={13} style={{ color:D.amber }}/>
                  <span style={{ fontSize:14, color:D.txt2 }}>{l.trades} trades</span>
                </div>
              </div>
            ))}
            <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"14px 28px",
              borderTop:`1px solid ${D.border}`, background:"rgba(255,255,255,0.02)" }}>
              <span style={{ fontSize:11, color:D.muted }}>Showing top 5 of 12,400+ traders</span>
              <button onClick={() => navigate("/dashboard")}
                style={{ display:"flex", alignItems:"center", gap:5, fontSize:12, fontWeight:600, color:D.cyan, background:"transparent", border:"none", cursor:"pointer" }}>
                Full leaderboard <ArrowRight size={12}/>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ── FOOTER ────────────────────────────────────────────────────── */}
      <footer style={{ background:"#000", borderTop:`1px solid ${D.border}`, padding:"60px 64px 40px" }}>
        <div style={{ maxWidth:1280, margin:"0 auto" }}>
          <div style={{ display:"grid", gridTemplateColumns:"1.4fr 1fr 1fr 1fr 1fr", gap:40, marginBottom:48 }}>
            {/* Brand */}
            <div>
              <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:12 }}>
                <div style={{ width:26, height:26, borderRadius:6, background:"linear-gradient(135deg,#7C3AED,#06B6D4)", display:"flex", alignItems:"center", justifyContent:"center" }}>
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none">
                    <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <span style={{ fontSize:14, fontWeight:800, color:D.txt1 }}>CryptoSim</span>
              </div>
              <p style={{ fontSize:12, color:D.muted, lineHeight:1.7, marginBottom:20 }}>
                A trading simulator using virtual funds.<br/>No real money is used.
              </p>
              <div style={{ display:"inline-flex", alignItems:"center", gap:6, padding:"4px 10px", borderRadius:20,
                background:D.greenGlow, border:"1px solid rgba(0,217,126,0.3)" }}>
                <span style={{ width:6, height:6, borderRadius:"50%", background:D.green, display:"inline-block" }}/>
                <span style={{ fontSize:10, fontWeight:600, color:D.green }}>All systems live</span>
              </div>
            </div>
            {/* Link columns */}
            {[
              { heading:"Product",   links:["Dashboard","Exchange","Analytics","Open Orders","Trade History"] },
              { heading:"Markets",   links:["Crypto Pairs","Spot Trading","Futures Sim","Margin Sim","Price Alerts"] },
              { heading:"Community", links:["Discord","Telegram","Twitter","Reddit","Blog"] },
              { heading:"Company",   links:["About","Privacy Policy","Terms","Risk Disclosure","FAQ"] },
            ].map(col => (
              <div key={col.heading}>
                <p style={{ fontSize:11, fontWeight:700, color:D.txt2, marginBottom:16, letterSpacing:"0.06em", textTransform:"uppercase" }}>{col.heading}</p>
                <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
                  {col.links.map(l => (
                    <button key={l} style={{ textAlign:"left", fontSize:13, color:D.muted, background:"transparent", border:"none", cursor:"pointer" }}
                      onMouseEnter={e => (e.currentTarget.style.color = D.txt2)}
                      onMouseLeave={e => (e.currentTarget.style.color = D.muted)}>
                      {l}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", paddingTop:24, borderTop:`1px solid ${D.border}` }}>
            <p style={{ fontSize:11, color:D.muted }}>© 2026 CryptoSim Trading Simulator. For educational use only. Not financial advice.</p>
            <div style={{ display:"flex", gap:12 }}>
              {["Twitter","Discord","GitHub","Telegram"].map(s => (
                <button key={s} style={{ fontSize:11, color:D.muted, background:"transparent", border:`1px solid ${D.border}`, borderRadius:6, padding:"4px 10px", cursor:"pointer" }}>{s}</button>
              ))}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}