import { useState, useRef, useEffect } from "react";
import { Plus, Search, Download, MoreHorizontal, ChevronUp, ChevronDown, FileText, X, Pencil, Trash2, Eye } from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "../components/PageHeader";
import { useDS } from "../context/ThemeContext";

type Status = "Paid" | "Pending" | "Overdue" | "Draft";
interface Invoice { id:string; client:string; email:string; project:string; amount:string; amountNum:number; date:string; due:string; status:Status; }

const initialInvoices: Invoice[] = [
  { id:"INV-2026-001", client:"Apex Ventures",    email:"billing@apex.io",       project:"Smart Contract Audit", amount:"$12,400", amountNum:12400, date:"Mar 01, 2026", due:"Mar 15, 2026", status:"Pending" },
  { id:"INV-2026-002", client:"Nova Protocol",    email:"finance@nova.xyz",      project:"DeFi Dashboard Build", amount:"$8,750",  amountNum:8750,  date:"Feb 22, 2026", due:"Mar 08, 2026", status:"Paid"    },
  { id:"INV-2026-003", client:"Chain Analytics",  email:"pay@chainanalytics.io", project:"On-chain Data API",    amount:"$5,200",  amountNum:5200,  date:"Feb 15, 2026", due:"Mar 01, 2026", status:"Overdue" },
  { id:"INV-2026-004", client:"Metaverse Labs",   email:"ops@metalabs.com",      project:"NFT Marketplace",      amount:"$21,000", amountNum:21000, date:"Mar 02, 2026", due:"Mar 30, 2026", status:"Draft"   },
  { id:"INV-2026-005", client:"BlockStream Inc",  email:"admin@blockstream.io",  project:"Node Infrastructure",  amount:"$3,600",  amountNum:3600,  date:"Jan 28, 2026", due:"Feb 11, 2026", status:"Paid"    },
  { id:"INV-2026-006", client:"Orbis Capital",    email:"billing@orbis.fund",    project:"Portfolio Tracker",    amount:"$9,150",  amountNum:9150,  date:"Feb 05, 2026", due:"Feb 20, 2026", status:"Overdue" },
  { id:"INV-2026-007", client:"Stellar Payments", email:"hi@stellar.pay",        project:"Payment Gateway SDK",  amount:"$6,800",  amountNum:6800,  date:"Mar 02, 2026", due:"Apr 01, 2026", status:"Pending" },
];

const statusStyle: Record<Status, { light:{bg:string;text:string}; dark:{bg:string;text:string} }> = {
  Paid:    { light:{bg:"#dcfce7",text:"#16a34a"}, dark:{bg:"rgba(34,197,94,0.15)",  text:"#4ade80"} },
  Pending: { light:{bg:"#fef9c3",text:"#ca8a04"}, dark:{bg:"rgba(234,179,8,0.15)",  text:"#fbbf24"} },
  Overdue: { light:{bg:"#fee2e2",text:"#dc2626"}, dark:{bg:"rgba(239,68,68,0.15)",  text:"#f87171"} },
  Draft:   { light:{bg:"#f3f4f6",text:"#6b7280"}, dark:{bg:"rgba(107,114,128,0.15)",text:"#9ca3af"} },
};

const PAGE_SIZE = 4;

function RowMenu({ inv, onDelete, ds }: { inv: Invoice; onDelete: (id:string) => void; ds: ReturnType<typeof useDS> }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const h = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  return (
    <div className="relative" ref={ref}>
      <button onClick={() => setOpen((o) => !o)}
        className="w-7 h-7 flex items-center justify-center rounded-lg transition-colors"
        style={{ background: ds.subBg, color: ds.textMuted }}
        onMouseEnter={(e) => (e.currentTarget.style.background = ds.subBg2)}
        onMouseLeave={(e) => (e.currentTarget.style.background = ds.subBg)}>
        <MoreHorizontal size={12}/>
      </button>
      {open && (
        <div className="absolute right-0 top-8 w-36 rounded-xl z-20 overflow-hidden"
          style={{ background: ds.card, border: `1px solid ${ds.border}`, boxShadow: "0 8px 24px rgba(0,0,0,0.18)" }}>
          {[
            { label:"View",   icon:Eye,    action:() => { toast.info(`Viewing ${inv.id}`); setOpen(false); }, danger:false },
            { label:"Edit",   icon:Pencil, action:() => { toast.info(`Editing ${inv.id}`); setOpen(false); }, danger:false },
            { label:"Delete", icon:Trash2, action:() => { onDelete(inv.id); setOpen(false); },                danger:true  },
          ].map(({ label, icon:Icon, action, danger }) => (
            <button key={label} onClick={action}
              className="w-full flex items-center gap-2 px-3 py-2 text-xs transition-colors"
              style={{ color: danger ? "#ef4444" : ds.textSecondary }}
              onMouseEnter={(e) => (e.currentTarget.style.background = danger ? (ds.isDark ? "rgba(239,68,68,0.1)" : "#fff5f5") : ds.hoverBg)}
              onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}>
              <Icon size={12}/>{label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export function InvoicesPage() {
  const ds = useDS();
  const [invoices, setInvoices] = useState<Invoice[]>(initialInvoices);
  const [search, setSearch]     = useState("");
  const [filter, setFilter]     = useState<"All"|Status>("All");
  const [sortDir, setSortDir]   = useState<"asc"|"desc">("desc");
  const [page, setPage]         = useState(1);
  const [newOpen, setNewOpen]   = useState(false);
  const [form, setForm]         = useState({ client:"", email:"", project:"", amount:"", due:"" });

  const getStatusStyle = (s: Status) => ds.isDark ? statusStyle[s].dark : statusStyle[s].light;

  const handleDelete = (id:string) => { setInvoices((p) => p.filter((i) => i.id !== id)); toast.success(`Invoice ${id} deleted`); };
  const handleNew    = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.client || !form.project || !form.amount) { toast.error("Fill required fields"); return; }
    const num = parseFloat(form.amount.replace(/[^0-9.]/g,"")) || 0;
    const inv: Invoice = { id:`INV-2026-${String(invoices.length+1).padStart(3,"0")}`, client:form.client, email:form.email, project:form.project, amount:`$${num.toLocaleString()}`, amountNum:num, date:"Mar 03, 2026", due:form.due||"Mar 31, 2026", status:"Draft" };
    setInvoices((p) => [inv, ...p]);
    toast.success(`Invoice ${inv.id} created!`);
    setNewOpen(false); setForm({ client:"", email:"", project:"", amount:"", due:"" });
  };

  const filtered = invoices
    .filter((inv) => (filter === "All" || inv.status === filter) && (inv.client.toLowerCase().includes(search.toLowerCase()) || inv.id.toLowerCase().includes(search.toLowerCase())))
    .sort((a,b) => sortDir === "desc" ? b.amountNum - a.amountNum : a.amountNum - b.amountNum);
  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paginated  = filtered.slice((page-1)*PAGE_SIZE, page*PAGE_SIZE);

  const inputStyle = { background: ds.inputBg, border: `1px solid ${ds.inputBorder}`, borderRadius:"12px", padding:"10px 16px", fontSize:"14px", color: ds.textPrimary, outline:"none", width:"100%" };

  return (
    <>
      <PageHeader title="Invoices"/>
      <main className="flex-1 px-6 pb-8 overflow-auto">

        {/* Stat cards */}
        <div className="grid grid-cols-4 gap-4 mb-5">
          {[
            { label:"Total Revenue", value:"$66,900", sub:"all time",   color:"#06b6d4" },
            { label:"Paid",          value:"$14,350", sub:"2 invoices", color:"#22c55e" },
            { label:"Pending",       value:"$19,200", sub:"2 invoices", color:"#f59e0b" },
            { label:"Overdue",       value:"$8,800",  sub:"2 invoices", color:"#ef4444" },
          ].map(({ label, value, sub, color }) => (
            <div key={label} className="rounded-2xl p-5 transition-colors duration-300"
              style={{ background: ds.card, boxShadow: ds.cardShadow }}>
              <div className="flex items-center justify-between mb-3">
                <p className="text-xs" style={{ color: ds.textMuted }}>{label}</p>
                <FileText size={15} style={{ color }}/>
              </div>
              <p className="text-xl font-semibold" style={{ color: ds.textPrimary }}>{value}</p>
              <p className="text-xs mt-1" style={{ color: ds.textMuted }}>{sub}</p>
            </div>
          ))}
        </div>

        <div className="rounded-2xl overflow-hidden transition-colors duration-300"
          style={{ background: ds.card, boxShadow: ds.cardShadow }}>
          {/* Toolbar */}
          <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: `1px solid ${ds.divider}` }}>
            <div className="flex items-center gap-2">
              {(["All","Paid","Pending","Overdue","Draft"] as const).map((f) => (
                <button key={f} onClick={() => { setFilter(f); setPage(1); }}
                  className="text-xs px-3 py-1.5 rounded-lg transition-all"
                  style={filter === f
                    ? { background: "linear-gradient(90deg,#22c55e,#06b6d4)", color: "white" }
                    : { background: ds.subBg, color: ds.textMuted }}>
                  {f}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 rounded-xl px-3 py-2"
                style={{ background: ds.subBg, border: `1px solid ${ds.border}` }}>
                <Search size={13} style={{ color: ds.textMuted }}/>
                <input value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }}
                  placeholder="Search invoices…" className="bg-transparent outline-none text-xs w-36"
                  style={{ color: ds.textSecondary }}/>
              </div>
              <button onClick={() => setNewOpen(true)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-medium text-white"
                style={{ background: "linear-gradient(90deg,#22c55e,#06b6d4)" }}>
                <Plus size={13}/> New Invoice
              </button>
            </div>
          </div>

          <table className="w-full text-sm">
            <thead>
              <tr style={{ background: ds.subBg }}>
                {[{ label:"Invoice ID",sortable:false },{ label:"Client",sortable:false },{ label:"Project",sortable:false },{ label:"Amount",sortable:true },{ label:"Issue Date",sortable:false },{ label:"Due Date",sortable:false },{ label:"Status",sortable:false },{ label:"",sortable:false }].map(({ label, sortable }) => (
                  <th key={label} className="text-left text-xs font-medium px-5 py-3 whitespace-nowrap"
                    style={{ color: ds.textMuted, cursor: sortable ? "pointer" : "default" }}
                    onClick={sortable ? () => setSortDir((d) => d === "asc" ? "desc" : "asc") : undefined}>
                    <span className="flex items-center gap-1">
                      {label}
                      {sortable && (
                        <span className="flex flex-col">
                          <ChevronUp size={9} style={{ color: sortDir==="asc" ? "#06b6d4" : ds.textMuted, marginBottom:-2 }}/>
                          <ChevronDown size={9} style={{ color: sortDir==="desc" ? "#06b6d4" : ds.textMuted }}/>
                        </span>
                      )}
                    </span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {paginated.length === 0 ? (
                <tr><td colSpan={8} className="text-center py-12 text-sm" style={{ color: ds.textMuted }}>No invoices found</td></tr>
              ) : (
                paginated.map((inv) => (
                  <tr key={inv.id} className="transition-colors" style={{ borderTop: `1px solid ${ds.divider}` }}
                    onMouseEnter={(e) => (e.currentTarget.style.background = ds.hoverBg)}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}>
                    <td className="px-5 py-4 text-xs font-mono" style={{ color: ds.textMuted }}>{inv.id}</td>
                    <td className="px-5 py-4">
                      <p className="text-sm font-medium" style={{ color: ds.textPrimary }}>{inv.client}</p>
                      <p className="text-xs" style={{ color: ds.textMuted }}>{inv.email}</p>
                    </td>
                    <td className="px-5 py-4 text-sm" style={{ color: ds.textSecondary }}>{inv.project}</td>
                    <td className="px-5 py-4 text-sm font-semibold" style={{ color: ds.textPrimary }}>{inv.amount}</td>
                    <td className="px-5 py-4 text-xs" style={{ color: ds.textMuted }}>{inv.date}</td>
                    <td className="px-5 py-4 text-xs" style={{ color: ds.textMuted }}>{inv.due}</td>
                    <td className="px-5 py-4">
                      <span className="text-xs font-medium px-2.5 py-1 rounded-full" style={getStatusStyle(inv.status)}>{inv.status}</span>
                    </td>
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-2">
                        <button onClick={() => toast.success(`Downloading ${inv.id}…`)}
                          className="w-7 h-7 flex items-center justify-center rounded-lg transition-colors"
                          style={{ background: ds.subBg, color: ds.textMuted }}
                          onMouseEnter={(e) => (e.currentTarget.style.background = ds.subBg2)}
                          onMouseLeave={(e) => (e.currentTarget.style.background = ds.subBg)}>
                          <Download size={12}/>
                        </button>
                        <RowMenu inv={inv} onDelete={handleDelete} ds={ds}/>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>

          <div className="flex items-center justify-between px-5 py-4" style={{ borderTop: `1px solid ${ds.divider}` }}>
            <p className="text-xs" style={{ color: ds.textMuted }}>{filtered.length} invoices · page {page} of {totalPages}</p>
            <div className="flex gap-1">
              <button onClick={() => setPage((p) => Math.max(1,p-1))} disabled={page===1}
                className="w-7 h-7 rounded-lg text-xs font-medium transition-all"
                style={{ background: ds.subBg, color: page===1 ? ds.textMuted : ds.textSecondary }}>‹</button>
              {Array.from({length:totalPages},(_,i)=>i+1).map((p) => (
                <button key={p} onClick={() => setPage(p)}
                  className="w-7 h-7 rounded-lg text-xs font-medium transition-all"
                  style={p===page ? { background:"linear-gradient(90deg,#22c55e,#06b6d4)",color:"white" } : { background:ds.subBg,color:ds.textSecondary }}>
                  {p}
                </button>
              ))}
              <button onClick={() => setPage((p) => Math.min(totalPages,p+1))} disabled={page===totalPages}
                className="w-7 h-7 rounded-lg text-xs font-medium transition-all"
                style={{ background: ds.subBg, color: page===totalPages ? ds.textMuted : ds.textSecondary }}>›</button>
            </div>
          </div>
        </div>
      </main>

      {newOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setNewOpen(false)}/>
          <div className="relative rounded-2xl w-full max-w-md mx-4 p-6"
            style={{ background: ds.card, border: `1px solid ${ds.border}`, boxShadow: "0 20px 60px rgba(0,0,0,0.3)" }}>
            <div className="flex items-center justify-between mb-5">
              <p className="text-base font-semibold" style={{ color: ds.textPrimary }}>New Invoice</p>
              <button onClick={() => setNewOpen(false)} style={{ color: ds.textMuted }}><X size={18}/></button>
            </div>
            <form onSubmit={handleNew} className="flex flex-col gap-3">
              {[
                { label:"Client Name *", key:"client",  type:"text",   placeholder:"Acme Corp"          },
                { label:"Email",         key:"email",   type:"email",  placeholder:"billing@acme.com"   },
                { label:"Project *",     key:"project", type:"text",   placeholder:"Project description" },
                { label:"Amount *",      key:"amount",  type:"number", placeholder:"5000"               },
                { label:"Due Date",      key:"due",     type:"date",   placeholder:""                   },
              ].map(({ label, key, type, placeholder }) => (
                <div key={key}>
                  <label className="text-xs font-medium mb-1 block" style={{ color: ds.textMuted }}>{label}</label>
                  <input type={type} placeholder={placeholder} value={form[key as keyof typeof form]}
                    onChange={(e) => setForm((p) => ({ ...p, [key]: e.target.value }))}
                    style={inputStyle}
                    onFocus={(e) => (e.currentTarget.style.borderColor = "#06b6d4")}
                    onBlur={(e)  => (e.currentTarget.style.borderColor = ds.inputBorder)}/>
                </div>
              ))}
              <div className="flex gap-3 mt-2">
                <button type="button" onClick={() => setNewOpen(false)}
                  className="flex-1 py-2.5 rounded-xl text-sm font-medium transition-colors"
                  style={{ background: ds.subBg, color: ds.textSecondary }}>Cancel</button>
                <button type="submit" className="flex-1 py-2.5 rounded-xl text-sm font-medium text-white"
                  style={{ background: "linear-gradient(90deg,#22c55e,#06b6d4)" }}>Create Invoice</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
