import { useState } from "react";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend,
} from "recharts";
import { TrendingUp, TrendingDown, Target, Activity, AlertTriangle, Trophy } from "lucide-react";
import { PageHeader } from "../components/PageHeader";
import { useDS } from "../context/ThemeContext";
import type { BarShapeProps } from "../types/recharts";

/* ── mock data ──────────────────────────────────────────────────────── */
const eqCurve = [
  {d:"Jan W1",v:100000},{d:"Jan W2",v:103200},{d:"Jan W3",v:101800},{d:"Jan W4",v:105400},
  {d:"Feb W1",v:108100},{d:"Feb W2",v:104900},{d:"Feb W3",v:111300},{d:"Feb W4",v:115700},
  {d:"Mar W1",v:112400},{d:"Mar W2",v:118900},{d:"Mar W3",v:122100},{d:"Mar W4",v:148250},
];

const monthlyPnl = [
  {m:"Jan",v:5400, trades:62},{m:"Feb",v:-2100,trades:54},{m:"Mar",v:3800,trades:48},
  {m:"Apr",v:8100, trades:71},{m:"May",v:-1400,trades:41},{m:"Jun",v:6200,trades:58},
  {m:"Jul",v:4300, trades:49},{m:"Aug",v:11200,trades:83},{m:"Sep",v:-800, trades:36},
  {m:"Oct",v:9400, trades:76},{m:"Nov",v:3100, trades:45},{m:"Dec",v:12100,trades:89},
];

const drawdown = [
  {d:"Jan",dd:0},{d:"Feb W1",dd:-1.2},{d:"Feb W2",dd:-4.8},{d:"Feb W3",dd:-2.1},
  {d:"Mar W1",dd:-5.4},{d:"Mar W2",dd:-2.8},{d:"Mar W3",dd:0},{d:"Mar W4",dd:0},
  {d:"Apr",dd:-0.8},{d:"May",dd:-6.2},{d:"Jun",dd:-3.1},{d:"Jul",dd:0},
];

const symbolPerf = [
  {sym:"BTC",wins:28,losses:10,pnl:18420},
  {sym:"ETH",wins:22,losses:14,pnl:9340 },
  {sym:"SOL",wins:19,losses:8, pnl:7180 },
  {sym:"BNB",wins:14,losses:12,pnl:2340 },
  {sym:"LINK",wins:10,losses:11,pnl:-820},
];

const wlData = [
  { name:"Wins",  value:234, color:"#22c55e" },
  { name:"Losses",value:108, color:"#ef4444" },
];

type Period = "1M"|"3M"|"6M"|"1Y";

const metricCards = [
  { label:"ROI",           icon:TrendingUp,    value:"+48.25%",   sub:"since inception",     color:"#22c55e" },
  { label:"Net Profit",    icon:Trophy,        value:"+$48,250",  sub:"on $100k capital",    color:"#06b6d4" },
  { label:"Total Trades",  icon:Activity,      value:"342",       sub:"last 12 months",      color:"#8b5cf6" },
  { label:"Win Rate",      icon:Target,        value:"68.4%",     sub:"234W / 108L",         color:"#f59e0b" },
  { label:"Max Drawdown",  icon:AlertTriangle, value:"-6.2%",     sub:"May 2026",            color:"#ef4444" },
  { label:"Avg Win/Loss",  icon:TrendingDown,  value:"2.3:1",     sub:"reward:risk ratio",   color:"#22c55e" },
];

export function AnalyticsPage() {
  const ds = useDS();
  const [period, setPeriod] = useState<Period>("1Y");

  const sliceData = (arr: typeof eqCurve) => {
    if (period === "1M") return arr.slice(-4);
    if (period === "3M") return arr.slice(-6);
    if (period === "6M") return arr.slice(-8);
    return arr;
  };

  return (
    <>
      <PageHeader title="Analytics" />
      <main className="flex-1 px-6 pb-8 overflow-auto page-enter">

        {/* Metric cards */}
        <div className="grid grid-cols-6 gap-3 mb-5">
          {metricCards.map(({ label, icon:Icon, value, sub, color }) => (
            <div key={label} className="rounded-2xl px-4 py-4 transition-colors duration-300"
              style={{ background: ds.card, boxShadow: ds.cardShadow }}>
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs" style={{ color: ds.textMuted }}>{label}</p>
                <div className="w-7 h-7 rounded-lg flex items-center justify-center"
                  style={{ background: color + (ds.isDark ? "22" : "15") }}>
                  <Icon size={13} style={{ color }}/>
                </div>
              </div>
              <p className="text-lg font-semibold" style={{ color }}>{value}</p>
              <p className="text-xs mt-0.5" style={{ color: ds.textMuted }}>{sub}</p>
            </div>
          ))}
        </div>

        {/* Equity curve + Win/Loss donut */}
        <div className="flex gap-5 mb-5">
          <div className="rounded-2xl p-5 flex-1 min-w-0 transition-colors duration-300"
            style={{ background: ds.card, boxShadow: ds.cardShadow }}>
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-sm font-semibold" style={{ color: ds.textPrimary }}>Equity Curve</p>
                <p className="text-xs" style={{ color: ds.textMuted }}>Virtual portfolio value over time</p>
              </div>
              <div className="flex gap-1">
                {(["1M","3M","6M","1Y"] as Period[]).map((t) => (
                  <button key={t} onClick={() => setPeriod(t)}
                    className="text-xs px-2.5 py-1 rounded-lg transition-all"
                    style={period === t
                      ? { background: "linear-gradient(90deg,#22c55e,#06b6d4)", color: "white" }
                      : { background: ds.subBg, color: ds.textMuted }}>
                    {t}
                  </button>
                ))}
              </div>
            </div>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={sliceData(eqCurve)}>
                <defs>
                  <linearGradient id="eqFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#22c55e" stopOpacity={ds.isDark ? 0.3 : 0.15}/>
                    <stop offset="100%" stopColor="#06b6d4" stopOpacity={0.01}/>
                  </linearGradient>
                  <linearGradient id="eqLine" x1="0" y1="0" x2="1" y2="0">
                    <stop stopColor="#22c55e"/><stop offset="1" stopColor="#06b6d4"/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke={ds.isDark ? "rgba(255,255,255,0.05)" : "#f0f0f5"} vertical={false}/>
                <XAxis dataKey="d" tick={{ fontSize: 10, fill: ds.textMuted }} axisLine={false} tickLine={false}/>
                <YAxis tick={{ fontSize: 10, fill: ds.textMuted }} axisLine={false} tickLine={false}
                  tickFormatter={(v) => `$${(v/1000).toFixed(0)}k`}/>
                <Tooltip
                  contentStyle={{ borderRadius: 10, border: "none", fontSize: 12, background: ds.card, boxShadow: "0 4px 20px rgba(0,0,0,0.16)", color: ds.textPrimary }}
                  formatter={(v: number) => [`$${v.toLocaleString()}`, "Portfolio"]}
                />
                <Area type="monotone" dataKey="v" stroke="url(#eqLine)" strokeWidth={2.5} fill="url(#eqFill)" dot={false}/>
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Win / Loss donut */}
          <div className="rounded-2xl p-5 w-64 shrink-0 transition-colors duration-300"
            style={{ background: ds.card, boxShadow: ds.cardShadow }}>
            <p className="text-sm font-semibold mb-1" style={{ color: ds.textPrimary }}>Win / Loss Ratio</p>
            <p className="text-xs mb-4" style={{ color: ds.textMuted }}>342 total trades</p>
            <div className="flex justify-center">
              <PieChart width={150} height={150}>
                <Pie data={wlData} cx={70} cy={70} innerRadius={42} outerRadius={68} dataKey="value" strokeWidth={0}>
                  {wlData.map((e, i) => <Cell key={i} fill={e.color}/>)}
                </Pie>
              </PieChart>
            </div>
            <Legend
              payload={wlData.map((e) => ({ value: `${e.name}: ${e.value}`, color: e.color, type:"circle" as const }))}
              iconSize={8} wrapperStyle={{ fontSize: 11, color: ds.textSecondary, marginTop: 4 }}
            />
            <div className="mt-3 pt-3 grid grid-cols-2 gap-2" style={{ borderTop: `1px solid ${ds.divider}` }}>
              <div>
                <p className="text-xs" style={{ color: ds.textMuted }}>Win Rate</p>
                <p className="text-base font-semibold" style={{ color: "#22c55e" }}>68.4%</p>
              </div>
              <div>
                <p className="text-xs" style={{ color: ds.textMuted }}>Avg Win</p>
                <p className="text-base font-semibold" style={{ color: "#06b6d4" }}>$412</p>
              </div>
            </div>
          </div>
        </div>

        {/* Monthly P&L + Drawdown */}
        <div className="flex gap-5 mb-5">
          <div className="rounded-2xl p-5 flex-1 min-w-0 transition-colors duration-300"
            style={{ background: ds.card, boxShadow: ds.cardShadow }}>
            <p className="text-sm font-semibold mb-1" style={{ color: ds.textPrimary }}>Monthly Performance</p>
            <p className="text-xs mb-4" style={{ color: ds.textMuted }}>Realised P&L per month</p>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={monthlyPnl}>
                <CartesianGrid strokeDasharray="3 3" stroke={ds.isDark ? "rgba(255,255,255,0.05)" : "#f0f0f5"} vertical={false}/>
                <XAxis dataKey="m" tick={{ fontSize: 10, fill: ds.textMuted }} axisLine={false} tickLine={false}/>
                <YAxis tick={{ fontSize: 10, fill: ds.textMuted }} axisLine={false} tickLine={false}
                  tickFormatter={(v) => v >= 0 ? `+$${(v/1000).toFixed(0)}k` : `-$${Math.abs(v/1000).toFixed(0)}k`}/>
                <Tooltip
                  contentStyle={{ borderRadius: 10, border: "none", fontSize: 12, background: ds.card, boxShadow: "0 4px 20px rgba(0,0,0,0.16)", color: ds.textPrimary }}
                  formatter={(v: number) => [`${v >= 0 ? "+" : ""}$${v.toLocaleString()}`, "P&L"]}
                />
                <Bar dataKey="v" radius={[4,4,0,0]}
                  fill="transparent"
                  shape={(props: BarShapeProps) => {
                    const { x, y, width, height, value } = props;
                    const h = Math.abs(height as number);
                    return <rect x={x} y={(value as number) >= 0 ? y : y - h} width={width} height={h}
                      fill={(value as number) >= 0 ? "#22c55e" : "#ef4444"} fillOpacity={0.85} rx={3} ry={3}/>;
                  }}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="rounded-2xl p-5 flex-1 min-w-0 transition-colors duration-300"
            style={{ background: ds.card, boxShadow: ds.cardShadow }}>
            <p className="text-sm font-semibold mb-1" style={{ color: ds.textPrimary }}>Drawdown Chart</p>
            <p className="text-xs mb-4" style={{ color: ds.textMuted }}>Peak-to-trough decline percentage</p>
            <ResponsiveContainer width="100%" height={180}>
              <AreaChart data={drawdown}>
                <defs>
                  <linearGradient id="ddFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#ef4444" stopOpacity={ds.isDark ? 0.4 : 0.25}/>
                    <stop offset="100%" stopColor="#ef4444" stopOpacity={0.02}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke={ds.isDark ? "rgba(255,255,255,0.05)" : "#f0f0f5"} vertical={false}/>
                <XAxis dataKey="d" tick={{ fontSize: 10, fill: ds.textMuted }} axisLine={false} tickLine={false}/>
                <YAxis tick={{ fontSize: 10, fill: ds.textMuted }} axisLine={false} tickLine={false}
                  tickFormatter={(v) => `${v}%`}/>
                <Tooltip
                  contentStyle={{ borderRadius: 10, border: "none", fontSize: 12, background: ds.card, boxShadow: "0 4px 20px rgba(0,0,0,0.16)", color: ds.textPrimary }}
                  formatter={(v: number) => [`${v}%`, "Drawdown"]}
                />
                <Area type="monotone" dataKey="dd" stroke="#ef4444" strokeWidth={2} fill="url(#ddFill)" dot={false}/>
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Per-symbol performance */}
        <div className="rounded-2xl overflow-hidden transition-colors duration-300"
          style={{ background: ds.card, boxShadow: ds.cardShadow }}>
          <div className="px-5 pt-5 pb-3">
            <p className="text-sm font-semibold" style={{ color: ds.textPrimary }}>Performance by Asset</p>
            <p className="text-xs mt-0.5" style={{ color: ds.textMuted }}>Breakdown of trades per symbol</p>
          </div>
          <table className="w-full text-sm">
            <thead>
              <tr style={{ background: ds.subBg }}>
                {["Symbol","Wins","Losses","Win Rate","Net P&L",""].map((h) => (
                  <th key={h} className="text-left text-xs font-medium px-5 py-3" style={{ color: ds.textMuted }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {symbolPerf.map((s) => {
                const total = s.wins + s.losses;
                const wr    = Math.round((s.wins / total) * 100);
                return (
                  <tr key={s.sym} className="transition-colors"
                    style={{ borderTop: `1px solid ${ds.divider}` }}
                    onMouseEnter={(e) => (e.currentTarget.style.background = ds.hoverBg)}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}>
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-xl flex items-center justify-center text-white text-xs font-bold shrink-0"
                          style={{ background: "linear-gradient(135deg,#1a1a2e,#0f3460)" }}>{s.sym[0]}</div>
                        <span className="text-sm font-semibold" style={{ color: ds.textPrimary }}>{s.sym}</span>
                      </div>
                    </td>
                    <td className="px-5 py-4 text-sm font-semibold" style={{ color: "#22c55e" }}>{s.wins}</td>
                    <td className="px-5 py-4 text-sm font-semibold" style={{ color: "#ef4444" }}>{s.losses}</td>
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-20 h-1.5 rounded-full overflow-hidden" style={{ background: ds.subBg2 }}>
                          <div className="h-full rounded-full" style={{ width: `${wr}%`, background: wr >= 60 ? "#22c55e" : wr >= 50 ? "#f59e0b" : "#ef4444" }}/>
                        </div>
                        <span className="text-xs font-medium" style={{ color: ds.textSecondary }}>{wr}%</span>
                      </div>
                    </td>
                    <td className="px-5 py-4">
                      <span className="text-sm font-semibold" style={{ color: s.pnl >= 0 ? "#22c55e" : "#ef4444" }}>
                        {s.pnl >= 0 ? "+" : ""}${s.pnl.toLocaleString()}
                      </span>
                    </td>
                    <td className="px-5 py-4">
                      <span className="text-xs px-2 py-0.5 rounded-full"
                        style={s.pnl >= 0
                          ? { background: ds.isDark ? "rgba(34,197,94,0.15)"  : "#dcfce7", color: "#16a34a" }
                          : { background: ds.isDark ? "rgba(239,68,68,0.15)"  : "#fee2e2", color: "#dc2626" }}>
                        {s.pnl >= 0 ? "Profitable" : "Losing"}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </main>
    </>
  );
}