import { useState, useMemo } from "react";
import { useNavigate } from "react-router";
import { TrendingUp, TrendingDown, Flame, Star, Zap, Globe, Search } from "lucide-react";
import { AreaChart, Area, ResponsiveContainer } from "recharts";
import { PageHeader } from "../components/PageHeader";
import { useDS } from "../context/ThemeContext";

const makeSpark = (seed: number, up: boolean) =>
  Array.from({ length: 12 }, (_, i) => ({ i, v: 50 + Math.sin((i + seed) * 0.8) * 15 + (up ? i * 1.5 : -i * 1.2) }));

const trending = [
  { rank:1, symbol:"SOL",  name:"Solana",    price:"$178.42", cap:"$76.2B", vol:"$4.1B", change:"+5.67%", up:true,  spark:makeSpark(1,true),  cat:"Layer 1" },
  { rank:2, symbol:"AVAX", name:"Avalanche", price:"$38.91",  cap:"$15.8B", vol:"$812M", change:"+4.12%", up:true,  spark:makeSpark(2,true),  cat:"Layer 1" },
  { rank:3, symbol:"ARB",  name:"Arbitrum",  price:"$1.24",   cap:"$3.9B",  vol:"$421M", change:"+3.88%", up:true,  spark:makeSpark(3,true),  cat:"Layer 2" },
  { rank:4, symbol:"INJ",  name:"Injective", price:"$24.72",  cap:"$2.3B",  vol:"$318M", change:"+3.21%", up:true,  spark:makeSpark(4,true),  cat:"DeFi"   },
  { rank:5, symbol:"OP",   name:"Optimism",  price:"$2.85",   cap:"$3.1B",  vol:"$294M", change:"+2.74%", up:true,  spark:makeSpark(5,true),  cat:"Layer 2" },
];
const gainers = [
  { rank:1, symbol:"PEPE",  name:"Pepe",      price:"$0.0000148", cap:"—", vol:"—", change:"+22.4%", up:true,  spark:makeSpark(10,true),  cat:"Meme Coins" },
  { rank:2, symbol:"WIF",   name:"dogwifhat", price:"$2.84",      cap:"—", vol:"—", change:"+18.7%", up:true,  spark:makeSpark(11,true),  cat:"Meme Coins" },
  { rank:3, symbol:"BONK",  name:"Bonk",      price:"$0.0000312", cap:"—", vol:"—", change:"+14.2%", up:true,  spark:makeSpark(12,true),  cat:"Meme Coins" },
  { rank:4, symbol:"FLOKI", name:"Floki",     price:"$0.000198",  cap:"—", vol:"—", change:"+11.8%", up:true,  spark:makeSpark(13,true),  cat:"Meme Coins" },
];
const losers = [
  { rank:1, symbol:"MATIC", name:"Polygon",  price:"$0.89",  cap:"—", vol:"—", change:"-8.3%", up:false, spark:makeSpark(20,false), cat:"Layer 2" },
  { rank:2, symbol:"DOT",   name:"Polkadot", price:"$7.81",  cap:"—", vol:"—", change:"-6.7%", up:false, spark:makeSpark(21,false), cat:"Layer 1" },
  { rank:3, symbol:"XRP",   name:"Ripple",   price:"$0.542", cap:"—", vol:"—", change:"-4.9%", up:false, spark:makeSpark(22,false), cat:"Layer 1" },
  { rank:4, symbol:"ADA",   name:"Cardano",  price:"$0.485", cap:"—", vol:"—", change:"-3.8%", up:false, spark:makeSpark(23,false), cat:"Layer 1" },
];
const newListings = [
  { rank:1, symbol:"EIGEN", name:"EigenLayer", price:"$3.21", cap:"$1.2B", vol:"$184M", change:"+8.4%", up:true, spark:makeSpark(30,true), cat:"DeFi"   },
  { rank:2, symbol:"ZETA",  name:"ZetaChain",  price:"$0.84", cap:"$580M", vol:"$92M",  change:"+5.1%", up:true, spark:makeSpark(31,true), cat:"Layer 1" },
  { rank:3, symbol:"SAGA",  name:"Saga",       price:"$1.47", cap:"$420M", vol:"$67M",  change:"+3.7%", up:true, spark:makeSpark(32,true), cat:"Layer 1" },
];

const categories = [
  { name:"All",        count:"350 tokens", change:"+2.4%", up:true,  color:"#06b6d4" },
  { name:"DeFi",       count:"142 tokens", change:"+3.2%", up:true,  color:"#22c55e" },
  { name:"Layer 1",    count:"38 tokens",  change:"+1.8%", up:true,  color:"#8b5cf6" },
  { name:"Layer 2",    count:"29 tokens",  change:"+2.4%", up:true,  color:"#f59e0b" },
  { name:"Meme Coins", count:"87 tokens",  change:"+9.1%", up:true,  color:"#ef4444" },
  { name:"GameFi",     count:"64 tokens",  change:"-1.2%", up:false, color:"#9ca3af" },
  { name:"AI Tokens",  count:"31 tokens",  change:"+5.6%", up:true,  color:"#3b82f6" },
];

const TABS = ["Trending","Gainers","Losers","New Listings"] as const;
type TabType = typeof TABS[number];
const tabData: Record<TabType, typeof trending> = { "Trending":trending,"Gainers":gainers,"Losers":losers,"New Listings":newListings };

export function DiscoverPage() {
  const navigate = useNavigate();
  const ds = useDS();
  const [tab, setTab]           = useState<TabType>("Trending");
  const [search, setSearch]     = useState("");
  const [activeCat, setActiveCat] = useState("All");

  const coins = useMemo(() => {
    let list = tabData[tab];
    if (activeCat !== "All") list = list.filter((c) => c.cat === activeCat);
    if (search.trim()) { const q = search.toLowerCase(); list = list.filter((c) => c.symbol.toLowerCase().includes(q) || c.name.toLowerCase().includes(q)); }
    return list;
  }, [tab, search, activeCat]);

  return (
    <>
      <PageHeader title="Discover" />
      <main className="flex-1 px-6 pb-8 overflow-auto">

        {/* Search hero */}
        <div className="rounded-2xl p-6 mb-5 relative overflow-hidden text-white"
          style={{ background: "linear-gradient(135deg, #1a1a2e 0%, #0f3460 60%, #16213e 100%)" }}>
          <div className="absolute inset-0 opacity-10" style={{ backgroundImage: "radial-gradient(circle at 70% 50%, #06b6d4, transparent 60%)" }}/>
          <p className="text-xl font-semibold mb-1 relative">Explore the Market</p>
          <p className="text-sm mb-4 relative" style={{ color: "#94a3b8" }}>Discover trending tokens, top gainers, and emerging projects.</p>
          <div className="flex items-center gap-2 backdrop-blur rounded-xl px-4 py-3 w-full max-w-md relative"
            style={{ background: "rgba(255,255,255,0.1)" }}>
            <Search size={15} style={{ color: "#94a3b8" }} className="shrink-0"/>
            <input value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="Search tokens, projects…"
              className="bg-transparent outline-none text-sm flex-1 text-white placeholder-slate-400"/>
          </div>
          <div className="flex gap-6 mt-4 relative">
            {[{ label:"Market Cap",value:"$2.41T",icon:Globe },{ label:"24h Volume",value:"$98.2B",icon:Zap },{ label:"BTC Dominance",value:"52.4%",icon:Star }].map(({ label, value, icon: Icon }) => (
              <div key={label} className="flex items-center gap-2">
                <Icon size={14} style={{ color: "#94a3b8" }}/>
                <span className="text-xs" style={{ color: "#94a3b8" }}>{label}</span>
                <span className="text-sm font-semibold">{value}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="flex gap-5">
          {/* Main table */}
          <div className="rounded-2xl flex-1 min-w-0 overflow-hidden transition-colors duration-300"
            style={{ background: ds.card, boxShadow: ds.cardShadow }}>
            <div className="flex items-center gap-1 px-5 pt-4 pb-3">
              {TABS.map((t) => (
                <button key={t} onClick={() => { setTab(t); setActiveCat("All"); }}
                  className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl text-sm transition-all"
                  style={tab === t ? { background: "linear-gradient(90deg,#22c55e,#06b6d4)", color: "white" } : { color: ds.textMuted }}>
                  {t === "Trending"     && <Flame size={13}/>}
                  {t === "Gainers"      && <TrendingUp size={13}/>}
                  {t === "Losers"       && <TrendingDown size={13}/>}
                  {t === "New Listings" && <Zap size={13}/>}
                  {t}
                </button>
              ))}
            </div>
            <table className="w-full text-sm">
              <thead>
                <tr style={{ background: ds.subBg }}>
                  {["#","Name","Price","Market Cap","Volume 24h","Change","7d"].map((h) => (
                    <th key={h} className="text-left text-xs font-medium px-5 py-2.5" style={{ color: ds.textMuted }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {coins.length === 0 ? (
                  <tr><td colSpan={7} className="text-center py-12 text-sm" style={{ color: ds.textMuted }}>No tokens found</td></tr>
                ) : (
                  coins.map((coin, i) => (
                    <tr key={coin.symbol} onClick={() => navigate("/trade")}
                      className="transition-colors cursor-pointer" style={{ borderTop: `1px solid ${ds.divider}` }}
                      onMouseEnter={(e) => (e.currentTarget.style.background = ds.hoverBg)}
                      onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}>
                      <td className="px-5 py-3.5 text-xs" style={{ color: ds.textMuted }}>{i+1}</td>
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-xl flex items-center justify-center text-white text-xs font-bold shrink-0"
                            style={{ background: "linear-gradient(135deg,#1a1a2e,#0f3460)" }}>{coin.symbol[0]}</div>
                          <div>
                            <p className="text-sm font-semibold" style={{ color: ds.textPrimary }}>{coin.symbol}</p>
                            <p className="text-xs" style={{ color: ds.textMuted }}>{coin.name}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-3.5 text-sm font-medium" style={{ color: ds.textPrimary }}>{coin.price}</td>
                      <td className="px-5 py-3.5 text-xs" style={{ color: ds.textMuted }}>{coin.cap}</td>
                      <td className="px-5 py-3.5 text-xs" style={{ color: ds.textMuted }}>{coin.vol}</td>
                      <td className="px-5 py-3.5">
                        <span className="flex items-center gap-1 text-xs font-semibold" style={{ color: coin.up ? "#22c55e" : "#ef4444" }}>
                          {coin.up ? <TrendingUp size={11}/> : <TrendingDown size={11}/>}{coin.change}
                        </span>
                      </td>
                      <td className="px-5 py-3.5">
                        <ResponsiveContainer width={70} height={32}>
                          <AreaChart data={coin.spark}>
                            <defs>
                              <linearGradient id={`dg${coin.symbol}`} x1="0" y1="0" x2="0" y2="1">
                                <stop offset="0%" stopColor={coin.up ? "#22c55e" : "#ef4444"} stopOpacity={0.2}/>
                                <stop offset="100%" stopColor={coin.up ? "#22c55e" : "#ef4444"} stopOpacity={0}/>
                              </linearGradient>
                            </defs>
                            <Area type="monotone" dataKey="v" stroke={coin.up ? "#22c55e" : "#ef4444"}
                              strokeWidth={1.5} fill={`url(#dg${coin.symbol})`} dot={false}/>
                          </AreaChart>
                        </ResponsiveContainer>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Sidebar */}
          <div className="w-60 shrink-0 flex flex-col gap-4">
            <div className="rounded-2xl p-5 transition-colors duration-300" style={{ background: ds.card, boxShadow: ds.cardShadow }}>
              <p className="text-sm font-semibold mb-3" style={{ color: ds.textPrimary }}>Categories</p>
              <div className="flex flex-col gap-1">
                {categories.map((cat) => (
                  <button key={cat.name} onClick={() => setActiveCat(cat.name)}
                    className="flex items-center justify-between px-3 py-2.5 rounded-xl transition-all text-left"
                    style={activeCat === cat.name
                      ? { background: ds.isDark ? "rgba(6,182,212,0.1)" : "rgba(6,182,212,0.06)", borderLeft: "3px solid #06b6d4" }
                      : { borderLeft: "3px solid transparent" }}
                    onMouseEnter={(e) => { if (activeCat !== cat.name) (e.currentTarget as HTMLElement).style.background = ds.hoverBg; }}
                    onMouseLeave={(e) => { if (activeCat !== cat.name) (e.currentTarget as HTMLElement).style.background = "transparent"; }}>
                    <div className="flex items-center gap-2.5">
                      <span className="w-2 h-2 rounded-full shrink-0" style={{ background: cat.color }}/>
                      <div>
                        <p className="text-sm" style={{ color: ds.textSecondary }}>{cat.name}</p>
                        <p className="text-xs" style={{ color: ds.textMuted }}>{cat.count}</p>
                      </div>
                    </div>
                    <span className="text-xs font-semibold" style={{ color: cat.up ? "#22c55e" : "#ef4444" }}>{cat.change}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Fear & Greed */}
            <div className="rounded-2xl p-5 transition-colors duration-300" style={{ background: ds.card, boxShadow: ds.cardShadow }}>
              <p className="text-sm font-semibold mb-3" style={{ color: ds.textPrimary }}>Fear & Greed</p>
              <div className="flex flex-col items-center gap-2">
                <div className="w-20 h-20 rounded-full flex items-center justify-center"
                  style={{ background: "conic-gradient(#22c55e 0% 72%, rgba(107,114,128,0.3) 72% 100%)", boxShadow: `0 0 0 6px ${ds.card} inset` }}>
                  <div className="w-14 h-14 rounded-full flex flex-col items-center justify-center"
                    style={{ background: ds.card }}>
                    <span className="text-xl font-bold" style={{ color: ds.textPrimary }}>72</span>
                    <span className="text-xs" style={{ color: ds.textMuted }}>Greed</span>
                  </div>
                </div>
                <p className="text-xs text-center" style={{ color: ds.textMuted }}>Market sentiment is bullish</p>
                <div className="w-full flex justify-between text-xs" style={{ color: ds.textMuted }}>
                  <span>Fear</span><span>Greed</span>
                </div>
                <div className="w-full h-1.5 rounded-full overflow-hidden" style={{ background: ds.subBg }}>
                  <div className="h-full rounded-full w-[72%]"
                    style={{ background: "linear-gradient(90deg,#ef4444,#f59e0b,#22c55e)" }}/>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </>
  );
}
