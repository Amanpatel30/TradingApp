import { useParams, useNavigate } from "react-router";
import { ArrowLeft, TrendingUp, TrendingDown } from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import { PageHeader } from "../components/PageHeader";
import { useDS } from "../context/ThemeContext";

/* ── per-asset mock data ────────────────────────────────────────────── */
const ASSET_DATA: Record<string, {
  name: string; price: number; change: number; qty: number; avgBuy: number;
  color: string; icon: string;
  chart1D: { t: string; p: number }[];
  trades: { id: string; side: "Buy" | "Sell"; qty: number; price: number; pnl: number; date: string }[];
}> = {
  BTC: {
    name: "Bitcoin", price: 67482, change: 2.34, qty: 0.4821, avgBuy: 54200,
    color: "#f59e0b", icon: "₿",
    chart1D: [
      { t: "00:00", p: 64200 }, { t: "02:00", p: 63800 }, { t: "04:00", p: 64900 },
      { t: "06:00", p: 65400 }, { t: "08:00", p: 66100 }, { t: "10:00", p: 65700 },
      { t: "12:00", p: 66800 }, { t: "14:00", p: 67100 }, { t: "16:00", p: 67482 },
      { t: "18:00", p: 67200 }, { t: "20:00", p: 67600 }, { t: "22:00", p: 67482 },
    ],
    trades: [
      { id: "T-001", side: "Buy",  qty: 0.10, price: 52100, pnl: 1538,  date: "2025-11-10" },
      { id: "T-002", side: "Buy",  qty: 0.15, price: 55400, pnl: 1812,  date: "2025-12-02" },
      { id: "T-003", side: "Sell", qty: 0.05, price: 61200, pnl: 454,   date: "2026-01-15" },
      { id: "T-004", side: "Buy",  qty: 0.20, price: 58900, pnl: 1716,  date: "2026-02-08" },
      { id: "T-005", side: "Buy",  qty: 0.0821,price:54200, pnl: 1090,  date: "2026-03-01" },
    ],
  },
  ETH: {
    name: "Ethereum", price: 3521, change: -1.12, qty: 3.2, avgBuy: 2800,
    color: "#8b5cf6", icon: "Ξ",
    chart1D: [
      { t: "00:00", p: 3480 }, { t: "02:00", p: 3450 }, { t: "04:00", p: 3510 },
      { t: "06:00", p: 3560 }, { t: "08:00", p: 3590 }, { t: "10:00", p: 3540 },
      { t: "12:00", p: 3570 }, { t: "14:00", p: 3610 }, { t: "16:00", p: 3521 },
      { t: "18:00", p: 3490 }, { t: "20:00", p: 3530 }, { t: "22:00", p: 3521 },
    ],
    trades: [
      { id: "T-010", side: "Buy",  qty: 1.5,  price: 2650, pnl: 1307, date: "2025-10-20" },
      { id: "T-011", side: "Buy",  qty: 1.0,  price: 2900, pnl: 621,  date: "2025-12-18" },
      { id: "T-012", side: "Buy",  qty: 0.7,  price: 3100, pnl: 295,  date: "2026-01-30" },
    ],
  },
  SOL: {
    name: "Solana", price: 178.42, change: 5.67, qty: 42, avgBuy: 130,
    color: "#06b6d4", icon: "◎",
    chart1D: [
      { t: "00:00", p: 155 }, { t: "02:00", p: 158 }, { t: "04:00", p: 162 },
      { t: "06:00", p: 160 }, { t: "08:00", p: 165 }, { t: "10:00", p: 170 },
      { t: "12:00", p: 168 }, { t: "14:00", p: 174 }, { t: "16:00", p: 178 },
      { t: "18:00", p: 176 }, { t: "20:00", p: 180 }, { t: "22:00", p: 178 },
    ],
    trades: [
      { id: "T-020", side: "Buy",  qty: 20, price: 120, pnl: 1169, date: "2025-11-05" },
      { id: "T-021", side: "Buy",  qty: 15, price: 138, pnl:  606, date: "2026-01-12" },
      { id: "T-022", side: "Buy",  qty: 7,  price: 142, pnl:  254, date: "2026-02-20" },
    ],
  },
  BNB: {
    name: "BNB", price: 592.30, change: 0.88, qty: 5.5, avgBuy: 480,
    color: "#f59e0b", icon: "B",
    chart1D: [
      { t: "00:00", p: 575 }, { t: "04:00", p: 580 }, { t: "08:00", p: 578 },
      { t: "12:00", p: 585 }, { t: "16:00", p: 592 }, { t: "20:00", p: 590 },
    ],
    trades: [
      { id: "T-030", side: "Buy", qty: 3, price: 470, pnl: 366, date: "2025-12-10" },
      { id: "T-031", side: "Buy", qty: 2.5, price: 492, pnl: 251, date: "2026-02-01" },
    ],
  },
};

export function PortfolioDetailPage() {
  const { symbol = "BTC" } = useParams<{ symbol: string }>();
  const navigate = useNavigate();
  const ds = useDS();

  const asset = ASSET_DATA[symbol.toUpperCase()] ?? ASSET_DATA["BTC"];
  const sym   = symbol.toUpperCase();
  const pnl   = (asset.price - asset.avgBuy) * asset.qty;
  const pnlPct = ((asset.price - asset.avgBuy) / asset.avgBuy) * 100;
  const value  = asset.price * asset.qty;
  const isUp   = asset.change >= 0;

  return (
    <>
      <PageHeader title={`${asset.name} (${sym})`} />
      <main className="flex-1 px-6 pb-8 overflow-auto">

        {/* Back button */}
        <button
          onClick={() => navigate("/wallet")}
          className="flex items-center gap-1.5 mb-5 hover:opacity-70 transition-opacity"
          style={{ fontSize: 13, fontWeight: 600, color: ds.textSecondary }}
        >
          <ArrowLeft size={15}/> Back to Wallet
        </button>

        {/* Header stats */}
        <div className="grid grid-cols-4 gap-4 mb-5">
          {[
            { label: "Current Price",   value: `$${asset.price.toLocaleString()}`,                  color: ds.textPrimary  },
            { label: "24h Change",      value: `${isUp ? "+" : ""}${asset.change}%`,                color: isUp ? "#22c55e" : "#ef4444" },
            { label: "Holdings Value",  value: `$${value.toLocaleString("en-US", { maximumFractionDigits: 2 })}`, color: ds.textPrimary },
            { label: "Unrealised P&L",  value: `${pnl >= 0 ? "+" : ""}$${pnl.toLocaleString("en-US", { maximumFractionDigits: 2 })} (${pnlPct.toFixed(2)}%)`, color: pnl >= 0 ? "#22c55e" : "#ef4444" },
          ].map(({ label, value, color }) => (
            <div key={label} className="rounded-2xl p-5 transition-colors duration-300"
              style={{ background: ds.card, boxShadow: ds.cardShadow }}>
              <p className="text-xs mb-1" style={{ color: ds.textMuted }}>{label}</p>
              <p className="font-semibold" style={{ color, fontSize: "1.1rem" }}>{value}</p>
            </div>
          ))}
        </div>

        {/* Chart */}
        <div className="rounded-2xl p-5 mb-5 transition-colors duration-300"
          style={{ background: ds.card, boxShadow: ds.cardShadow }}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm"
                style={{ background: asset.color + "22", color: asset.color, border: `1px solid ${asset.color}33` }}>
                {asset.icon}
              </div>
              <div>
                <p className="text-sm font-semibold" style={{ color: ds.textPrimary }}>{asset.name} · {sym}/USDT</p>
                <p className="text-xs" style={{ color: ds.textMuted }}>24h Price Chart</p>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              {isUp ? <TrendingUp size={16} style={{ color: "#22c55e" }}/> : <TrendingDown size={16} style={{ color: "#ef4444" }}/>}
              <span className="text-sm font-semibold" style={{ color: isUp ? "#22c55e" : "#ef4444" }}>
                {isUp ? "+" : ""}{asset.change}%
              </span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={asset.chart1D}>
              <defs>
                <linearGradient id={`pdFill${sym}`} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={asset.color} stopOpacity={ds.isDark ? 0.25 : 0.15}/>
                  <stop offset="100%" stopColor={asset.color} stopOpacity={0.01}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke={ds.isDark ? "rgba(255,255,255,0.05)" : "#f0f0f5"} vertical={false}/>
              <XAxis dataKey="t" tick={{ fontSize: 10, fill: ds.textMuted }} axisLine={false} tickLine={false}/>
              <YAxis tick={{ fontSize: 10, fill: ds.textMuted }} axisLine={false} tickLine={false}
                tickFormatter={v => `$${v >= 1000 ? (v / 1000).toFixed(0) + "k" : v}`}
                domain={["auto", "auto"]}/>
              <Tooltip
                contentStyle={{ borderRadius: 10, border: "none", fontSize: 12, background: ds.card, boxShadow: "0 4px 20px rgba(0,0,0,0.16)", color: ds.textPrimary }}
                formatter={(v: number) => [`$${v.toLocaleString()}`, sym]}
              />
              <Area type="monotone" dataKey="p" stroke={asset.color} strokeWidth={2.5}
                fill={`url(#pdFill${sym})`} dot={false}/>
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Position details + trade history */}
        <div className="grid grid-cols-3 gap-5">

          {/* Position summary */}
          <div className="rounded-2xl p-5 transition-colors duration-300"
            style={{ background: ds.card, boxShadow: ds.cardShadow }}>
            <p className="text-sm font-semibold mb-4" style={{ color: ds.textPrimary }}>Position Summary</p>
            <div className="flex flex-col gap-3">
              {[
                { label: "Quantity",    value: `${asset.qty} ${sym}` },
                { label: "Avg Buy",     value: `$${asset.avgBuy.toLocaleString()}` },
                { label: "Mkt Price",   value: `$${asset.price.toLocaleString()}` },
                { label: "Total Value", value: `$${value.toLocaleString("en-US", { maximumFractionDigits: 2 })}` },
                { label: "Total P&L",   value: `${pnl >= 0 ? "+" : ""}$${pnl.toLocaleString("en-US", { maximumFractionDigits: 2 })}` },
              ].map(({ label, value }) => (
                <div key={label} className="flex items-center justify-between py-2"
                  style={{ borderBottom: `1px solid ${ds.divider}` }}>
                  <span className="text-xs" style={{ color: ds.textMuted }}>{label}</span>
                  <span className="text-xs font-semibold" style={{ color: ds.textPrimary }}>{value}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Trade history for this asset */}
          <div className="rounded-2xl p-5 col-span-2 transition-colors duration-300"
            style={{ background: ds.card, boxShadow: ds.cardShadow }}>
            <p className="text-sm font-semibold mb-4" style={{ color: ds.textPrimary }}>Trade History — {sym}</p>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr style={{ background: ds.subBg }}>
                    {["Trade ID", "Side", "Qty", "Price", "P&L", "Date"].map(h => (
                      <th key={h} className="text-left text-xs font-medium px-4 py-2.5" style={{ color: ds.textMuted }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {asset.trades.map(t => (
                    <tr key={t.id} style={{ borderTop: `1px solid ${ds.divider}` }}>
                      <td className="px-4 py-3 text-xs font-mono" style={{ color: ds.textMuted }}>{t.id}</td>
                      <td className="px-4 py-3">
                        <span className="flex items-center gap-1 text-xs font-semibold"
                          style={{ color: t.side === "Buy" ? "#16a34a" : "#dc2626" }}>
                          {t.side === "Buy" ? <TrendingUp size={11}/> : <TrendingDown size={11}/>}
                          {t.side}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs font-medium" style={{ color: ds.textSecondary }}>{t.qty} {sym}</td>
                      <td className="px-4 py-3 text-xs font-medium" style={{ color: ds.textPrimary }}>${t.price.toLocaleString()}</td>
                      <td className="px-4 py-3 text-xs font-semibold" style={{ color: t.pnl >= 0 ? "#22c55e" : "#ef4444" }}>
                        {t.pnl >= 0 ? "+" : ""}${t.pnl.toLocaleString()}
                      </td>
                      <td className="px-4 py-3 text-xs" style={{ color: ds.textMuted }}>{t.date}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
    </>
  );
}
