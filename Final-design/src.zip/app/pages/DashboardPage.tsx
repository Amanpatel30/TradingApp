import { useState } from "react";
import { useNavigate } from "react-router";
import { TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight, Wallet, BarChart2, Activity, Repeat2 } from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell,
} from "recharts";
import { PageHeader } from "../components/PageHeader";
import { useDS } from "../context/ThemeContext";

const allChartData: Record<string, { date: string; value: number }[]> = {
  "1W": [
    { date: "Mon", value: 44200 }, { date: "Tue", value: 45800 }, { date: "Wed", value: 43900 },
    { date: "Thu", value: 46500 }, { date: "Fri", value: 47100 }, { date: "Sat", value: 46800 }, { date: "Sun", value: 48750 },
  ],
  "1M": [{ date: "W1", value: 41200 }, { date: "W2", value: 43800 }, { date: "W3", value: 45500 }, { date: "W4", value: 48750 }],
  "3M": [{ date: "Jan", value: 39800 }, { date: "Feb", value: 44500 }, { date: "Mar", value: 48750 }],
  "1Y": [
    { date: "Jan", value: 18400 }, { date: "Feb", value: 22100 }, { date: "Mar", value: 19800 },
    { date: "Apr", value: 27500 }, { date: "May", value: 25200 }, { date: "Jun", value: 31800 },
    { date: "Jul", value: 29400 }, { date: "Aug", value: 38200 }, { date: "Sep", value: 35600 },
    { date: "Oct", value: 42100 }, { date: "Nov", value: 39800 }, { date: "Dec", value: 48750 },
  ],
};

const allocation = [
  { name: "BTC",   value: 45, color: "#f59e0b" },
  { name: "ETH",   value: 28, color: "#8b5cf6" },
  { name: "SOL",   value: 15, color: "#06b6d4" },
  { name: "BNB",   value: 8,  color: "#22c55e" },
  { name: "Other", value: 4,  color: "#374151" },
];

const recentTx = [
  { id: 1, type: "buy",  asset: "BTC",  amount: "+0.045 BTC", usd: "+$3,036", time: "2m ago",  icon: "₿" },
  { id: 2, type: "sell", asset: "ETH",  amount: "-1.20 ETH",  usd: "-$4,226", time: "1h ago",  icon: "Ξ" },
  { id: 3, type: "buy",  asset: "SOL",  amount: "+12.5 SOL",  usd: "+$2,230", time: "3h ago",  icon: "◎" },
  { id: 4, type: "sell", asset: "BNB",  amount: "-2.0 BNB",   usd: "-$1,185", time: "5h ago",  icon: "B" },
  { id: 5, type: "buy",  asset: "LINK", amount: "+80 LINK",   usd: "+$1,178", time: "8h ago",  icon: "⬡" },
];

const topMovers = [
  { symbol: "SOL",   name: "Solana",    price: "$178.42", change: "+5.67%", up: true  },
  { symbol: "AVAX",  name: "Avalanche", price: "$38.91",  change: "+4.12%", up: true  },
  { symbol: "ARB",   name: "Arbitrum",  price: "$1.24",   change: "+3.88%", up: true  },
  { symbol: "MATIC", name: "Polygon",   price: "$0.89",   change: "-2.34%", up: false },
  { symbol: "DOT",   name: "Polkadot",  price: "$7.81",   change: "-1.78%", up: false },
];

const statCards = [
  { label: "Portfolio Value", value: "$48,750.20", sub: "+12.4% this month", icon: Wallet,    up: true },
  { label: "24h P&L",        value: "+$1,284.50", sub: "+2.71% today",      icon: TrendingUp, up: true },
  { label: "Total Trades",   value: "1,342",       sub: "38 this week",      icon: Repeat2,   up: true },
  { label: "Win Rate",       value: "68.4%",       sub: "last 90 days",      icon: BarChart2,  up: true },
];

type Period = "1W" | "1M" | "3M" | "1Y";

export function DashboardPage() {
  const navigate = useNavigate();
  const ds = useDS();
  const [period, setPeriod] = useState<Period>("1Y");
  const chartData = allChartData[period];

  return (
    <>
      <PageHeader title="Dashboard" />
      <main className="flex-1 px-6 pb-8 overflow-auto">

        {/* Stat cards */}
        <div className="grid grid-cols-4 gap-4 mb-5">
          {statCards.map(({ label, value, sub, icon: Icon, up }) => (
            <div key={label} className="rounded-2xl p-5 transition-colors duration-300"
              style={{ background: ds.card, boxShadow: ds.cardShadow }}>
              <div className="flex items-center justify-between mb-3">
                <p className="text-xs" style={{ color: ds.textMuted }}>{label}</p>
                <div className="w-8 h-8 rounded-xl flex items-center justify-center"
                  style={{ background: ds.isDark ? "rgba(6,182,212,0.12)" : "rgba(34,197,94,0.08)" }}>
                  <Icon size={15} style={{ color: "#06b6d4" }} />
                </div>
              </div>
              <p className="text-xl font-semibold" style={{ color: ds.textPrimary }}>{value}</p>
              <div className="flex items-center gap-1 mt-1">
                {up ? <ArrowUpRight size={13} style={{ color: "#22c55e" }} /> : <ArrowDownRight size={13} style={{ color: "#ef4444" }} />}
                <p className="text-xs" style={{ color: up ? "#22c55e" : "#ef4444" }}>{sub}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Chart + Allocation */}
        <div className="flex gap-5 mb-5">
          <div className="rounded-2xl p-5 flex-1 min-w-0 transition-colors duration-300"
            style={{ background: ds.card, boxShadow: ds.cardShadow }}>
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-sm font-semibold" style={{ color: ds.textPrimary }}>Portfolio Performance</p>
                <p className="text-xs" style={{ color: ds.textMuted }}>
                  {period === "1W" ? "Last 7 days" : period === "1M" ? "Last 4 weeks" : period === "3M" ? "Last 3 months" : "Year to date"}
                </p>
              </div>
              <div className="flex gap-1">
                {(["1W","1M","3M","1Y"] as Period[]).map((t) => (
                  <button key={t} onClick={() => setPeriod(t)}
                    className="text-xs px-3 py-1 rounded-lg transition-all"
                    style={period === t
                      ? { background: "linear-gradient(90deg,#22c55e,#06b6d4)", color: "white" }
                      : { background: ds.subBg, color: ds.textMuted }}>
                    {t}
                  </button>
                ))}
              </div>
            </div>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="pgradDash" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#22c55e" stopOpacity={ds.isDark ? 0.25 : 0.15} />
                    <stop offset="100%" stopColor="#06b6d4" stopOpacity={0.01} />
                  </linearGradient>
                  <linearGradient id="lineGradDash" x1="0" y1="0" x2="1" y2="0">
                    <stop stopColor="#22c55e" /><stop offset="1" stopColor="#06b6d4" />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke={ds.isDark ? "rgba(255,255,255,0.05)" : "#f0f0f5"} vertical={false} />
                <XAxis dataKey="date" tick={{ fontSize: 11, fill: ds.textMuted }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: ds.textMuted }} axisLine={false} tickLine={false}
                  tickFormatter={(v) => `$${(v/1000).toFixed(0)}k`} />
                <Tooltip
                  contentStyle={{ borderRadius: 12, border: "none", boxShadow: "0 4px 20px rgba(0,0,0,0.16)", fontSize: 12, background: ds.card, color: ds.textPrimary }}
                  formatter={(v: number) => [`$${v.toLocaleString()}`, "Value"]}
                />
                <Area type="monotone" dataKey="value" stroke="url(#lineGradDash)" strokeWidth={2} fill="url(#pgradDash)" dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Allocation */}
          <div className="rounded-2xl p-5 w-64 shrink-0 transition-colors duration-300"
            style={{ background: ds.card, boxShadow: ds.cardShadow }}>
            <p className="text-sm font-semibold mb-1" style={{ color: ds.textPrimary }}>Allocation</p>
            <p className="text-xs mb-3" style={{ color: ds.textMuted }}>By asset</p>
            <div className="flex justify-center">
              <PieChart width={130} height={130}>
                <Pie data={allocation} cx={60} cy={60} innerRadius={38} outerRadius={60} dataKey="value" strokeWidth={0}>
                  {allocation.map((e) => <Cell key={e.name} fill={e.color} />)}
                </Pie>
              </PieChart>
            </div>
            <div className="flex flex-col gap-2 mt-3">
              {allocation.map((a) => (
                <div key={a.name} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: a.color }} />
                    <span className="text-xs" style={{ color: ds.textSecondary }}>{a.name}</span>
                  </div>
                  <span className="text-xs font-medium" style={{ color: ds.textPrimary }}>{a.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Recent txs + Top movers */}
        <div className="flex gap-5">
          <div className="rounded-2xl flex-1 min-w-0 transition-colors duration-300"
            style={{ background: ds.card, boxShadow: ds.cardShadow }}>
            <div className="flex items-center justify-between px-5 pt-5 pb-3">
              <p className="text-sm font-semibold" style={{ color: ds.textPrimary }}>Recent Transactions</p>
              <button onClick={() => navigate("/wallet")} className="text-xs text-cyan-500 hover:text-cyan-400 transition-colors">
                View all →
              </button>
            </div>
            <div style={{ borderTop: `1px solid ${ds.divider}` }}>
              {recentTx.map((tx) => (
                <div key={tx.id} className="flex items-center gap-3 px-5 py-3 transition-colors"
                  style={{ borderBottom: `1px solid ${ds.divider}` }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = ds.hoverBg)}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}>
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center text-sm font-semibold shrink-0"
                    style={tx.type === "buy"
                      ? { background: ds.isDark ? "rgba(34,197,94,0.15)"  : "#dcfce7", color: "#16a34a" }
                      : { background: ds.isDark ? "rgba(239,68,68,0.15)"  : "#fee2e2", color: "#dc2626" }}>
                    {tx.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium" style={{ color: ds.textPrimary }}>{tx.type === "buy" ? "Bought" : "Sold"} {tx.asset}</p>
                    <p className="text-xs" style={{ color: ds.textMuted }}>{tx.time}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold" style={{ color: tx.type === "buy" ? "#16a34a" : "#dc2626" }}>{tx.usd}</p>
                    <p className="text-xs" style={{ color: ds.textMuted }}>{tx.amount}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Top Movers */}
          <div className="rounded-2xl w-64 shrink-0 transition-colors duration-300"
            style={{ background: ds.card, boxShadow: ds.cardShadow }}>
            <div className="flex items-center justify-between px-5 pt-5 pb-3">
              <p className="text-sm font-semibold" style={{ color: ds.textPrimary }}>Top Movers</p>
              <Activity size={15} style={{ color: "#06b6d4" }} />
            </div>
            <div style={{ borderTop: `1px solid ${ds.divider}` }}>
              {topMovers.map((m) => (
                <button key={m.symbol} onClick={() => navigate("/trade")}
                  className="w-full flex items-center justify-between px-5 py-3 transition-colors"
                  style={{ borderBottom: `1px solid ${ds.divider}` }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = ds.hoverBg)}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}>
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold text-white shrink-0"
                      style={{ background: "linear-gradient(135deg,#1a1a2e,#0f3460)" }}>{m.symbol[0]}</div>
                    <div className="text-left">
                      <p className="text-sm font-medium" style={{ color: ds.textPrimary }}>{m.symbol}</p>
                      <p className="text-xs" style={{ color: ds.textMuted }}>{m.name}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xs font-medium" style={{ color: ds.textSecondary }}>{m.price}</p>
                    <p className="text-xs font-semibold flex items-center gap-0.5 justify-end"
                      style={{ color: m.up ? "#22c55e" : "#ef4444" }}>
                      {m.up ? <TrendingUp size={10}/> : <TrendingDown size={10}/>} {m.change}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </main>
    </>
  );
}
