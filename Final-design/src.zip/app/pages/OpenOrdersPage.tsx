import { useState } from "react";
import { X, Filter, RefreshCw, ClipboardList } from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "../components/PageHeader";
import { EmptyState } from "../components/EmptyState";
import { TableSkeleton } from "../components/Skeleton";
import { WSIndicator } from "../components/WSIndicator";
import { useDS } from "../context/ThemeContext";

type Side   = "Buy" | "Sell";
type OType  = "Limit" | "Market" | "Stop-Limit";
type Status = "Open" | "Partial";

interface Order {
  id: string; symbol: string; side: Side; type: OType;
  qty: number; price: number; filled: number; status: Status; time: string;
}

const INIT_ORDERS: Order[] = [
  { id:"OO-001", symbol:"BTC/USDT",  side:"Buy",  type:"Limit",      qty:0.25,   price:66900,  filled:0,    status:"Open",    time:"14:22:01" },
  { id:"OO-002", symbol:"ETH/USDT",  side:"Sell", type:"Limit",      qty:2.50,   price:3600,   filled:0.80, status:"Partial", time:"13:58:44" },
  { id:"OO-003", symbol:"SOL/USDT",  side:"Buy",  type:"Limit",      qty:15.00,  price:172,    filled:0,    status:"Open",    time:"13:40:10" },
  { id:"OO-004", symbol:"BNB/USDT",  side:"Buy",  type:"Market",     qty:3.00,   price:590,    filled:1.20, status:"Partial", time:"13:10:33" },
  { id:"OO-005", symbol:"LINK/USDT", side:"Sell", type:"Limit",      qty:100.00, price:15.20,  filled:0,    status:"Open",    time:"12:55:07" },
  { id:"OO-006", symbol:"AVAX/USDT", side:"Buy",  type:"Stop-Limit", qty:8.00,   price:37.50,  filled:0,    status:"Open",    time:"12:30:22" },
  { id:"OO-007", symbol:"DOT/USDT",  side:"Sell", type:"Limit",      qty:50.00,  price:8.10,   filled:30,   status:"Partial", time:"11:58:41" },
];

const SYMBOLS = ["All", "BTC/USDT","ETH/USDT","SOL/USDT","BNB/USDT","LINK/USDT","AVAX/USDT","DOT/USDT"];

export function OpenOrdersPage() {
  const ds = useDS();
  const [orders, setOrders]       = useState<Order[]>(INIT_ORDERS);
  const [symbol, setSymbol]       = useState("All");
  const [loading, setLoading]     = useState(false);
  const [cancelAll, setCancelAll] = useState(false);

  const filtered = symbol === "All" ? orders : orders.filter((o) => o.symbol === symbol);

  const cancel = (id: string) => {
    setOrders((p) => p.filter((o) => o.id !== id));
    toast.success(`Order ${id} cancelled`);
  };

  const handleCancelAll = () => {
    setOrders([]);
    setCancelAll(false);
    toast.success("All open orders cancelled");
  };

  const refresh = () => {
    setLoading(true);
    setTimeout(() => setLoading(false), 1200);
    toast.info("Order book refreshed");
  };

  const fillPct = (o: Order) => o.qty > 0 ? Math.round((o.filled / o.qty) * 100) : 0;

  return (
    <>
      <PageHeader title="Open Orders" />
      <main className="flex-1 px-6 pb-8 overflow-auto page-enter">

        {/* Stat strip */}
        <div className="grid grid-cols-4 gap-4 mb-5">
          {[
            { label: "Open Orders",    value: orders.length,                                    color: "#06b6d4" },
            { label: "Buy Orders",     value: orders.filter((o) => o.side === "Buy").length,    color: "#22c55e" },
            { label: "Sell Orders",    value: orders.filter((o) => o.side === "Sell").length,   color: "#ef4444" },
            { label: "Partial Fills",  value: orders.filter((o) => o.status === "Partial").length, color: "#f59e0b" },
          ].map(({ label, value, color }) => (
            <div key={label} className="rounded-2xl px-5 py-4 transition-colors duration-300"
              style={{ background: ds.card, boxShadow: ds.cardShadow }}>
              <p className="text-xs mb-1" style={{ color: ds.textMuted }}>{label}</p>
              <p className="text-2xl font-semibold" style={{ color }}>{value}</p>
            </div>
          ))}
        </div>

        {/* Table card */}
        <div className="rounded-2xl overflow-hidden transition-colors duration-300"
          style={{ background: ds.card, boxShadow: ds.cardShadow }}>

          {/* Toolbar */}
          <div className="flex items-center justify-between px-5 py-4"
            style={{ borderBottom: `1px solid ${ds.divider}` }}>
            <div className="flex items-center gap-3">
              <WSIndicator />
              <div className="flex items-center gap-2 rounded-xl px-3 py-1.5"
                style={{ background: ds.subBg, border: `1px solid ${ds.border}` }}>
                <Filter size={13} style={{ color: ds.textMuted }} />
                <select value={symbol} onChange={(e) => setSymbol(e.target.value)}
                  className="bg-transparent outline-none text-xs cursor-pointer"
                  style={{ color: ds.textSecondary }}>
                  {SYMBOLS.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button onClick={refresh}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs transition-colors"
                style={{ background: ds.subBg, color: ds.textSecondary }}>
                <RefreshCw size={12} className={loading ? "animate-spin" : ""} /> Refresh
              </button>
              {filtered.length > 0 && (
                <button onClick={() => setCancelAll(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-colors"
                  style={{ background: ds.isDark ? "rgba(239,68,68,0.12)" : "#fee2e2", color: "#ef4444" }}>
                  <X size={12} /> Cancel All
                </button>
              )}
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr style={{ background: ds.subBg }}>
                  {["Order ID","Symbol","Side","Type","Quantity","Price (USDT)","Filled","Total","Status","Time",""].map((h) => (
                    <th key={h} className="text-left text-xs font-medium px-5 py-3 whitespace-nowrap" style={{ color: ds.textMuted }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <TableSkeleton rows={5} cols={11} />
                ) : filtered.length === 0 ? (
                  <tr><td colSpan={11}>
                    <EmptyState
                      icon={ClipboardList}
                      title="No open orders"
                      description={symbol !== "All" ? `No open orders for ${symbol}.` : "You have no open orders at the moment. Place a trade from the Exchange page."}
                      action={{ label: "Go to Exchange", onClick: () => window.location.href = "/trade" }}
                    />
                  </td></tr>
                ) : (
                  filtered.map((o) => (
                    <tr key={o.id} className="transition-colors"
                      style={{ borderTop: `1px solid ${ds.divider}` }}
                      onMouseEnter={(e) => (e.currentTarget.style.background = ds.hoverBg)}
                      onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}>
                      <td className="px-5 py-3.5 text-xs font-mono" style={{ color: ds.textMuted }}>{o.id}</td>
                      <td className="px-5 py-3.5 text-sm font-semibold" style={{ color: ds.textPrimary }}>{o.symbol}</td>
                      <td className="px-5 py-3.5">
                        <span className="text-xs font-semibold px-2.5 py-1 rounded-full"
                          style={o.side === "Buy"
                            ? { background: ds.isDark ? "rgba(34,197,94,0.15)"  : "#dcfce7", color: "#16a34a" }
                            : { background: ds.isDark ? "rgba(239,68,68,0.15)"  : "#fee2e2", color: "#dc2626" }}>
                          {o.side}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-xs" style={{ color: ds.textSecondary }}>{o.type}</td>
                      <td className="px-5 py-3.5 text-xs" style={{ color: ds.textSecondary }}>{o.qty.toFixed(4)}</td>
                      <td className="px-5 py-3.5 text-xs" style={{ color: ds.textSecondary }}>${o.price.toLocaleString()}</td>
                      <td className="px-5 py-3.5">
                        <div className="flex flex-col gap-1">
                          <span className="text-xs" style={{ color: ds.textSecondary }}>
                            {o.filled.toFixed(4)} <span style={{ color: ds.textMuted }}>/ {o.qty.toFixed(4)} ({fillPct(o)}%)</span>
                          </span>
                          <div className="w-16 h-1.5 rounded-full overflow-hidden" style={{ background: ds.subBg2 }}>
                            <div className="h-full rounded-full transition-all"
                              style={{ width: `${fillPct(o)}%`, background: "linear-gradient(90deg,#22c55e,#06b6d4)" }}/>
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-3.5 text-xs" style={{ color: ds.textSecondary }}>
                        ${(o.qty * o.price).toLocaleString()}
                      </td>
                      <td className="px-5 py-3.5">
                        <span className="text-xs px-2.5 py-1 rounded-full"
                          style={o.status === "Open"
                            ? { background: ds.isDark ? "rgba(59,130,246,0.15)"  : "#eff6ff", color: "#3b82f6" }
                            : { background: ds.isDark ? "rgba(234,179,8,0.15)"   : "#fef9c3", color: "#ca8a04" }}>
                          {o.status}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-xs font-mono" style={{ color: ds.textMuted }}>{o.time}</td>
                      <td className="px-5 py-3.5">
                        <button onClick={() => cancel(o.id)}
                          className="w-7 h-7 rounded-full flex items-center justify-center transition-all"
                          style={{ background: ds.subBg, color: ds.textMuted }}
                          onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = ds.isDark ? "rgba(239,68,68,0.2)" : "#fee2e2"; (e.currentTarget as HTMLElement).style.color = "#ef4444"; }}
                          onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = ds.subBg; (e.currentTarget as HTMLElement).style.color = ds.textMuted; }}
                          title="Cancel order">
                          <X size={12} />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Cancel-all confirm */}
        {cancelAll && (
          <div className="fixed inset-0 z-50 flex items-center justify-center">
            <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setCancelAll(false)}/>
            <div className="relative rounded-2xl p-6 w-80" style={{ background: ds.card, border: `1px solid ${ds.border}`, boxShadow: "0 20px 60px rgba(0,0,0,0.3)" }}>
              <p className="text-base font-semibold mb-2" style={{ color: ds.textPrimary }}>Cancel all orders?</p>
              <p className="text-sm mb-5" style={{ color: ds.textMuted }}>This will cancel all {filtered.length} open order{filtered.length !== 1 ? "s" : ""}. This action cannot be undone.</p>
              <div className="flex gap-3">
                <button onClick={() => setCancelAll(false)}
                  className="flex-1 py-2.5 rounded-xl text-sm font-medium"
                  style={{ background: ds.subBg, color: ds.textSecondary }}>Keep</button>
                <button onClick={handleCancelAll}
                  className="flex-1 py-2.5 rounded-xl text-sm font-medium text-white"
                  style={{ background: "linear-gradient(90deg,#f43f5e,#ef4444)" }}>Cancel All</button>
              </div>
            </div>
          </div>
        )}
      </main>
    </>
  );
}
