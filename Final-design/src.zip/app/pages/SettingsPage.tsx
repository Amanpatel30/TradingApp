import { useState, useRef } from "react";
import { User, Shield, Bell, Key, CreditCard, Smartphone, Check, ChevronRight, Eye, EyeOff, Copy, Plus, Trash2, Lock } from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "../components/PageHeader";
import { useDS, useTheme } from "../context/ThemeContext";

const TABS = [
  { id:"profile",       label:"Profile",       icon:User       },
  { id:"security",      label:"Security",      icon:Shield     },
  { id:"notifications", label:"Notifications", icon:Bell       },
  { id:"api",           label:"API Keys",      icon:Key        },
  { id:"billing",       label:"Billing",       icon:CreditCard },
] as const;
type TabId = typeof TABS[number]["id"];

function Toggle({ value, onChange }: { value:boolean; onChange:(v:boolean)=>void }) {
  return (
    <button onClick={() => onChange(!value)} className="relative rounded-full transition-all duration-300 shrink-0"
      style={{ background: value ? "linear-gradient(90deg,#22c55e,#06b6d4)" : "#374151", height:"22px", width:"40px" }}>
      <span className="absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all duration-300"
        style={{ left: value ? "20px" : "2px" }}/>
    </button>
  );
}

function SectionCard({ title, children, ds }: { title:string; children:React.ReactNode; ds:ReturnType<typeof useDS> }) {
  return (
    <div className="rounded-2xl p-6 transition-colors duration-300" style={{ background: ds.card, boxShadow: ds.cardShadow }}>
      <p className="text-sm font-semibold mb-5" style={{ color: ds.textPrimary }}>{title}</p>
      {children}
    </div>
  );
}

function SettingsRow({ label, desc, children, ds }: { label:string; desc?:string; children:React.ReactNode; ds:ReturnType<typeof useDS> }) {
  return (
    <div className="flex items-center justify-between py-3.5" style={{ borderBottom: `1px solid ${ds.divider}` }}>
      <div>
        <p className="text-sm" style={{ color: ds.textSecondary }}>{label}</p>
        {desc && <p className="text-xs mt-0.5" style={{ color: ds.textMuted }}>{desc}</p>}
      </div>
      <div className="ml-4 shrink-0">{children}</div>
    </div>
  );
}

function generateKey() {
  const c = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  return "cc_live_" + Array.from({length:24},()=>c[Math.floor(Math.random()*c.length)]).join("");
}

export function SettingsPage() {
  const ds = useDS();
  const { isDark, toggleTheme } = useTheme();
  const [tab, setTab] = useState<TabId>("profile");

  const [name,     setName]     = useState("Eden Ellis");
  const [email,    setEmail]    = useState("eden@cryptocrack.io");
  const [currency, setCurrency] = useState("USD");
  const [language, setLanguage] = useState("English");
  const [timezone, setTimezone] = useState("UTC−05:00 Eastern");
  const [compact,  setCompact]  = useState(true);
  const [saved,    setSaved]    = useState(false);
  const avatarRef = useRef<HTMLInputElement>(null);

  const [twoFA,         setTwoFA]        = useState(true);
  const [bioAuth,       setBioAuth]      = useState(false);
  const [sessionAlerts, setSessionAlerts]= useState(true);
  const [sessions, setSessions] = useState([
    { id:1, device:"MacBook Pro 16″",    location:"New York, US", time:"Now",         current:true  },
    { id:2, device:"iPhone 15 Pro",       location:"New York, US", time:"2 hours ago", current:false },
    { id:3, device:"Chrome · Windows 11", location:"London, UK",   time:"3 days ago",  current:false },
  ]);
  const [changingPw, setChangingPw] = useState(false);
  const [pwForm, setPwForm] = useState({ current:"", next:"", confirm:"" });
  const [showPw, setShowPw] = useState({ current:false, next:false, confirm:false });

  const [notifs, setNotifs] = useState({ priceAlerts:true, orderFills:true, deposits:true, withdrawals:true, newsletter:false, security:true, pushMobile:true, emailDigest:false });

  const [apiKeys, setApiKeys] = useState([
    { id:0, name:"Production Key", key:"cc_live_4Xk9mP2nR7vQ3wL8jH5tY1bF6cD0",  created:"Jan 12, 2026", perms:"Read & Trade", active:true  },
    { id:1, name:"Read-only Key",  key:"cc_live_9Bz2sK6uN4eA1mC7dW3xJ5yR8pT0",   created:"Feb 03, 2026", perms:"Read only",    active:true  },
    { id:2, name:"Webhook Key",    key:"cc_live_7Fp5nH2kM9vX4wQ8rL1tY6bC3dG0",   created:"Feb 28, 2026", perms:"Webhooks",     active:false },
  ]);
  const [visibleKeys, setVisibleKeys] = useState<Record<number,boolean>>({});
  const [copiedKey,   setCopiedKey]   = useState<number|null>(null);

  const [payments, setPayments] = useState([
    { id:0, type:"Visa",       last4:"4242", exp:"09/27", default:true  },
    { id:1, type:"Mastercard", last4:"5310", exp:"12/25", default:false },
  ]);
  const [addingCard, setAddingCard] = useState(false);
  const [cardForm, setCardForm] = useState({ number:"", exp:"", cvv:"", name:"" });

  const maskKey = (k:string) => k.slice(0,10)+"••••••••••••••••"+k.slice(-6);
  const inputCls = { background:ds.inputBg, border:`1px solid ${ds.inputBorder}`, borderRadius:"12px", padding:"10px 16px", fontSize:"14px", color:ds.textPrimary, outline:"none", width:"100%" };

  const handleSave = () => { setSaved(true); toast.success("Profile saved!"); setTimeout(() => setSaved(false), 2000); };
  const handleRevoke = (id:number) => { setSessions((p) => p.filter((s) => s.id!==id)); toast.success("Session revoked"); };
  const handleChangePw = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pwForm.current)               { toast.error("Enter current password"); return; }
    if (pwForm.next.length < 8)        { toast.error("Min 8 characters"); return; }
    if (pwForm.next !== pwForm.confirm) { toast.error("Passwords don't match"); return; }
    toast.success("Password updated!"); setChangingPw(false); setPwForm({current:"",next:"",confirm:""});
  };
  const handleGenerateKey = () => { setApiKeys((p) => [...p, { id:Date.now(), name:`New Key ${p.length+1}`, key:generateKey(), created:"Mar 03, 2026", perms:"Read only", active:true }]); toast.success("New API key generated!"); };
  const handleDeleteKey   = (id:number) => { setApiKeys((p) => p.filter((k) => k.id!==id)); toast.success("Key deleted"); };
  const handleSetDefault  = (id:number) => { setPayments((p) => p.map((pm) => ({...pm, default:pm.id===id}))); toast.success("Default updated"); };
  const handleAddCard     = (e: React.FormEvent) => {
    e.preventDefault();
    if (!cardForm.number||!cardForm.exp||!cardForm.cvv||!cardForm.name) { toast.error("Fill all card fields"); return; }
    setPayments((p) => [...p, { id:Date.now(), type:"Visa", last4:cardForm.number.replace(/\s/g,"").slice(-4), exp:cardForm.exp, default:false }]);
    toast.success("Card added!"); setAddingCard(false); setCardForm({number:"",exp:"",cvv:"",name:""});
  };

  const activeStyle = { background:"linear-gradient(90deg,#22c55e,#06b6d4)", color:"white" };

  return (
    <>
      <PageHeader title="Settings"/>
      <main className="flex-1 px-6 pb-8 overflow-auto">
        <div className="flex gap-5">

          {/* Sidebar nav */}
          <div className="rounded-2xl p-3 w-52 shrink-0 h-fit transition-colors duration-300"
            style={{ background: ds.card, boxShadow: ds.cardShadow }}>
            {TABS.map(({ id, label, icon:Icon }) => (
              <button key={id} onClick={() => setTab(id)}
                className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm transition-all"
                style={tab===id ? activeStyle : { color: ds.navInactive }}>
                <Icon size={16}/>{label}
              </button>
            ))}
          </div>

          <div className="flex-1 min-w-0 flex flex-col gap-4">

            {/* ── Profile ── */}
            {tab === "profile" && (
              <>
                <SectionCard title="Profile Information" ds={ds}>
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-pink-300 to-purple-400 flex items-center justify-center text-white text-xl font-semibold shrink-0">EE</div>
                    <div>
                      <input ref={avatarRef} type="file" accept="image/*" className="hidden" onChange={() => toast.success("Avatar updated!")}/>
                      <button onClick={() => avatarRef.current?.click()}
                        className="text-sm font-medium text-white px-4 py-2 rounded-xl hover:opacity-90 transition-opacity"
                        style={{ background:"linear-gradient(90deg,#22c55e,#06b6d4)" }}>Change Avatar</button>
                      <p className="text-xs mt-1" style={{ color: ds.textMuted }}>JPG, PNG or GIF · max 2MB</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    {[{label:"Full Name",value:name,setter:setName},{label:"Email",value:email,setter:setEmail}].map(({ label, value, setter }) => (
                      <div key={label} className="flex flex-col gap-1.5">
                        <label className="text-xs font-medium" style={{ color: ds.textMuted }}>{label}</label>
                        <input value={value} onChange={(e) => setter(e.target.value)} style={inputCls}
                          onFocus={(e) => (e.currentTarget.style.borderColor="#06b6d4")}
                          onBlur={(e)  => (e.currentTarget.style.borderColor=ds.inputBorder)}/>
                      </div>
                    ))}
                    <div className="flex flex-col gap-1.5">
                      <label className="text-xs font-medium" style={{ color: ds.textMuted }}>Currency</label>
                      <select value={currency} onChange={(e) => setCurrency(e.target.value)} style={{ ...inputCls, cursor:"pointer" }}>
                        {["USD","EUR","GBP","JPY","AUD"].map((c) => <option key={c}>{c}</option>)}
                      </select>
                    </div>
                    <div className="flex flex-col gap-1.5">
                      <label className="text-xs font-medium" style={{ color: ds.textMuted }}>Language</label>
                      <select value={language} onChange={(e) => setLanguage(e.target.value)} style={{ ...inputCls, cursor:"pointer" }}>
                        {["English","Spanish","French","German","Japanese"].map((l) => <option key={l}>{l}</option>)}
                      </select>
                    </div>
                  </div>
                </SectionCard>

                <SectionCard title="Preferences" ds={ds}>
                  <SettingsRow label="Dark Mode" desc="Switch to a darker theme" ds={ds}>
                    <Toggle value={isDark} onChange={() => toggleTheme()}/>
                  </SettingsRow>
                  <SettingsRow label="Compact View" desc="Show more data with less spacing" ds={ds}>
                    <Toggle value={compact} onChange={(v) => { setCompact(v); toast.info(v?"Compact on":"Comfortable on"); }}/>
                  </SettingsRow>
                  <SettingsRow label="Time Zone" desc="Used for all timestamps" ds={ds}>
                    <select value={timezone} onChange={(e) => setTimezone(e.target.value)}
                      className="text-xs rounded-lg px-3 py-1.5 outline-none"
                      style={{ background:ds.inputBg, border:`1px solid ${ds.inputBorder}`, color:ds.textSecondary }}>
                      <option>UTC−05:00 Eastern</option>
                      <option>UTC+00:00 London</option>
                      <option>UTC+08:00 Singapore</option>
                      <option>UTC+09:00 Tokyo</option>
                    </select>
                  </SettingsRow>
                </SectionCard>

                <div className="flex justify-end">
                  <button onClick={handleSave}
                    className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-medium text-white hover:opacity-90 transition-opacity"
                    style={{ background:"linear-gradient(90deg,#22c55e,#06b6d4)", boxShadow:"0 4px 16px rgba(6,182,212,0.2)" }}>
                    {saved ? <><Check size={15}/> Saved!</> : "Save Changes"}
                  </button>
                </div>
              </>
            )}

            {/* ── Security ── */}
            {tab === "security" && (
              <>
                <SectionCard title="Account Security" ds={ds}>
                  <SettingsRow label="Two-Factor Authentication" desc="Require OTP for every login" ds={ds}><Toggle value={twoFA} onChange={setTwoFA}/></SettingsRow>
                  <SettingsRow label="Biometric Authentication" desc="Use Face ID or fingerprint" ds={ds}><Toggle value={bioAuth} onChange={setBioAuth}/></SettingsRow>
                  <SettingsRow label="Session Alerts" desc="Get notified of new sign-ins" ds={ds}><Toggle value={sessionAlerts} onChange={setSessionAlerts}/></SettingsRow>
                  <SettingsRow label="Change Password" desc="Last changed 45 days ago" ds={ds}>
                    <button onClick={() => setChangingPw((o) => !o)}
                      className="flex items-center gap-1 text-xs text-cyan-500 hover:text-cyan-400 transition-colors">
                      {changingPw?"Cancel":"Update"}<ChevronRight size={13}/>
                    </button>
                  </SettingsRow>
                </SectionCard>

                {changingPw && (
                  <SectionCard title="Change Password" ds={ds}>
                    <form onSubmit={handleChangePw} className="flex flex-col gap-3">
                      {[{label:"Current Password",key:"current"},{label:"New Password",key:"next"},{label:"Confirm New",key:"confirm"}].map(({ label, key }) => (
                        <div key={key} className="flex flex-col gap-1.5">
                          <label className="text-xs font-medium" style={{ color: ds.textMuted }}>{label}</label>
                          <div className="flex items-center gap-2 rounded-xl px-4 py-2.5"
                            style={{ background:ds.inputBg, border:`1px solid ${ds.inputBorder}` }}>
                            <Lock size={13} style={{ color: ds.textMuted }} className="shrink-0"/>
                            <input type={showPw[key as keyof typeof showPw]?"text":"password"}
                              value={pwForm[key as keyof typeof pwForm]}
                              onChange={(e) => setPwForm((p) => ({...p,[key]:e.target.value}))}
                              placeholder="••••••••" className="flex-1 bg-transparent outline-none text-sm" style={{ color:ds.textPrimary }}/>
                            <button type="button" onClick={() => setShowPw((p) => ({...p,[key]:!p[key as keyof typeof p]}))} style={{ color: ds.textMuted }}>
                              {showPw[key as keyof typeof showPw] ? <EyeOff size={13}/> : <Eye size={13}/>}
                            </button>
                          </div>
                        </div>
                      ))}
                      <div className="flex gap-3 mt-1">
                        <button type="button" onClick={() => setChangingPw(false)}
                          className="flex-1 py-2.5 rounded-xl text-sm font-medium transition-colors"
                          style={{ background:ds.subBg, color:ds.textSecondary }}>Cancel</button>
                        <button type="submit" className="flex-1 py-2.5 rounded-xl text-sm font-medium text-white"
                          style={{ background:"linear-gradient(90deg,#22c55e,#06b6d4)" }}>Update Password</button>
                      </div>
                    </form>
                  </SectionCard>
                )}

                <SectionCard title="Active Sessions" ds={ds}>
                  {sessions.map((s) => (
                    <div key={s.id} className="flex items-center justify-between py-3" style={{ borderBottom:`1px solid ${ds.divider}` }}>
                      <div className="flex items-center gap-3">
                        <Smartphone size={16} style={{ color: ds.textMuted }}/>
                        <div>
                          <p className="text-sm" style={{ color: ds.textSecondary }}>{s.device}</p>
                          <p className="text-xs" style={{ color: ds.textMuted }}>{s.location} · {s.time}</p>
                        </div>
                      </div>
                      {s.current
                        ? <span className="text-xs px-2 py-0.5 rounded-full" style={{ background:ds.isDark?"rgba(34,197,94,0.15)":"#dcfce7",color:"#16a34a" }}>Current</span>
                        : <button onClick={() => handleRevoke(s.id)} className="text-xs text-red-400 hover:text-red-300 transition-colors">Revoke</button>}
                    </div>
                  ))}
                </SectionCard>
              </>
            )}

            {/* ── Notifications ── */}
            {tab === "notifications" && (
              <>
                <SectionCard title="Trading Alerts" ds={ds}>
                  {[{key:"priceAlerts",label:"Price Alerts",desc:"When an asset hits your target price"},{key:"orderFills",label:"Order Fills",desc:"When a limit or stop order is filled"},{key:"deposits",label:"Deposits",desc:"When funds arrive in your wallet"},{key:"withdrawals",label:"Withdrawals",desc:"When funds leave your wallet"}].map(({ key, label, desc }) => (
                    <SettingsRow key={key} label={label} desc={desc} ds={ds}>
                      <Toggle value={notifs[key as keyof typeof notifs]} onChange={(v) => setNotifs((p) => ({...p,[key]:v}))}/>
                    </SettingsRow>
                  ))}
                </SectionCard>
                <SectionCard title="General" ds={ds}>
                  {[{key:"newsletter",label:"Newsletter",desc:"Weekly market roundup"},{key:"security",label:"Security Alerts",desc:"Sign-ins and suspicious activity"},{key:"pushMobile",label:"Push Notifications",desc:"On your mobile app"},{key:"emailDigest",label:"Daily Email Digest",desc:"Summary of your portfolio"}].map(({ key, label, desc }) => (
                    <SettingsRow key={key} label={label} desc={desc} ds={ds}>
                      <Toggle value={notifs[key as keyof typeof notifs]} onChange={(v) => setNotifs((p) => ({...p,[key]:v}))}/>
                    </SettingsRow>
                  ))}
                </SectionCard>
              </>
            )}

            {/* ── API Keys ── */}
            {tab === "api" && (
              <SectionCard title="API Keys" ds={ds}>
                <p className="text-xs mb-4 leading-relaxed" style={{ color: ds.textMuted }}>Use API keys to connect third-party apps and trading bots.</p>
                <div className="flex flex-col gap-3 mb-5">
                  {apiKeys.map((ak) => (
                    <div key={ak.id} className="rounded-xl p-4" style={{ border:`1px solid ${ds.border}` }}>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-medium" style={{ color: ds.textPrimary }}>{ak.name}</p>
                          <span className="text-xs px-2 py-0.5 rounded-full"
                            style={ak.active ? { background:ds.isDark?"rgba(34,197,94,0.15)":"#dcfce7",color:"#16a34a" } : { background:ds.subBg,color:ds.textMuted }}>
                            {ak.active?"Active":"Inactive"}
                          </span>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-xs" style={{ color: ds.textMuted }}>{ak.perms} · {ak.created}</span>
                          <button onClick={() => handleDeleteKey(ak.id)} style={{ color: ds.textMuted }}
                            onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.color = "#ef4444")}
                            onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.color = ds.textMuted)}>
                            <Trash2 size={13}/>
                          </button>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 rounded-xl px-3 py-2" style={{ background: ds.subBg }}>
                        <Key size={13} style={{ color: ds.textMuted }} className="shrink-0"/>
                        <span className="text-xs font-mono flex-1 truncate" style={{ color: ds.textSecondary }}>
                          {visibleKeys[ak.id] ? ak.key : maskKey(ak.key)}
                        </span>
                        <button onClick={() => setVisibleKeys((p) => ({...p,[ak.id]:!p[ak.id]}))} style={{ color: ds.textMuted }}>
                          {visibleKeys[ak.id] ? <EyeOff size={13}/> : <Eye size={13}/>}
                        </button>
                        <button onClick={() => { navigator.clipboard.writeText(ak.key).catch(()=>{}); setCopiedKey(ak.id); toast.success("Copied!"); setTimeout(()=>setCopiedKey(null),2000); }} style={{ color: ds.textMuted }}>
                          {copiedKey===ak.id ? <Check size={13} style={{ color:"#22c55e" }}/> : <Copy size={13}/>}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
                <button onClick={handleGenerateKey}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium text-white hover:opacity-90 transition-opacity"
                  style={{ background:"linear-gradient(90deg,#22c55e,#06b6d4)" }}>
                  <Plus size={14}/> Generate New Key
                </button>
              </SectionCard>
            )}

            {/* ── Billing ── */}
            {tab === "billing" && (
              <>
                <SectionCard title="Current Plan" ds={ds}>
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <p className="text-lg font-semibold" style={{ color: ds.textPrimary }}>Pro Trader</p>
                        <span className="text-xs px-2 py-0.5 rounded-full text-white" style={{ background:"linear-gradient(90deg,#22c55e,#06b6d4)" }}>Active</span>
                      </div>
                      <p className="text-sm" style={{ color: ds.textMuted }}>$49/month · renews Apr 2, 2026</p>
                      <ul className="mt-3 flex flex-col gap-1">
                        {["Unlimited trades","Advanced charts","Priority support","API access","0.05% trading fee"].map((f) => (
                          <li key={f} className="flex items-center gap-2 text-xs" style={{ color: ds.textMuted }}>
                            <Check size={12} style={{ color:"#22c55e" }}/>{f}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <button onClick={() => toast.info("Upgrade options coming soon!")} className="text-xs text-cyan-500 hover:text-cyan-400 transition-colors mt-1">Upgrade →</button>
                  </div>
                </SectionCard>

                <SectionCard title="Payment Methods" ds={ds}>
                  {payments.map((pm) => (
                    <div key={pm.id} className="flex items-center justify-between py-3" style={{ borderBottom:`1px solid ${ds.divider}` }}>
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-7 rounded-lg flex items-center justify-center" style={{ background: ds.subBg }}>
                          <CreditCard size={16} style={{ color: ds.textMuted }}/>
                        </div>
                        <div>
                          <p className="text-sm" style={{ color: ds.textSecondary }}>{pm.type} ···· {pm.last4}</p>
                          <p className="text-xs" style={{ color: ds.textMuted }}>Expires {pm.exp}</p>
                        </div>
                      </div>
                      {pm.default
                        ? <span className="text-xs px-2 py-0.5 rounded-full" style={{ background:ds.isDark?"rgba(34,197,94,0.15)":"#dcfce7",color:"#16a34a" }}>Default</span>
                        : <button onClick={() => handleSetDefault(pm.id)} className="text-xs text-cyan-500 hover:text-cyan-400 transition-colors">Set default</button>}
                    </div>
                  ))}

                  {addingCard ? (
                    <form onSubmit={handleAddCard} className="mt-4 flex flex-col gap-3 p-4 rounded-xl" style={{ background:ds.subBg }}>
                      <p className="text-xs font-medium" style={{ color: ds.textSecondary }}>Add New Card</p>
                      {[{label:"Cardholder Name",key:"name",type:"text",placeholder:"Eden Ellis"},{label:"Card Number",key:"number",type:"text",placeholder:"1234 5678 9012 3456"},{label:"Expiry (MM/YY)",key:"exp",type:"text",placeholder:"09/27"},{label:"CVV",key:"cvv",type:"text",placeholder:"123"}].map(({ label, key, type, placeholder }) => (
                        <div key={key}>
                          <label className="text-xs mb-1 block" style={{ color: ds.textMuted }}>{label}</label>
                          <input type={type} placeholder={placeholder} value={cardForm[key as keyof typeof cardForm]}
                            onChange={(e) => setCardForm((p) => ({...p,[key]:e.target.value}))}
                            style={{ ...inputCls, background:ds.card }}
                            onFocus={(e) => (e.currentTarget.style.borderColor="#06b6d4")}
                            onBlur={(e)  => (e.currentTarget.style.borderColor=ds.inputBorder)}/>
                        </div>
                      ))}
                      <div className="flex gap-2">
                        <button type="button" onClick={() => setAddingCard(false)}
                          className="flex-1 py-2 rounded-xl text-xs font-medium transition-colors"
                          style={{ background:ds.card, color:ds.textSecondary, border:`1px solid ${ds.border}` }}>Cancel</button>
                        <button type="submit" className="flex-1 py-2 rounded-xl text-xs font-medium text-white"
                          style={{ background:"linear-gradient(90deg,#22c55e,#06b6d4)" }}>Add Card</button>
                      </div>
                    </form>
                  ) : (
                    <button onClick={() => setAddingCard(true)} className="mt-4 flex items-center gap-1.5 text-xs text-cyan-500 hover:text-cyan-400 transition-colors">
                      <Plus size={12}/> Add payment method
                    </button>
                  )}
                </SectionCard>

                <SectionCard title="Danger Zone" ds={ds}>
                  <div className="flex items-center justify-between py-2">
                    <div>
                      <p className="text-sm" style={{ color: ds.textSecondary }}>Cancel Subscription</p>
                      <p className="text-xs" style={{ color: ds.textMuted }}>Plan stays active until Apr 2, 2026</p>
                    </div>
                    <button onClick={() => toast.error("Contact support to cancel.")}
                      className="text-xs text-red-400 hover:text-red-300 px-3 py-1.5 rounded-lg transition-colors"
                      style={{ border:"1px solid rgba(239,68,68,0.3)" }}>Cancel Plan</button>
                  </div>
                </SectionCard>
              </>
            )}
          </div>
        </div>
      </main>
    </>
  );
}
