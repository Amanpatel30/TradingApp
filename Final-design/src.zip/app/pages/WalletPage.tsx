import { useState } from "react";
import { useNavigate } from "react-router";
import { ArrowUpRight, ArrowDownLeft, Plus, RefreshCw, Copy, Check, TrendingUp, TrendingDown, X } from "lucide-react";
import { AreaChart, Area, ResponsiveContainer } from "recharts";
import { toast } from "sonner";
import { PageHeader } from "../components/PageHeader";
import { useDS } from "../context/ThemeContext";

const sparkBTC = [42,46,44,48,52,50,55,58,54,60,57,62,60,65,67].map((v,i)=>({i,v}));
const sparkETH = [30,28,32,35,31,36,34,38,36,40,38,42,39,41,40].map((v,i)=>({i,v}));
const sparkSOL = [10,12,11,14,13,16,15,18,16,20,18,22,21,23,22].map((v,i)=>({i,v}));

const assets = [
  { symbol: "BTC",  name: "Bitcoin",   balance: "0.7241",  value: "$48,862.50", alloc: 45, change: "+2.34%", up: true,  color: "#f59e0b", spark: sparkBTC },
  { symbol: "ETH",  name: "Ethereum",  balance: "3.850",   value: "$13,558.83", alloc: 28, change: "-1.12%", up: false, color: "#8b5cf6", spark: sparkETH },
  { symbol: "SOL",  name: "Solana",    balance: "38.20",   value: "$6,817.72",  alloc: 15, change: "+5.67%", up: true,  color: "#06b6d4", spark: sparkSOL },
  { symbol: "BNB",  name: "BNB Chain", balance: "6.50",    value: "$3,849.95",  alloc: 8,  change: "+0.88%", up: true,  color: "#22c55e", spark: sparkBTC },
  { symbol: "LINK", name: "Chainlink", balance: "124.00",  value: "$1,825.28",  alloc: 4,  change: "-2.45%", up: false, color: "#3b82f6", spark: sparkETH },
];

const txHistory = [
  { id: 1, type: "receive", asset: "BTC",  amount: "+0.045 BTC", usd: "+$3,036", date: "Mar 2",  hash: "0x4a2b…9f3c" },
  { id: 2, type: "send",    asset: "ETH",  amount: "-1.20 ETH",  usd: "-$4,226", date: "Mar 1",  hash: "0x7d1e…2a8b" },
  { id: 3, type: "receive", asset: "SOL",  amount: "+12.5 SOL",  usd: "+$2,230", date: "Feb 28", hash: "0x9c3f…1d5e" },
  { id: 4, type: "send",    asset: "BNB",  amount: "-2.0 BNB",   usd: "-$1,185", date: "Feb 27", hash: "0x2f8a…6b4d" },
  { id: 5, type: "receive", asset: "LINK", amount: "+80 LINK",   usd: "+$1,178", date: "Feb 26", hash: "0x5e7c…3a9f" },
];

type ModalType = "send" | "receive" | null;

export function WalletPage() {
  const navigate = useNavigate();
  const ds = useDS();
  const [copied, setCopied] = useState(false);
  const [modal, setModal]   = useState<ModalType>(null);
  const [sendAsset, setSendAsset] = useState("BTC");
  const [sendAddr, setSendAddr]   = useState("");
  const [sendAmt, setSendAmt]     = useState("");

  const handleCopy = () => {
    navigator.clipboard.writeText("0x4a2b3f...9f3c8d").catch(() => {});
    setCopied(true); setTimeout(() => setCopied(false), 2000);
  };

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sendAddr.trim()) { toast.error("Please enter a recipient address"); return; }
    if (!sendAmt || parseFloat(sendAmt) <= 0) { toast.error("Please enter a valid amount"); return; }
    toast.success(`Sent ${sendAmt} ${sendAsset} successfully`);
    setModal(null); setSendAddr(""); setSendAmt("");
  };

  const modalBg = {
    position: "fixed" as const, inset: 0, zIndex: 50,
    display: "flex", alignItems: "center", justifyContent: "center",
  };

  const modalCard = {
    position: "relative" as const, borderRadius: "16px", width: "100%", maxWidth: "400px", margin: "0 16px",
    padding: "24px", background: ds.card, boxShadow: "0 20px 60px rgba(0,0,0,0.3)",
    border: `1px solid ${ds.border}`,
  };

  const inputStyle = {
    width: "100%", background: ds.inputBg, border: `1px solid ${ds.inputBorder}`,
    borderRadius: "12px", padding: "10px 16px", fontSize: "14px", color: ds.textPrimary,
    outline: "none",
  };

  return (
    <>
      <PageHeader title="Wallet" />
      <main className="flex-1 px-6 pb-8 overflow-auto">

        {/* Hero balance card */}
        <div className="rounded-2xl p-6 mb-5 text-white relative overflow-hidden"
          style={{ background: "linear-gradient(135deg, #1a1a2e 0%, #0f3460 60%, #16213e 100%)" }}>
          <div className="absolute inset-0 opacity-10"
            style={{ backgroundImage: "radial-gradient(circle at 80% 50%, #06b6d4 0%, transparent 60%)" }} />
          <p className="text-sm mb-1" style={{ color: "#94a3b8" }}>Total Portfolio Value</p>
          <p className="text-4xl font-semibold mb-1">$74,914.28</p>
          <div className="flex items-center gap-2 mb-6">
            <span className="flex items-center gap-1 text-sm" style={{ color: "#22c55e" }}><TrendingUp size={14}/> +$1,284.50</span>
            <span className="text-sm" style={{ color: "#64748b" }}>+1.74% today</span>
          </div>
          <div className="flex items-center gap-3 mb-5">
            <div className="bg-white/10 backdrop-blur px-4 py-2 rounded-xl flex items-center gap-2">
              <span className="text-xs font-mono" style={{ color: "#cbd5e1" }}>0x4a2b3f...9f3c8d</span>
              <button onClick={handleCopy} className="transition-colors hover:text-white" style={{ color: "#94a3b8" }}>
                {copied ? <Check size={13} style={{ color: "#22c55e" }}/> : <Copy size={13}/>}
              </button>
            </div>
          </div>
          <div className="flex gap-3">
            {[
              { icon: ArrowUpRight,  label: "Send",    action: () => setModal("send"),   grad: "linear-gradient(90deg,#22c55e,#06b6d4)" },
              { icon: ArrowDownLeft, label: "Receive", action: () => setModal("receive"), grad: "rgba(255,255,255,0.1)" },
              { icon: Plus,          label: "Buy",     action: () => navigate("/trade"),  grad: "rgba(255,255,255,0.1)" },
              { icon: RefreshCw,     label: "Swap",    action: () => navigate("/trade"),  grad: "rgba(255,255,255,0.1)" },
            ].map(({ icon: Icon, label, action, grad }) => (
              <button key={label} onClick={action}
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium text-white hover:opacity-90 transition-all"
                style={{ background: grad }}>
                <Icon size={15}/>{label}
              </button>
            ))}
          </div>
        </div>

        <div className="flex gap-5">
          {/* Assets table */}
          <div className="rounded-2xl flex-1 min-w-0 overflow-hidden transition-colors duration-300"
            style={{ background: ds.card, boxShadow: ds.cardShadow }}>
            <div className="px-5 pt-5 pb-3 flex items-center justify-between">
              <p className="text-sm font-semibold" style={{ color: ds.textPrimary }}>Your Assets</p>
              <span className="text-xs" style={{ color: ds.textMuted }}>{assets.length} tokens</span>
            </div>
            <table className="w-full text-sm">
              <thead>
                <tr style={{ background: ds.subBg }}>
                  {["Asset","Balance","Value","Allocation","24h","7d Chart",""].map((h) => (
                    <th key={h} className="text-left text-xs font-medium px-5 py-2.5 whitespace-nowrap" style={{ color: ds.textMuted }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {assets.map((a) => (
                  <tr key={a.symbol} className="transition-colors" style={{ borderTop: `1px solid ${ds.divider}` }}
                    onMouseEnter={(e) => (e.currentTarget.style.background = ds.hoverBg)}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-xs font-bold shrink-0"
                          style={{ background: a.color }}>{a.symbol[0]}</div>
                        <div>
                          <p className="text-sm font-semibold" style={{ color: ds.textPrimary }}>{a.symbol}</p>
                          <p className="text-xs" style={{ color: ds.textMuted }}>{a.name}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-3.5 text-sm" style={{ color: ds.textSecondary }}>{a.balance}</td>
                    <td className="px-5 py-3.5 text-sm font-medium" style={{ color: ds.textPrimary }}>{a.value}</td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-1.5 rounded-full overflow-hidden" style={{ background: ds.subBg2 }}>
                          <div className="h-full rounded-full" style={{ width: `${a.alloc}%`, background: a.color }}/>
                        </div>
                        <span className="text-xs" style={{ color: ds.textMuted }}>{a.alloc}%</span>
                      </div>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className="flex items-center gap-1 text-xs font-medium" style={{ color: a.up ? "#22c55e" : "#ef4444" }}>
                        {a.up ? <TrendingUp size={11}/> : <TrendingDown size={11}/>}{a.change}
                      </span>
                    </td>
                    <td className="px-5 py-3.5">
                      <ResponsiveContainer width={80} height={32}>
                        <AreaChart data={a.spark}>
                          <defs>
                            <linearGradient id={`sg${a.symbol}`} x1="0" y1="0" x2="0" y2="1">
                              <stop offset="0%" stopColor={a.up ? "#22c55e" : "#ef4444"} stopOpacity={0.2}/>
                              <stop offset="100%" stopColor={a.up ? "#22c55e" : "#ef4444"} stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <Area type="monotone" dataKey="v" stroke={a.up ? "#22c55e" : "#ef4444"}
                            strokeWidth={1.5} fill={`url(#sg${a.symbol})`} dot={false}/>
                        </AreaChart>
                      </ResponsiveContainer>
                    </td>
                    <td className="px-5 py-3.5">
                      <button onClick={() => navigate(`/portfolio/${a.symbol}`)} className="text-xs text-cyan-500 hover:text-cyan-400 transition-colors">
                        Details →
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Transactions */}
          <div className="rounded-2xl w-64 shrink-0 transition-colors duration-300"
            style={{ background: ds.card, boxShadow: ds.cardShadow }}>
            <div className="px-5 pt-5 pb-3">
              <p className="text-sm font-semibold" style={{ color: ds.textPrimary }}>Transactions</p>
            </div>
            <div style={{ borderTop: `1px solid ${ds.divider}` }}>
              {txHistory.map((tx) => (
                <div key={tx.id} className="px-5 py-3" style={{ borderBottom: `1px solid ${ds.divider}` }}>
                  <div className="flex items-center justify-between mb-0.5">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-lg flex items-center justify-center shrink-0"
                        style={tx.type === "receive"
                          ? { background: ds.isDark ? "rgba(34,197,94,0.15)"  : "#dcfce7" }
                          : { background: ds.isDark ? "rgba(239,68,68,0.15)"  : "#fee2e2" }}>
                        {tx.type === "receive"
                          ? <ArrowDownLeft size={12} style={{ color: "#16a34a" }}/>
                          : <ArrowUpRight  size={12} style={{ color: "#dc2626" }}/>}
                      </div>
                      <span className="text-xs font-medium capitalize" style={{ color: ds.textSecondary }}>{tx.type}</span>
                    </div>
                    <span className="text-xs font-semibold" style={{ color: tx.type === "receive" ? "#16a34a" : "#dc2626" }}>
                      {tx.usd}
                    </span>
                  </div>
                  <p className="text-xs ml-8" style={{ color: ds.textMuted }}>{tx.amount}</p>
                  <div className="flex items-center justify-between ml-8 mt-0.5">
                    <span className="text-xs font-mono" style={{ color: ds.textMuted, opacity: 0.7 }}>{tx.hash}</span>
                    <span className="text-xs" style={{ color: ds.textMuted, opacity: 0.7 }}>{tx.date}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>

      {/* Send Modal */}
      {modal === "send" && (
        <div style={modalBg}>
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setModal(null)} />
          <div style={modalCard}>
            <div className="flex items-center justify-between mb-5">
              <p className="text-base font-semibold" style={{ color: ds.textPrimary }}>Send Crypto</p>
              <button onClick={() => setModal(null)} style={{ color: ds.textMuted }}><X size={18}/></button>
            </div>
            <form onSubmit={handleSend} className="flex flex-col gap-4">
              <div>
                <label className="text-xs font-medium mb-1 block" style={{ color: ds.textMuted }}>Asset</label>
                <select value={sendAsset} onChange={(e) => setSendAsset(e.target.value)} style={{ ...inputStyle, cursor: "pointer" }}>
                  {assets.map((a) => <option key={a.symbol} value={a.symbol}>{a.symbol} — {a.name}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs font-medium mb-1 block" style={{ color: ds.textMuted }}>Recipient Address</label>
                <input value={sendAddr} onChange={(e) => setSendAddr(e.target.value)} placeholder="0x…" style={{ ...inputStyle, fontFamily: "monospace" }}
                  onFocus={(e) => (e.currentTarget.style.borderColor = "#06b6d4")}
                  onBlur={(e)  => (e.currentTarget.style.borderColor = ds.inputBorder)} />
              </div>
              <div>
                <label className="text-xs font-medium mb-1 block" style={{ color: ds.textMuted }}>Amount</label>
                <div className="flex items-center gap-2 rounded-xl px-4 py-2.5"
                  style={{ background: ds.inputBg, border: `1px solid ${ds.inputBorder}` }}>
                  <input type="number" step="any" min="0" value={sendAmt} onChange={(e) => setSendAmt(e.target.value)}
                    placeholder="0.00" className="flex-1 bg-transparent outline-none text-sm" style={{ color: ds.textPrimary }}/>
                  <span className="text-xs font-medium px-2 py-0.5 rounded-md" style={{ background: ds.subBg2, color: ds.textMuted }}>{sendAsset}</span>
                </div>
              </div>
              <div className="flex gap-3 mt-1">
                <button type="button" onClick={() => setModal(null)}
                  className="flex-1 py-2.5 rounded-xl text-sm font-medium transition-colors"
                  style={{ background: ds.subBg, color: ds.textSecondary }}>Cancel</button>
                <button type="submit"
                  className="flex-1 py-2.5 rounded-xl text-sm font-medium text-white"
                  style={{ background: "linear-gradient(90deg,#22c55e,#06b6d4)" }}>Send</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Receive Modal */}
      {modal === "receive" && (
        <div style={modalBg}>
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setModal(null)} />
          <div style={modalCard}>
            <div className="flex items-center justify-between mb-5">
              <p className="text-base font-semibold" style={{ color: ds.textPrimary }}>Receive Crypto</p>
              <button onClick={() => setModal(null)} style={{ color: ds.textMuted }}><X size={18}/></button>
            </div>
            <div className="flex justify-center mb-4">
              <div className="w-40 h-40 rounded-2xl flex flex-col items-center justify-center gap-2"
                style={{ background: ds.subBg, border: `1px solid ${ds.border}` }}>
                <div className="grid grid-cols-5 gap-0.5">
                  {Array.from({length: 25}).map((_, i) => (
                    <div key={i} className="w-5 h-5 rounded-sm"
                      style={{ background: [0,1,2,5,6,10,12,14,18,20,22,23,24].includes(i) ? ds.textPrimary : "transparent" }}/>
                  ))}
                </div>
                <p className="text-xs" style={{ color: ds.textMuted }}>Scan QR</p>
              </div>
            </div>
            <p className="text-xs text-center mb-2" style={{ color: ds.textMuted }}>Your wallet address</p>
            <div className="flex items-center gap-2 rounded-xl px-4 py-2.5" style={{ background: ds.inputBg, border: `1px solid ${ds.inputBorder}` }}>
              <span className="text-xs font-mono flex-1 truncate" style={{ color: ds.textSecondary }}>0x4a2b3f9c8d1e7f2a5b6c3d0e9f4a2b3f9c8d</span>
              <button onClick={() => { handleCopy(); toast.success("Address copied!"); }} style={{ color: ds.textMuted }}>
                <Copy size={13}/>
              </button>
            </div>
            <p className="text-xs text-center mt-3" style={{ color: ds.textMuted }}>Only send ETH-compatible tokens to this address</p>
            <button onClick={() => setModal(null)} className="w-full mt-4 py-2.5 rounded-xl text-sm font-medium text-white"
              style={{ background: "linear-gradient(90deg,#22c55e,#06b6d4)" }}>Done</button>
          </div>
        </div>
      )}
    </>
  );
}