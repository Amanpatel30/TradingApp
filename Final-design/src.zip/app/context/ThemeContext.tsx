import { createContext, useContext, useState, useEffect, ReactNode } from "react";

interface ThemeContextType {
  isDark: boolean;
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextType>({
  isDark: false,
  toggleTheme: () => {},
});

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [isDark, setIsDark] = useState(() => {
    try { return localStorage.getItem("cc-theme") === "dark"; } catch { return false; }
  });

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
    try { localStorage.setItem("cc-theme", isDark ? "dark" : "light"); } catch {}
  }, [isDark]);

  const toggleTheme = () => setIsDark((p) => !p);

  return (
    <ThemeContext.Provider value={{ isDark, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export const useTheme = () => useContext(ThemeContext);

/* ─── Shared dark-aware style helpers ────────────────────────────────────── */
export function useDS() {
  const { isDark } = useTheme();
  return {
    isDark,
    pageBg: isDark
      ? "linear-gradient(135deg, #06061a 0%, #080f20 60%, #06100a 100%)"
      : "linear-gradient(135deg, #f5f3ff 0%, #ecf4fb 60%, #e8f5e9 100%)",
    sidebar: isDark ? "#0b0b1e" : "#ffffff",
    sidebarShadow: isDark
      ? "2px 0 12px rgba(0,0,0,0.4)"
      : "2px 0 12px rgba(0,0,0,0.04)",
    card: isDark ? "#111127" : "#ffffff",
    cardShadow: isDark
      ? "0 1px 3px rgba(0,0,0,0.4)"
      : "0 1px 3px rgba(0,0,0,0.06)",
    subBg: isDark ? "#1a1a2e" : "#f9fafb",
    subBg2: isDark ? "#1e1e32" : "#f3f4f6",
    border: isDark ? "rgba(255,255,255,0.07)" : "#f3f4f6",
    borderMid: isDark ? "rgba(255,255,255,0.10)" : "#e5e7eb",
    divider: isDark ? "rgba(255,255,255,0.05)" : "#f9fafb",
    textPrimary: isDark ? "#f1f5f9" : "#111827",
    textSecondary: isDark ? "#94a3b8" : "#4b5563",
    textMuted: isDark ? "#475569" : "#9ca3af",
    textPlaceholder: isDark ? "#334155" : "#d1d5db",
    hoverBg: isDark ? "rgba(255,255,255,0.04)" : "#f9fafb",
    inputBg: isDark ? "#1a1a2e" : "#f9fafb",
    inputBorder: isDark ? "rgba(255,255,255,0.10)" : "#f3f4f6",
    badge: (base: string) => isDark ? base.replace("#f3f4f6","#1f2937").replace("#fff","#1a1a2e") : base,
    navInactive: isDark ? "#64748b" : "#6b7280",
  };
}
