import { ReactNode } from "react";
import { TrendingUp, ShieldCheck, Zap } from "lucide-react";

const features = [
  { icon: TrendingUp, title: "Real-time Trading", desc: "Live order books and instant execution across 200+ pairs." },
  { icon: ShieldCheck, title: "Bank-grade Security", desc: "256-bit encryption and two-factor authentication built in." },
  { icon: Zap, title: "Lightning Fast", desc: "Sub-millisecond order matching with 99.99% uptime." },
];

const tickers = [
  { symbol: "BTC", price: "$67,482", change: "+2.34%", up: true },
  { symbol: "ETH", price: "$3,521", change: "-1.12%", up: false },
  { symbol: "SOL", price: "$178.42", change: "+5.67%", up: true },
];

export function AuthLayout({ children }: { children: ReactNode }) {
  return (
    <div
      className="min-h-screen flex items-center justify-center p-6"
      style={{ background: "linear-gradient(135deg, #f5f3ff 0%, #ecf4fb 60%, #e8f5e9 100%)" }}
    >
      {/* Decorative blobs */}
      <div
        className="fixed pointer-events-none"
        style={{
          top: "-120px", left: "-120px", width: "480px", height: "480px",
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(139,92,246,0.08) 0%, transparent 70%)",
        }}
      />
      <div
        className="fixed pointer-events-none"
        style={{
          bottom: "-100px", right: "-100px", width: "500px", height: "500px",
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(6,182,212,0.07) 0%, transparent 70%)",
        }}
      />

      {/* Card shell */}
      <div
        className="relative w-full max-w-4xl bg-white rounded-3xl overflow-hidden"
        style={{ boxShadow: "0 20px 60px rgba(0,0,0,0.08), 0 4px 16px rgba(0,0,0,0.04)" }}
      >
        <div className="flex min-h-[580px]">

          {/* ── Left panel ── */}
          <div
            className="hidden md:flex flex-col justify-between w-[360px] shrink-0 p-10"
            style={{
              background: "linear-gradient(160deg, #1a1a2e 0%, #0f3460 60%, #16213e 100%)",
            }}
          >
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{ background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.1)" }}
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <defs>
                    <linearGradient id="lgLeft" x1="0" y1="0" x2="24" y2="24" gradientUnits="userSpaceOnUse">
                      <stop stopColor="#22c55e" /><stop offset="1" stopColor="#06b6d4" />
                    </linearGradient>
                  </defs>
                  <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"
                    stroke="url(#lgLeft)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <div>
                <p className="text-xs font-semibold text-white tracking-widest">CRYPTO</p>
                <p className="text-xs font-semibold text-white tracking-widest">CRACK</p>
              </div>
            </div>

            {/* Headline */}
            <div className="flex-1 flex flex-col justify-center py-8 gap-6">
              <div>
                <h2 className="text-white text-2xl font-semibold leading-snug">
                  Trade smarter.<br />
                  <span
                    className="bg-clip-text text-transparent"
                    style={{ backgroundImage: "linear-gradient(90deg, #22c55e, #06b6d4)" }}
                  >
                    Grow faster.
                  </span>
                </h2>
                <p className="text-sm mt-2" style={{ color: "#94a3b8" }}>
                  Join 183,000+ traders on the fastest crypto platform.
                </p>
              </div>

              {/* Features */}
              <div className="flex flex-col gap-4">
                {features.map(({ icon: Icon, title, desc }) => (
                  <div key={title} className="flex items-start gap-3">
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0 mt-0.5"
                      style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.08)" }}
                    >
                      <Icon size={15} style={{ color: "#06b6d4" }} />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-white">{title}</p>
                      <p className="text-xs mt-0.5" style={{ color: "#64748b" }}>{desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Live tickers */}
            <div className="flex flex-col gap-2">
              <p className="text-xs mb-1" style={{ color: "#475569" }}>Live market</p>
              {tickers.map((t) => (
                <div
                  key={t.symbol}
                  className="flex items-center justify-between px-3 py-2 rounded-xl"
                  style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.06)" }}
                >
                  <span className="text-xs font-semibold text-white">{t.symbol}</span>
                  <span className="text-xs" style={{ color: "#94a3b8" }}>{t.price}</span>
                  <span
                    className="text-xs font-medium px-1.5 py-0.5 rounded-full"
                    style={t.up
                      ? { background: "rgba(34,197,94,0.15)", color: "#22c55e" }
                      : { background: "rgba(239,68,68,0.15)", color: "#ef4444" }}
                  >
                    {t.change}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* ── Right panel (form slot) ── */}
          <div className="flex flex-col flex-1 justify-center px-8 md:px-12 py-10">
            {children}
          </div>

        </div>
      </div>
    </div>
  );
}
