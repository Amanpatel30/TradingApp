import { useState } from "react";
import { Link } from "react-router";
import { Mail, Lock, Eye, EyeOff, AlertCircle, Loader2 } from "lucide-react";
import { AuthLayout } from "./AuthLayout";

const DEMO = { email: "demo@cryptocrack.io", password: "password123" };

export function LoginPage() {
  const [email, setEmail]       = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [remember, setRemember] = useState(true);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState("");
  const [success, setSuccess]   = useState(false);

  const validate = () => {
    if (!email.trim())                              return "Please enter your email address.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return "Please enter a valid email address.";
    if (!password)                                  return "Please enter your password.";
    return "";
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const err = validate();
    if (err) { setError(err); return; }
    setError(""); setLoading(true);
    await new Promise((r) => setTimeout(r, 1400));
    setLoading(false);
    if (email !== DEMO.email || password !== DEMO.password) {
      setError("Invalid credentials. Try demo@cryptocrack.io / password123");
      return;
    }
    setSuccess(true);
  };

  return (
    <AuthLayout>
      {success ? (
        <div className="flex flex-col items-center justify-center gap-4 py-8">
          <div
            className="w-16 h-16 rounded-2xl flex items-center justify-center"
            style={{ background: "linear-gradient(135deg, rgba(34,197,94,0.12), rgba(6,182,212,0.12))", border: "1px solid rgba(6,182,212,0.15)" }}
          >
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
              <defs>
                <linearGradient id="ck" x1="4" y1="6" x2="20" y2="17" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#22c55e"/><stop offset="1" stopColor="#06b6d4"/>
                </linearGradient>
              </defs>
              <path d="M20 6L9 17l-5-5" stroke="url(#ck)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <div className="text-center">
            <p className="text-gray-800 font-semibold">Welcome back!</p>
            <p className="text-sm text-gray-400 mt-1">Redirecting to your dashboard…</p>
          </div>
          <Link
            to="/dashboard"
            className="mt-2 px-6 py-2.5 rounded-xl text-sm font-semibold text-white"
            style={{ background: "linear-gradient(90deg, #22c55e, #06b6d4)" }}
          >
            Go to Dashboard →
          </Link>
        </div>
      ) : (
        <>
          {/* Header */}
          <div className="mb-7">
            <h1 className="text-2xl font-semibold text-gray-900">Welcome back</h1>
            <p className="text-sm text-gray-400 mt-1">Sign in to your CryptoCrack account</p>
          </div>

          <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-4">

            {/* Error banner */}
            <div
              className="overflow-hidden transition-all duration-300"
              style={{ maxHeight: error ? "72px" : "0px", opacity: error ? 1 : 0 }}
            >
              <div
                className="flex items-start gap-2.5 rounded-xl px-4 py-3"
                style={{ background: "#fff1f2", border: "1px solid #fecdd3" }}
              >
                <AlertCircle size={15} className="shrink-0 mt-0.5 text-red-400" />
                <p className="text-xs text-red-500 leading-relaxed">{error}</p>
              </div>
            </div>

            {/* Email */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-medium text-gray-500">Email address</label>
              <div
                className="flex items-center gap-3 bg-gray-50 rounded-xl px-4 py-3 transition-all"
                style={{ border: "1.5px solid #f0f0f5" }}
                onFocus={() => {}} 
              >
                <Mail size={15} className="text-gray-300 shrink-0" />
                <input
                  type="email"
                  autoComplete="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => { setEmail(e.target.value); setError(""); }}
                  className="flex-1 bg-transparent outline-none text-sm text-gray-700 placeholder-gray-300"
                  style={{ caretColor: "#06b6d4" }}
                  onFocus={(e) => (e.currentTarget.parentElement!.style.borderColor = "#06b6d4")}
                  onBlur={(e)  => (e.currentTarget.parentElement!.style.borderColor = "#f0f0f5")}
                />
              </div>
            </div>

            {/* Password */}
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-medium text-gray-500">Password</label>
                <Link to="/forgot-password" className="text-xs text-cyan-500 hover:text-cyan-600 transition-colors">
                  Forgot password?
                </Link>
              </div>
              <div
                className="flex items-center gap-3 bg-gray-50 rounded-xl px-4 py-3 transition-all"
                style={{ border: "1.5px solid #f0f0f5" }}
              >
                <Lock size={15} className="text-gray-300 shrink-0" />
                <input
                  type={showPass ? "text" : "password"}
                  autoComplete="current-password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => { setPassword(e.target.value); setError(""); }}
                  className="flex-1 bg-transparent outline-none text-sm text-gray-700 placeholder-gray-300"
                  style={{ caretColor: "#06b6d4" }}
                  onFocus={(e) => (e.currentTarget.parentElement!.style.borderColor = "#06b6d4")}
                  onBlur={(e)  => (e.currentTarget.parentElement!.style.borderColor = "#f0f0f5")}
                />
                <button type="button" onClick={() => setShowPass(!showPass)} className="text-gray-300 hover:text-gray-500 transition-colors">
                  {showPass ? <EyeOff size={15}/> : <Eye size={15}/>}
                </button>
              </div>
            </div>

            {/* Remember me */}
            <label className="flex items-center gap-2.5 cursor-pointer select-none">
              <button
                type="button"
                onClick={() => setRemember(!remember)}
                className="w-4 h-4 rounded flex items-center justify-center shrink-0 transition-all"
                style={remember
                  ? { background: "linear-gradient(90deg,#22c55e,#06b6d4)", border: "none" }
                  : { background: "white", border: "1.5px solid #e5e7eb" }}
              >
                {remember && (
                  <svg width="9" height="9" viewBox="0 0 9 9" fill="none">
                    <path d="M1.5 4.5l2 2 4-4" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                )}
              </button>
              <span className="text-xs text-gray-500">Keep me signed in for 30 days</span>
            </label>

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="relative w-full flex items-center justify-center gap-2 rounded-xl py-3.5 mt-1 text-sm font-semibold text-white overflow-hidden transition-all active:scale-[0.98]"
              style={{
                background: loading ? "#e5e7eb" : "linear-gradient(90deg, #22c55e, #06b6d4)",
                color: loading ? "#9ca3af" : "white",
                cursor: loading ? "not-allowed" : "pointer",
                boxShadow: loading ? "none" : "0 4px 20px rgba(6,182,212,0.25)",
              }}
            >
              {loading
                ? <Loader2 size={17} className="animate-spin"/>
                : "Sign In"}
            </button>

            {/* Divider */}
            <div className="flex items-center gap-3">
              <div className="flex-1 h-px bg-gray-100" />
              <span className="text-xs text-gray-300">or</span>
              <div className="flex-1 h-px bg-gray-100" />
            </div>

            {/* Social */}
            <div className="flex gap-3">
              {[
                {
                  label: "Google",
                  icon: (
                    <svg width="16" height="16" viewBox="0 0 24 24">
                      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                    </svg>
                  ),
                },
                {
                  label: "Apple",
                  icon: (
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="#1a1a2e">
                      <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
                    </svg>
                  ),
                },
              ].map((s) => (
                <button
                  key={s.label}
                  type="button"
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs text-gray-500 bg-gray-50 hover:bg-gray-100 transition-colors"
                  style={{ border: "1.5px solid #f0f0f5" }}
                >
                  {s.icon} {s.label}
                </button>
              ))}
            </div>

            {/* Sign up */}
            <p className="text-center text-xs text-gray-400">
              Don't have an account?{" "}
              <Link to="/signup" className="text-cyan-500 hover:text-cyan-600 font-medium transition-colors">
                Create one →
              </Link>
            </p>
          </form>
        </>
      )}
    </AuthLayout>
  );
}