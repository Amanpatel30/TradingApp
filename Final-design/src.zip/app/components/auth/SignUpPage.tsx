import { useState } from "react";
import { Link } from "react-router";
import { User, Mail, Lock, Eye, EyeOff, AlertCircle, Loader2, CheckCircle2 } from "lucide-react";
import { AuthLayout } from "./AuthLayout";

function StrengthBar({ password }: { password: string }) {
  const checks = [
    password.length >= 8,
    /[A-Z]/.test(password),
    /[0-9]/.test(password),
    /[^A-Za-z0-9]/.test(password),
  ];
  const score = checks.filter(Boolean).length;
  const labels = ["", "Weak", "Fair", "Good", "Strong"];
  const colors = ["#e5e7eb", "#ef4444", "#f59e0b", "#22c55e", "#06b6d4"];

  if (!password) return null;

  return (
    <div className="flex flex-col gap-1.5 mt-1">
      <div className="flex gap-1">
        {[1, 2, 3, 4].map((i) => (
          <div
            key={i}
            className="flex-1 h-1 rounded-full transition-all duration-300"
            style={{ background: i <= score ? colors[score] : "#f0f0f5" }}
          />
        ))}
      </div>
      <p className="text-xs" style={{ color: colors[score] }}>{labels[score]}</p>
    </div>
  );
}

const requirements = [
  { label: "At least 8 characters", test: (p: string) => p.length >= 8 },
  { label: "One uppercase letter", test: (p: string) => /[A-Z]/.test(p) },
  { label: "One number", test: (p: string) => /[0-9]/.test(p) },
];

export function SignUpPage() {
  const [name, setName]         = useState("");
  const [email, setEmail]       = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm]   = useState("");
  const [showPass, setShowPass] = useState(false);
  const [showConf, setShowConf] = useState(false);
  const [agreed, setAgreed]     = useState(false);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState("");
  const [success, setSuccess]   = useState(false);

  const validate = () => {
    if (!name.trim())                               return "Please enter your full name.";
    if (!email.trim())                              return "Please enter your email address.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return "Please enter a valid email address.";
    if (password.length < 8)                        return "Password must be at least 8 characters.";
    if (password !== confirm)                       return "Passwords do not match.";
    if (!agreed)                                    return "Please accept the terms and conditions.";
    return "";
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const err = validate();
    if (err) { setError(err); return; }
    setError(""); setLoading(true);
    await new Promise((r) => setTimeout(r, 1600));
    setLoading(false);
    setSuccess(true);
  };

  return (
    <AuthLayout>
      {success ? (
        <div className="flex flex-col items-center justify-center gap-4 py-6">
          <div
            className="w-16 h-16 rounded-2xl flex items-center justify-center"
            style={{ background: "linear-gradient(135deg, rgba(34,197,94,0.12), rgba(6,182,212,0.12))", border: "1px solid rgba(6,182,212,0.15)" }}
          >
            <CheckCircle2 size={28} style={{ color: "#22c55e" }} />
          </div>
          <div className="text-center">
            <p className="text-gray-800 font-semibold">Account created!</p>
            <p className="text-sm text-gray-400 mt-1">Check your inbox to verify your email.</p>
          </div>
          <Link
            to="/login"
            className="mt-2 px-6 py-2.5 rounded-xl text-sm font-semibold text-white"
            style={{ background: "linear-gradient(90deg, #22c55e, #06b6d4)" }}
          >
            Sign In →
          </Link>
        </div>
      ) : (
        <>
          <div className="mb-6">
            <h1 className="text-2xl font-semibold text-gray-900">Create account</h1>
            <p className="text-sm text-gray-400 mt-1">Start trading in under 2 minutes</p>
          </div>

          <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-3.5">

            {/* Error */}
            <div
              className="overflow-hidden transition-all duration-300"
              style={{ maxHeight: error ? "72px" : "0px", opacity: error ? 1 : 0 }}
            >
              <div className="flex items-start gap-2.5 rounded-xl px-4 py-3" style={{ background: "#fff1f2", border: "1px solid #fecdd3" }}>
                <AlertCircle size={15} className="shrink-0 mt-0.5 text-red-400" />
                <p className="text-xs text-red-500 leading-relaxed">{error}</p>
              </div>
            </div>

            {/* Full name */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-medium text-gray-500">Full name</label>
              <div
                className="flex items-center gap-3 bg-gray-50 rounded-xl px-4 py-3 transition-all"
                style={{ border: "1.5px solid #f0f0f5" }}
              >
                <User size={15} className="text-gray-300 shrink-0" />
                <input
                  type="text"
                  autoComplete="name"
                  placeholder="Alex Johnson"
                  value={name}
                  onChange={(e) => { setName(e.target.value); setError(""); }}
                  className="flex-1 bg-transparent outline-none text-sm text-gray-700 placeholder-gray-300"
                  style={{ caretColor: "#06b6d4" }}
                  onFocus={(e) => (e.currentTarget.parentElement!.style.borderColor = "#06b6d4")}
                  onBlur={(e)  => (e.currentTarget.parentElement!.style.borderColor = "#f0f0f5")}
                />
              </div>
            </div>

            {/* Email */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-medium text-gray-500">Email address</label>
              <div
                className="flex items-center gap-3 bg-gray-50 rounded-xl px-4 py-3 transition-all"
                style={{ border: "1.5px solid #f0f0f5" }}
              >
                <Mail size={15} className="text-gray-300 shrink-0" />
                <input
                  type="email"
                  autoComplete="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => { setEmail(e.target.value); setError(""); }}
                  className="flex-1 bg-transparent outline-none text-sm text-gray-700 placeholder-gray-300"
                  style={{ caretColor: "#06b6d4" }}
                  onFocus={(e) => (e.currentTarget.parentElement!.style.borderColor = "#06b6d4")}
                  onBlur={(e)  => (e.currentTarget.parentElement!.style.borderColor = "#f0f0f5")}
                />
              </div>
            </div>

            {/* Password */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-medium text-gray-500">Password</label>
              <div
                className="flex items-center gap-3 bg-gray-50 rounded-xl px-4 py-3 transition-all"
                style={{ border: "1.5px solid #f0f0f5" }}
              >
                <Lock size={15} className="text-gray-300 shrink-0" />
                <input
                  type={showPass ? "text" : "password"}
                  autoComplete="new-password"
                  placeholder="Min. 8 characters"
                  value={password}
                  onChange={(e) => { setPassword(e.target.value); setError(""); }}
                  className="flex-1 bg-transparent outline-none text-sm text-gray-700 placeholder-gray-300"
                  style={{ caretColor: "#06b6d4" }}
                  onFocus={(e) => (e.currentTarget.parentElement!.style.borderColor = "#06b6d4")}
                  onBlur={(e)  => (e.currentTarget.parentElement!.style.borderColor = "#f0f0f5")}
                />
                <button type="button" onClick={() => setShowPass(!showPass)} className="text-gray-300 hover:text-gray-500 transition-colors">
                  {showPass ? <EyeOff size={15}/> : <Eye size={15}/>}
                </button>
              </div>
              <StrengthBar password={password} />
              {password && (
                <div className="flex flex-wrap gap-x-4 gap-y-1 mt-0.5">
                  {requirements.map((r) => (
                    <div key={r.label} className="flex items-center gap-1">
                      <div
                        className="w-3 h-3 rounded-full flex items-center justify-center"
                        style={{ background: r.test(password) ? "linear-gradient(90deg,#22c55e,#06b6d4)" : "#e5e7eb" }}
                      >
                        {r.test(password) && (
                          <svg width="7" height="7" viewBox="0 0 7 7" fill="none">
                            <path d="M1 3.5l1.5 1.5 3-3" stroke="white" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/>
                          </svg>
                        )}
                      </div>
                      <span className="text-xs" style={{ color: r.test(password) ? "#22c55e" : "#9ca3af" }}>{r.label}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Confirm password */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-medium text-gray-500">Confirm password</label>
              <div
                className="flex items-center gap-3 bg-gray-50 rounded-xl px-4 py-3 transition-all"
                style={{
                  border: confirm && confirm !== password
                    ? "1.5px solid #fecdd3"
                    : "1.5px solid #f0f0f5",
                }}
              >
                <Lock size={15} className="text-gray-300 shrink-0" />
                <input
                  type={showConf ? "text" : "password"}
                  autoComplete="new-password"
                  placeholder="Repeat password"
                  value={confirm}
                  onChange={(e) => { setConfirm(e.target.value); setError(""); }}
                  className="flex-1 bg-transparent outline-none text-sm text-gray-700 placeholder-gray-300"
                  style={{ caretColor: "#06b6d4" }}
                  onFocus={(e) => {
                    if (!confirm || confirm === password)
                      e.currentTarget.parentElement!.style.borderColor = "#06b6d4";
                  }}
                  onBlur={(e) => {
                    e.currentTarget.parentElement!.style.borderColor =
                      confirm && confirm !== password ? "#fecdd3" : "#f0f0f5";
                  }}
                />
                <button type="button" onClick={() => setShowConf(!showConf)} className="text-gray-300 hover:text-gray-500 transition-colors">
                  {showConf ? <EyeOff size={15}/> : <Eye size={15}/>}
                </button>
              </div>
              {confirm && confirm !== password && (
                <p className="text-xs text-red-400">Passwords don't match</p>
              )}
            </div>

            {/* Terms */}
            <label className="flex items-start gap-2.5 cursor-pointer select-none">
              <button
                type="button"
                onClick={() => setAgreed(!agreed)}
                className="w-4 h-4 rounded flex items-center justify-center shrink-0 mt-0.5 transition-all"
                style={agreed
                  ? { background: "linear-gradient(90deg,#22c55e,#06b6d4)", border: "none" }
                  : { background: "white", border: "1.5px solid #e5e7eb" }}
              >
                {agreed && (
                  <svg width="9" height="9" viewBox="0 0 9 9" fill="none">
                    <path d="M1.5 4.5l2 2 4-4" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                )}
              </button>
              <span className="text-xs text-gray-400 leading-relaxed">
                I agree to CryptoCrack's{" "}
                <a href="#" className="text-cyan-500 hover:underline">Terms of Service</a>{" "}
                and{" "}
                <a href="#" className="text-cyan-500 hover:underline">Privacy Policy</a>
              </span>
            </label>

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="relative w-full flex items-center justify-center gap-2 rounded-xl py-3.5 mt-1 text-sm font-semibold overflow-hidden transition-all active:scale-[0.98]"
              style={{
                background: loading ? "#e5e7eb" : "linear-gradient(90deg, #22c55e, #06b6d4)",
                color: loading ? "#9ca3af" : "white",
                cursor: loading ? "not-allowed" : "pointer",
                boxShadow: loading ? "none" : "0 4px 20px rgba(6,182,212,0.25)",
              }}
            >
              {loading ? <Loader2 size={17} className="animate-spin"/> : "Create Account"}
            </button>

            <p className="text-center text-xs text-gray-400">
              Already have an account?{" "}
              <Link to="/login" className="text-cyan-500 hover:text-cyan-600 font-medium transition-colors">
                Sign in →
              </Link>
            </p>
          </form>
        </>
      )}
    </AuthLayout>
  );
}
