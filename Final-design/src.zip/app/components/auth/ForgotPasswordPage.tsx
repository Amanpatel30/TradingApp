import { useState } from "react";
import { Link } from "react-router";
import { Mail, AlertCircle, Loader2, ArrowLeft, MailCheck } from "lucide-react";
import { AuthLayout } from "./AuthLayout";

export function ForgotPasswordPage() {
  const [email, setEmail]   = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError]   = useState("");
  const [sent, setSent]     = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim())                              { setError("Please enter your email address."); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { setError("Please enter a valid email address."); return; }
    setError(""); setLoading(true);
    await new Promise((r) => setTimeout(r, 1400));
    setLoading(false);
    setSent(true);
  };

  return (
    <AuthLayout>
      {sent ? (
        <div className="flex flex-col items-center justify-center gap-5 py-6">
          <div
            className="w-16 h-16 rounded-2xl flex items-center justify-center"
            style={{ background: "linear-gradient(135deg, rgba(34,197,94,0.1), rgba(6,182,212,0.1))", border: "1px solid rgba(6,182,212,0.15)" }}
          >
            <MailCheck size={28} style={{ color: "#06b6d4" }} />
          </div>
          <div className="text-center">
            <p className="text-gray-800 font-semibold">Check your inbox</p>
            <p className="text-sm text-gray-400 mt-1.5 leading-relaxed max-w-xs">
              We've sent a password reset link to<br />
              <span className="text-gray-600 font-medium">{email}</span>
            </p>
          </div>
          <div className="flex flex-col gap-2 w-full max-w-xs">
            <Link
              to="/login"
              className="flex items-center justify-center gap-2 rounded-xl py-3 text-sm font-semibold text-white"
              style={{ background: "linear-gradient(90deg, #22c55e, #06b6d4)", boxShadow: "0 4px 20px rgba(6,182,212,0.25)" }}
            >
              Back to Sign In
            </Link>
            <button
              onClick={() => { setSent(false); setEmail(""); }}
              className="text-xs text-gray-400 hover:text-gray-600 transition-colors py-2"
            >
              Didn't receive it? Resend email
            </button>
          </div>
        </div>
      ) : (
        <>
          <div className="mb-7">
            <Link to="/login" className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-gray-600 transition-colors mb-5">
              <ArrowLeft size={13}/> Back to sign in
            </Link>
            <h1 className="text-2xl font-semibold text-gray-900">Reset password</h1>
            <p className="text-sm text-gray-400 mt-1">
              Enter your email and we'll send you a reset link.
            </p>
          </div>

          <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-4">

            {/* Error */}
            <div
              className="overflow-hidden transition-all duration-300"
              style={{ maxHeight: error ? "72px" : "0px", opacity: error ? 1 : 0 }}
            >
              <div className="flex items-start gap-2.5 rounded-xl px-4 py-3" style={{ background: "#fff1f2", border: "1px solid #fecdd3" }}>
                <AlertCircle size={15} className="shrink-0 mt-0.5 text-red-400" />
                <p className="text-xs text-red-500 leading-relaxed">{error}</p>
              </div>
            </div>

            {/* Email */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-medium text-gray-500">Email address</label>
              <div
                className="flex items-center gap-3 bg-gray-50 rounded-xl px-4 py-3 transition-all"
                style={{ border: "1.5px solid #f0f0f5" }}
              >
                <Mail size={15} className="text-gray-300 shrink-0" />
                <input
                  type="email"
                  autoComplete="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => { setEmail(e.target.value); setError(""); }}
                  className="flex-1 bg-transparent outline-none text-sm text-gray-700 placeholder-gray-300"
                  style={{ caretColor: "#06b6d4" }}
                  onFocus={(e) => (e.currentTarget.parentElement!.style.borderColor = "#06b6d4")}
                  onBlur={(e)  => (e.currentTarget.parentElement!.style.borderColor = "#f0f0f5")}
                />
              </div>
            </div>

            {/* Info box */}
            <div
              className="flex items-start gap-3 rounded-xl px-4 py-3"
              style={{ background: "#f0fdf4", border: "1px solid #bbf7d0" }}
            >
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" className="shrink-0 mt-0.5">
                <circle cx="12" cy="12" r="10" stroke="#22c55e" strokeWidth="1.8"/>
                <path d="M12 8v4M12 16h.01" stroke="#22c55e" strokeWidth="2" strokeLinecap="round"/>
              </svg>
              <p className="text-xs text-green-700 leading-relaxed">
                The reset link expires in 15 minutes. Check your spam folder if you don't see the email.
              </p>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="relative w-full flex items-center justify-center gap-2 rounded-xl py-3.5 mt-1 text-sm font-semibold overflow-hidden transition-all active:scale-[0.98]"
              style={{
                background: loading ? "#e5e7eb" : "linear-gradient(90deg, #22c55e, #06b6d4)",
                color: loading ? "#9ca3af" : "white",
                cursor: loading ? "not-allowed" : "pointer",
                boxShadow: loading ? "none" : "0 4px 20px rgba(6,182,212,0.25)",
              }}
            >
              {loading ? <Loader2 size={17} className="animate-spin"/> : "Send Reset Link"}
            </button>

            <p className="text-center text-xs text-gray-400">
              Remember your password?{" "}
              <Link to="/login" className="text-cyan-500 hover:text-cyan-600 font-medium transition-colors">
                Sign in →
              </Link>
            </p>
          </form>
        </>
      )}
    </AuthLayout>
  );
}
