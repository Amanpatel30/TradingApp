import { useDS } from "../context/ThemeContext";

interface SkeletonProps {
  className?: string;
  height?: number | string;
  width?: number | string;
  rounded?: string;
  style?: React.CSSProperties;
}

export function Skeleton({ className = "", height = 16, width = "100%", rounded = "rounded-xl", style }: SkeletonProps) {
  const ds = useDS();
  return (
    <div
      className={`skeleton-pulse ${rounded} ${className}`}
      style={{ height, width, background: ds.subBg2, ...style }}
    />
  );
}

/** A full table-row skeleton – pass rowCount for multiple rows */
export function TableSkeleton({ rows = 5, cols = 6 }: { rows?: number; cols?: number }) {
  const ds = useDS();
  return (
    <>
      {Array.from({ length: rows }).map((_, i) => (
        <tr key={i} style={{ borderTop: `1px solid ${ds.divider}` }}>
          {Array.from({ length: cols }).map((_, j) => (
            <td key={j} className="px-5 py-3.5">
              <Skeleton height={12} rounded="rounded-md" width={j === 0 ? "60%" : j % 3 === 0 ? "40%" : "70%"} />
            </td>
          ))}
        </tr>
      ))}
    </>
  );
}

/** Card skeleton for grid layouts */
export function CardSkeleton({ lines = 3 }: { lines?: number }) {
  const ds = useDS();
  return (
    <div className="rounded-2xl p-5 flex flex-col gap-3" style={{ background: ds.card, boxShadow: ds.cardShadow }}>
      <Skeleton height={14} width="50%" />
      {Array.from({ length: lines }).map((_, i) => (
        <Skeleton key={i} height={10} width={i % 2 === 0 ? "80%" : "60%"} />
      ))}
    </div>
  );
}
