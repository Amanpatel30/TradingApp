import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { useDS } from "../context/ThemeContext";

const allData: Record<string, { time: string; price: number }[]> = {
  "1H": [
    { time: "12:00", price: 67100 }, { time: "12:10", price: 67230 }, { time: "12:20", price: 67180 },
    { time: "12:30", price: 67350 }, { time: "12:40", price: 67420 }, { time: "12:50", price: 67482 },
  ],
  "4H": [
    { time: "08:00", price: 66800 }, { time: "10:00", price: 67100 }, { time: "12:00", price: 66950 },
    { time: "14:00", price: 67300 }, { time: "16:00", price: 67482 }, { time: "18:00", price: 67420 },
  ],
  "1D": [
    { time: "00:00", price: 64200 }, { time: "02:00", price: 63800 }, { time: "04:00", price: 64900 },
    { time: "06:00", price: 65400 }, { time: "08:00", price: 66100 }, { time: "10:00", price: 65700 },
    { time: "12:00", price: 66800 }, { time: "14:00", price: 67100 }, { time: "16:00", price: 67482 },
    { time: "18:00", price: 67200 }, { time: "20:00", price: 67600 }, { time: "22:00", price: 67482 },
  ],
  "1W": [
    { time: "Mon", price: 64100 }, { time: "Tue", price: 65200 }, { time: "Wed", price: 63900 },
    { time: "Thu", price: 66400 }, { time: "Fri", price: 67482 }, { time: "Sat", price: 66800 }, { time: "Sun", price: 67200 },
  ],
  "1M": [
    { time: "W1", price: 60100 }, { time: "W2", price: 63400 }, { time: "W3", price: 65700 }, { time: "W4", price: 67482 },
  ],
};

const timeframes = ["1H", "4H", "1D", "1W", "1M"];

export function MiniChart({ tf, setTf }: { tf: string; setTf: (v: string) => void }) {
  const ds = useDS();
  const data = allData[tf] || allData["1D"];

  return (
    <div
      className="rounded-2xl p-5 transition-colors duration-300"
      style={{ background: ds.card, boxShadow: ds.cardShadow }}
    >
      <div className="flex items-center justify-between mb-4">
        <div>
          <p className="text-xs" style={{ color: ds.textMuted }}>BTC/USDT</p>
          <div className="flex items-baseline gap-2">
            <span className="text-xl font-semibold" style={{ color: ds.textPrimary }}>$67,482.50</span>
            <span className="text-xs font-medium" style={{ color: "#22c55e" }}>+2.34% (24h)</span>
          </div>
        </div>
        <div className="flex gap-1">
          {timeframes.map((t) => (
            <button key={t} onClick={() => setTf(t)}
              className="px-2.5 py-1 rounded-lg text-xs transition-all"
              style={tf === t
                ? { background: ds.isDark ? "rgba(6,182,212,0.15)" : "#ecfeff", color: "#06b6d4", fontWeight: 600 }
                : { color: ds.textMuted }}>
              {t}
            </button>
          ))}
        </div>
      </div>

      <ResponsiveContainer width="100%" height={160}>
        <AreaChart data={data} margin={{ top: 4, right: 0, left: -20, bottom: 0 }}>
          <defs>
            <linearGradient id="priceGrad" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#22c55e" />
              <stop offset="100%" stopColor="#06b6d4" />
            </linearGradient>
            <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#06b6d4" stopOpacity={ds.isDark ? 0.25 : 0.15} />
              <stop offset="100%" stopColor="#06b6d4" stopOpacity={0.01} />
            </linearGradient>
          </defs>
          <XAxis dataKey="time" tick={{ fontSize: 10, fill: ds.textMuted }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fontSize: 10, fill: ds.textMuted }} axisLine={false} tickLine={false}
            domain={["auto", "auto"]} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
          <Tooltip
            contentStyle={{
              border: "none", borderRadius: 10, fontSize: 12,
              background: ds.card,
              boxShadow: "0 4px 20px rgba(0,0,0,0.16)",
              color: ds.textPrimary,
            }}
            formatter={(val: number) => [`$${val.toLocaleString()}`, "Price"]}
          />
          <Area type="monotone" dataKey="price" stroke="url(#priceGrad)" strokeWidth={2.5} fill="url(#areaGrad)" dot={false} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
