import { NavLink } from "react-router";
import {
  LayoutDashboard, Wallet, Image, ArrowLeftRight, Receipt,
  Compass, Settings, BarChart2, History, ClipboardList, ShieldAlert,
} from "lucide-react";
import { toast } from "sonner";
import { useDS } from "../context/ThemeContext";
import { WSIndicator } from "./WSIndicator";

const mainNav = [
  { icon: LayoutDashboard, label: "Dashboard",    to: "/dashboard"      },
  { icon: Wallet,          label: "Wallet",        to: "/wallet"         },
  { icon: ArrowLeftRight,  label: "Exchange",      to: "/trade"          },
  { icon: ClipboardList,   label: "Open Orders",   to: "/open-orders"    },
  { icon: History,         label: "Trade History", to: "/trade-history"  },
  { icon: BarChart2,       label: "Analytics",     to: "/analytics"      },
  { icon: Compass,         label: "Discover",      to: "/discover"       },
  { icon: Image,           label: "NFTs",          to: "/nfts"           },
  { icon: Receipt,         label: "Invoices",      to: "/invoices"       },
  { icon: Settings,        label: "Settings",      to: "/settings"       },
];

export function Sidebar() {
  const ds = useDS();

  return (
    <aside
      className="flex flex-col w-[220px] min-h-screen shrink-0 transition-colors duration-300"
      style={{ background: ds.sidebar, boxShadow: ds.sidebarShadow }}
    >
      {/* Logo */}
      <div className="flex items-center gap-2 px-5 py-5">
        <div
          className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0"
          style={{ background: "linear-gradient(135deg, #1a1a2e 60%, #16213e)" }}
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <defs>
              <linearGradient id="sbLogoGrad" x1="0" y1="0" x2="24" y2="24" gradientUnits="userSpaceOnUse">
                <stop stopColor="#22c55e"/><stop offset="1" stopColor="#06b6d4"/>
              </linearGradient>
            </defs>
            <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"
              stroke="url(#sbLogoGrad)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
        <div className="leading-tight">
          <p className="text-xs font-bold tracking-widest" style={{ color: ds.textPrimary }}>CRYPTO</p>
          <p className="text-xs font-bold tracking-widest" style={{ color: ds.textPrimary }}>CRACK</p>
        </div>
      </div>

      {/* WS status */}
      <div className="px-4 mb-3">
        <WSIndicator />
      </div>

      {/* Main nav */}
      <nav className="flex flex-col gap-0.5 px-3 flex-1 overflow-y-auto">
        {mainNav.map(({ icon: Icon, label, to }) => (
          <NavLink
            key={label}
            to={to}
            className="flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all"
            style={({ isActive }) =>
              isActive
                ? { background: "linear-gradient(90deg, #22c55e, #06b6d4)", color: "white" }
                : { color: ds.navInactive }
            }
          >
            <Icon size={16} />
            <span className="text-sm">{label}</span>
          </NavLink>
        ))}

        {/* Admin link */}
        <div className="mt-2 pt-2" style={{ borderTop: `1px solid ${ds.divider}` }}>
          <NavLink
            to="/admin"
            className="flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all"
            style={({ isActive }) =>
              isActive
                ? { background: "linear-gradient(90deg, #f43f5e, #ef4444)", color: "white" }
                : { color: ds.navInactive }
            }
          >
            <ShieldAlert size={16} />
            <span className="text-sm">Admin</span>
          </NavLink>
        </div>
      </nav>

      {/* Footer links */}
      <div className="px-7 pb-3 pt-2 flex flex-col gap-1">
        <button
          onClick={() => toast.info("Support chat opening…")}
          className="text-xs text-left hover:opacity-80 transition-opacity"
          style={{ color: ds.textMuted }}
        >Support</button>
        <button
          onClick={() => window.open("https://docs.cryptocrack.io", "_blank")}
          className="text-xs text-left hover:opacity-80 transition-opacity"
          style={{ color: ds.textMuted }}
        >Documentation ↗</button>
      </div>

      {/* MetaMask widget */}
      <button
        onClick={() => toast.info("MetaMask integration coming soon!")}
        className="mx-3 mb-4 rounded-2xl p-3 text-white text-left hover:opacity-90 transition-opacity"
        style={{
          background: ds.isDark ? "#1a1a2e" : "#111827",
          border: ds.isDark ? "1px solid rgba(255,255,255,0.08)" : "none",
        }}
      >
        <div className="flex items-center gap-2">
          <span className="text-2xl">🦊</span>
          <div>
            <p className="text-xs font-semibold">Link MetaMask</p>
            <p className="text-xs" style={{ color: "#64748b" }}>better experience</p>
          </div>
        </div>
      </button>
    </aside>
  );
}
