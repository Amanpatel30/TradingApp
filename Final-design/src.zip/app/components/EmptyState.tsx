import { LucideIcon } from "lucide-react";
import { useDS } from "../context/ThemeContext";

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  description?: string;
  action?: { label: string; onClick: () => void };
}

export function EmptyState({ icon: Icon, title, description, action }: EmptyStateProps) {
  const ds = useDS();
  return (
    <div className="flex flex-col items-center justify-center py-16 px-8 text-center">
      <div
        className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4"
        style={{ background: ds.subBg }}
      >
        <Icon size={28} style={{ color: ds.textMuted }} />
      </div>
      <p className="text-base font-semibold mb-1.5" style={{ color: ds.textPrimary }}>
        {title}
      </p>
      {description && (
        <p className="text-sm max-w-xs leading-relaxed" style={{ color: ds.textMuted }}>
          {description}
        </p>
      )}
      {action && (
        <button
          onClick={action.onClick}
          className="mt-5 px-5 py-2.5 rounded-xl text-sm font-medium text-white hover:opacity-90 transition-opacity"
          style={{ background: "linear-gradient(90deg,#22c55e,#06b6d4)" }}
        >
          {action.label}
        </button>
      )}
    </div>
  );
}
