import { useState } from "react";
import { X } from "lucide-react";
import { toast } from "sonner";
import { useDS } from "../context/ThemeContext";

type Order = {
  id: string; symbol: string; side: "Buy" | "Sell"; type: "Limit" | "Market";
  quantity: number; price: number; filled: number; total: number; time: string; status: "Open" | "Partial";
};

const initialOrders: Order[] = [
  { id: "ORD-001", symbol: "BTC/USDT", side: "Buy",  type: "Limit",  quantity: 0.25,   price: 66900, filled: 0,    total: 16725,  time: "14:22:01", status: "Open"    },
  { id: "ORD-002", symbol: "ETH/USDT", side: "Sell", type: "Limit",  quantity: 2.50,   price: 3600,  filled: 0.80, total: 9000,   time: "13:58:44", status: "Partial" },
  { id: "ORD-003", symbol: "SOL/USDT", side: "Buy",  type: "Limit",  quantity: 15.00,  price: 172,   filled: 0,    total: 2580,   time: "13:40:10", status: "Open"    },
  { id: "ORD-004", symbol: "BNB/USDT", side: "Buy",  type: "Market", quantity: 3.00,   price: 590,   filled: 1.20, total: 1770,   time: "13:10:33", status: "Partial" },
  { id: "ORD-005", symbol: "LINK/USDT",side: "Sell", type: "Limit",  quantity: 100.00, price: 15.20, filled: 0,    total: 1520,   time: "12:55:07", status: "Open"    },
];

const historyOrders: Order[] = [
  { id: "ORD-098", symbol: "BTC/USDT", side: "Buy",  type: "Limit",  quantity: 0.50,  price: 62000, filled: 0.50, total: 31000,  time: "09:14:22", status: "Open" },
  { id: "ORD-097", symbol: "ETH/USDT", side: "Sell", type: "Market", quantity: 3.00,  price: 3450,  filled: 3.00, total: 10350,  time: "08:55:10", status: "Open" },
  { id: "ORD-096", symbol: "SOL/USDT", side: "Buy",  type: "Limit",  quantity: 20.00, price: 165,   filled: 20.00,total: 3300,   time: "08:22:44", status: "Open" },
];

export function OpenOrders() {
  const ds = useDS();
  const [orders, setOrders]       = useState<Order[]>(initialOrders);
  const [activeTab, setActiveTab] = useState<"open" | "history">("open");

  const cancelOrder = (id: string) => {
    setOrders((prev) => prev.filter((o) => o.id !== id));
    toast.success(`Order ${id} cancelled`);
  };

  const displayOrders = activeTab === "open" ? orders : historyOrders;
  const headers = ["Order ID","Symbol","Side","Type","Quantity","Price","Filled","Total","Time","Status","Action"];

  return (
    <div
      className="rounded-2xl overflow-hidden transition-colors duration-300"
      style={{ background: ds.card, boxShadow: ds.cardShadow }}
    >
      {/* Tabs */}
      <div className="flex items-center px-5" style={{ borderBottom: `1px solid ${ds.divider}` }}>
        {(["open", "history"] as const).map((tab) => (
          <button key={tab} onClick={() => setActiveTab(tab)}
            className="py-4 px-2 mr-4 text-sm capitalize border-b-2 transition-colors"
            style={activeTab === tab
              ? { borderColor: "#06b6d4", color: "#06b6d4" }
              : { borderColor: "transparent", color: ds.textMuted }}>
            {tab === "open" ? `Open Orders (${orders.length})` : "Order History"}
          </button>
        ))}
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr style={{ background: ds.subBg }}>
              {headers.map((h) => (
                <th key={h} className="text-left text-xs font-medium px-4 py-3 whitespace-nowrap" style={{ color: ds.textMuted }}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {displayOrders.length === 0 ? (
              <tr>
                <td colSpan={11} className="text-center py-12 text-sm" style={{ color: ds.textMuted }}>No open orders</td>
              </tr>
            ) : (
              displayOrders.map((order) => (
                <tr key={order.id} className="transition-colors"
                  style={{ borderTop: `1px solid ${ds.divider}` }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = ds.hoverBg)}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                >
                  <td className="px-4 py-3 text-xs font-mono" style={{ color: ds.textMuted }}>{order.id}</td>
                  <td className="px-4 py-3 text-xs font-semibold" style={{ color: ds.textPrimary }}>{order.symbol}</td>
                  <td className="px-4 py-3">
                    <span className="text-xs font-semibold px-2 py-0.5 rounded-full"
                      style={order.side === "Buy"
                        ? { background: ds.isDark ? "rgba(34,197,94,0.15)"  : "#dcfce7", color: "#16a34a" }
                        : { background: ds.isDark ? "rgba(239,68,68,0.15)"  : "#fee2e2", color: "#dc2626" }}>
                      {order.side}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-xs" style={{ color: ds.textSecondary }}>{order.type}</td>
                  <td className="px-4 py-3 text-xs" style={{ color: ds.textSecondary }}>{order.quantity.toFixed(4)}</td>
                  <td className="px-4 py-3 text-xs" style={{ color: ds.textSecondary }}>${order.price.toLocaleString()}</td>
                  <td className="px-4 py-3">
                    <div className="flex flex-col gap-0.5">
                      <span className="text-xs" style={{ color: ds.textSecondary }}>{order.filled.toFixed(4)}</span>
                      <div className="w-14 h-1 rounded-full overflow-hidden" style={{ background: ds.subBg2 }}>
                        <div className="h-full rounded-full"
                          style={{ width: `${(order.filled / order.quantity) * 100}%`, background: "linear-gradient(90deg,#22c55e,#06b6d4)" }} />
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-xs" style={{ color: ds.textSecondary }}>${order.total.toLocaleString()}</td>
                  <td className="px-4 py-3 text-xs font-mono" style={{ color: ds.textMuted }}>{order.time}</td>
                  <td className="px-4 py-3">
                    <span className="text-xs px-2 py-0.5 rounded-full"
                      style={order.status === "Open"
                        ? { background: ds.isDark ? "rgba(59,130,246,0.15)" : "#eff6ff", color: "#3b82f6" }
                        : { background: ds.isDark ? "rgba(234,179,8,0.15)"  : "#fef9c3", color: "#ca8a04" }}>
                      {order.status}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    {activeTab === "open" ? (
                      <button onClick={() => cancelOrder(order.id)}
                        className="w-6 h-6 flex items-center justify-center rounded-full transition-colors"
                        style={{ background: ds.subBg, color: ds.textMuted }}
                        onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = ds.isDark ? "rgba(239,68,68,0.2)" : "#fee2e2"; (e.currentTarget as HTMLElement).style.color = "#ef4444"; }}
                        onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = ds.subBg; (e.currentTarget as HTMLElement).style.color = ds.textMuted; }}>
                        <X size={12} />
                      </button>
                    ) : (
                      <span className="text-xs" style={{ color: ds.textMuted }}>—</span>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
