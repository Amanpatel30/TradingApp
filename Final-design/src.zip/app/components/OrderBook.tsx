import { useDS } from "../context/ThemeContext";

const asks = [
  { price: "67,612.00", amount: "0.4821", total: "32,596.47" },
  { price: "67,590.00", amount: "0.2134", total: "14,419.81" },
  { price: "67,570.00", amount: "0.8923", total: "60,296.01" },
  { price: "67,545.00", amount: "0.1500", total: "10,131.75" },
  { price: "67,520.00", amount: "0.3342", total: "22,563.74" },
];
const bids = [
  { price: "67,482.50", amount: "0.5612", total: "37,892.42" },
  { price: "67,460.00", amount: "0.2890", total: "19,495.94" },
  { price: "67,440.00", amount: "1.1240", total: "75,806.56" },
  { price: "67,415.00", amount: "0.4100", total: "27,640.15" },
  { price: "67,390.00", amount: "0.7832", total: "52,778.75" },
];

export function OrderBook() {
  const ds = useDS();

  return (
    <div
      className="rounded-2xl p-5 transition-colors duration-300"
      style={{ background: ds.card, boxShadow: ds.cardShadow }}
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold" style={{ color: ds.textPrimary }}>Order Book</h3>
        <span className="text-xs" style={{ color: ds.textMuted }}>BTC/USDT</span>
      </div>

      <div className="grid grid-cols-3 text-xs mb-2 px-1" style={{ color: ds.textMuted }}>
        <span>Price (USDT)</span>
        <span className="text-center">Amount (BTC)</span>
        <span className="text-right">Total</span>
      </div>

      {/* Asks */}
      <div className="flex flex-col gap-0.5 mb-1">
        {asks.map((row, i) => (
          <div key={i}
            className="relative grid grid-cols-3 text-xs px-1 py-1 rounded-md overflow-hidden transition-colors cursor-pointer"
            onMouseEnter={(e) => (e.currentTarget.style.background = ds.isDark ? "rgba(239,68,68,0.08)" : "#fff5f5")}
            onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
          >
            <div
              className="absolute inset-y-0 right-0 rounded-md"
              style={{ width: `${30 + i * 12}%`, background: ds.isDark ? "rgba(239,68,68,0.08)" : "rgba(239,68,68,0.06)" }}
            />
            <span className="relative font-medium" style={{ color: "#ef4444" }}>{row.price}</span>
            <span className="relative text-center" style={{ color: ds.textSecondary }}>{row.amount}</span>
            <span className="relative text-right" style={{ color: ds.textMuted }}>{row.total}</span>
          </div>
        ))}
      </div>

      {/* Spread */}
      <div className="flex items-center gap-2 py-2 px-1">
        <span className="text-sm font-semibold" style={{ color: ds.textPrimary }}>$67,482.50</span>
        <span className="text-xs px-2 py-0.5 rounded-md" style={{ background: ds.subBg, color: ds.textMuted }}>
          Spread: $129.50 (0.19%)
        </span>
      </div>

      {/* Bids */}
      <div className="flex flex-col gap-0.5">
        {bids.map((row, i) => (
          <div key={i}
            className="relative grid grid-cols-3 text-xs px-1 py-1 rounded-md overflow-hidden transition-colors cursor-pointer"
            onMouseEnter={(e) => (e.currentTarget.style.background = ds.isDark ? "rgba(34,197,94,0.08)" : "#f0fdf4")}
            onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
          >
            <div
              className="absolute inset-y-0 right-0 rounded-md"
              style={{ width: `${50 - i * 8}%`, background: ds.isDark ? "rgba(34,197,94,0.08)" : "rgba(34,197,94,0.07)" }}
            />
            <span className="relative font-medium" style={{ color: "#22c55e" }}>{row.price}</span>
            <span className="relative text-center" style={{ color: ds.textSecondary }}>{row.amount}</span>
            <span className="relative text-right" style={{ color: ds.textMuted }}>{row.total}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
