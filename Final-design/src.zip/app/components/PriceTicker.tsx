import { TrendingUp, TrendingDown } from "lucide-react";
import { useDS } from "../context/ThemeContext";

const tickers = [
  { ticker: "BTC/USDT",  price: "67,482.50", change: "+2.34%", up: true  },
  { ticker: "ETH/USDT",  price: "3,521.80",  change: "-1.12%", up: false },
  { ticker: "SOL/USDT",  price: "178.42",    change: "+5.67%", up: true  },
  { ticker: "BNB/USDT",  price: "592.30",    change: "+0.88%", up: true  },
  { ticker: "LINK/USDT", price: "14.72",     change: "-2.45%", up: false },
];

export function PriceTicker() {
  const ds = useDS();
  return (
    <div
      className="rounded-2xl px-5 py-4 overflow-hidden transition-colors duration-300"
      style={{ background: ds.card, boxShadow: ds.cardShadow }}
    >
      <div className="flex items-center gap-8 overflow-x-auto">
        {tickers.map((t) => (
          <div key={t.ticker} className="flex items-center gap-3 shrink-0">
            <div>
              <p className="text-xs" style={{ color: ds.textMuted }}>{t.ticker}</p>
              <p className="text-sm font-semibold" style={{ color: ds.textPrimary }}>${t.price}</p>
            </div>
            <div
              className="flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-full"
              style={t.up
                ? { background: ds.isDark ? "rgba(34,197,94,0.15)"  : "#dcfce7", color: "#22c55e" }
                : { background: ds.isDark ? "rgba(239,68,68,0.15)"  : "#fee2e2", color: "#ef4444" }}
            >
              {t.up ? <TrendingUp size={10} /> : <TrendingDown size={10} />}
              {t.change}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
