import { useState } from "react";
import { Bell, Search, Sun, Moon, ShoppingBag, X, TrendingUp, AlertTriangle, ArrowDownLeft } from "lucide-react";
import { useNavigate } from "react-router";
import { useTheme, useDS } from "../context/ThemeContext";

const NOTIFS_INIT = [
  { id: 1, type: "trade",   title: "Buy Order Filled",  desc: "0.25 BTC bought at $66,900", time: "2m ago",  read: false },
  { id: 2, type: "alert",   title: "Price Alert",       desc: "ETH dropped below $3,500",   time: "14m ago", read: false },
  { id: 3, type: "deposit", title: "Deposit Received",  desc: "+$5,000 USDT credited",      time: "1h ago",  read: true  },
  { id: 4, type: "trade",   title: "Sell Order Filled", desc: "1.2 ETH sold at $3,600",     time: "3h ago",  read: true  },
];

interface PageHeaderProps { title: string; }

export function PageHeader({ title }: PageHeaderProps) {
  const navigate = useNavigate();
  const { isDark, toggleTheme } = useTheme();
  const ds = useDS();
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifs, setNotifs]       = useState(NOTIFS_INIT);

  const unread = notifs.filter((n) => !n.read).length;
  const markAllRead = () => setNotifs((p) => p.map((n) => ({ ...n, read: true })));

  return (
    <header className="flex items-center justify-between px-8 py-4 bg-transparent relative z-30 transition-colors duration-300">
      <h1 className="text-2xl font-semibold" style={{ color: ds.textPrimary }}>{title}</h1>

      {/* Search */}
      <div
        className="flex items-center gap-2 rounded-full px-4 py-2 w-72 transition-colors duration-300"
        style={{ background: ds.card, boxShadow: ds.cardShadow }}
      >
        <Search size={15} style={{ color: ds.textMuted }} />
        <input
          type="text"
          placeholder="Search"
          className="bg-transparent outline-none text-sm w-full"
          style={{ color: ds.textSecondary }}
        />
      </div>

      {/* Right icons */}
      <div className="flex items-center gap-4">

        {/* Bell */}
        <div className="relative">
          <button
            onClick={() => setNotifOpen((o) => !o)}
            className="relative transition-colors"
            style={{ color: ds.textMuted }}
          >
            <Bell size={20} />
            {unread > 0 && (
              <span
                className="absolute -top-1 -right-1 w-4 h-4 rounded-full flex items-center justify-center text-white"
                style={{ background: "linear-gradient(90deg,#22c55e,#06b6d4)", fontSize: "9px" }}
              >
                {unread}
              </span>
            )}
          </button>

          {notifOpen && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setNotifOpen(false)} />
              <div
                className="absolute right-0 top-9 w-80 rounded-2xl z-50 overflow-hidden transition-colors duration-300"
                style={{ background: ds.card, boxShadow: "0 8px 40px rgba(0,0,0,0.18)", border: `1px solid ${ds.border}` }}
              >
                <div className="flex items-center justify-between px-4 pt-4 pb-2" style={{ borderBottom: `1px solid ${ds.divider}` }}>
                  <p className="text-sm font-semibold" style={{ color: ds.textPrimary }}>Notifications</p>
                  <div className="flex items-center gap-2">
                    {unread > 0 && (
                      <button onClick={markAllRead} className="text-xs text-cyan-500 hover:text-cyan-400 transition-colors">
                        Mark all read
                      </button>
                    )}
                    <button onClick={() => setNotifOpen(false)} style={{ color: ds.textMuted }}>
                      <X size={14} />
                    </button>
                  </div>
                </div>

                <div className="divide-y max-h-72 overflow-auto" style={{ borderColor: ds.divider }}>
                  {notifs.map((n) => (
                    <div
                      key={n.id}
                      onClick={() => setNotifs((p) => p.map((x) => x.id === n.id ? { ...x, read: true } : x))}
                      className="flex items-start gap-3 px-4 py-3 cursor-pointer transition-colors"
                      style={{
                        background: n.read ? "transparent" : isDark ? "rgba(6,182,212,0.05)" : "rgba(6,182,212,0.02)",
                      }}
                      onMouseEnter={(e) => (e.currentTarget.style.background = ds.hoverBg)}
                      onMouseLeave={(e) => (e.currentTarget.style.background = n.read ? "transparent" : isDark ? "rgba(6,182,212,0.05)" : "rgba(6,182,212,0.02)")}
                    >
                      <div
                        className="w-7 h-7 rounded-full flex items-center justify-center shrink-0 mt-0.5"
                        style={{ background: n.type === "alert" ? (isDark ? "#2d2500" : "#fef9c3") : n.type === "deposit" ? (isDark ? "#0e1f3d" : "#dbeafe") : (isDark ? "#0a2a15" : "#dcfce7") }}
                      >
                        {n.type === "alert"   && <AlertTriangle size={12} style={{ color: "#ca8a04" }} />}
                        {n.type === "trade"   && <TrendingUp    size={12} style={{ color: "#16a34a" }} />}
                        {n.type === "deposit" && <ArrowDownLeft size={12} style={{ color: "#2563eb" }} />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <p className="text-xs font-medium" style={{ color: ds.textPrimary }}>{n.title}</p>
                          {!n.read && <span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: "#06b6d4" }} />}
                        </div>
                        <p className="text-xs" style={{ color: ds.textMuted }}>{n.desc}</p>
                        <p className="text-xs mt-0.5" style={{ color: ds.textMuted, opacity: 0.6 }}>{n.time}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="px-4 py-3" style={{ borderTop: `1px solid ${ds.divider}` }}>
                  <button
                    onClick={() => setNotifOpen(false)}
                    className="w-full text-xs text-center text-cyan-500 hover:text-cyan-400 transition-colors"
                  >
                    View all notifications →
                  </button>
                </div>
              </div>
            </>
          )}
        </div>

        {/* NFT bag */}
        <button
          onClick={() => navigate("/nfts")}
          className="transition-colors hover:opacity-80"
          style={{ color: ds.textMuted }}
          title="NFT Marketplace"
        >
          <ShoppingBag size={20} />
        </button>

        {/* ☀/🌙 Dark mode toggle */}
        <button
          onClick={toggleTheme}
          className="transition-all hover:opacity-80"
          style={{ color: isDark ? "#f59e0b" : "#6b7280" }}
          title={isDark ? "Switch to light mode" : "Switch to dark mode"}
        >
          {isDark ? <Moon size={20} /> : <Sun size={20} />}
        </button>

        {/* Avatar */}
        <button
          onClick={() => navigate("/settings")}
          className="w-9 h-9 rounded-full bg-gradient-to-br from-pink-300 to-purple-400 flex items-center justify-center text-white text-sm font-semibold hover:opacity-90 transition-opacity"
          title="Account settings"
        >
          EE
        </button>
      </div>
    </header>
  );
}
