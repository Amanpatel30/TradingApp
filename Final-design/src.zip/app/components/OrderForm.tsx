import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { toast } from "sonner";
import { useDS } from "../context/ThemeContext";

const symbols = [
  { ticker: "BTC",  name: "Bitcoin",      price: 67482.5, change: 2.34,  icon: "₿" },
  { ticker: "ETH",  name: "Ethereum",     price: 3521.8,  change: -1.12, icon: "Ξ" },
  { ticker: "SOL",  name: "Solana",       price: 178.42,  change: 5.67,  icon: "◎" },
  { ticker: "BNB",  name: "Binance Coin", price: 592.3,   change: 0.88,  icon: "B" },
  { ticker: "LINK", name: "Chainlink",    price: 14.72,   change: -2.45, icon: "⬡" },
  { ticker: "DOT",  name: "Polkadot",     price: 7.84,    change: 3.21,  icon: "●" },
];

export function OrderForm() {
  const ds = useDS();
  const [side, setSide]               = useState<"buy" | "sell">("buy");
  const [orderType, setOrderType]     = useState<"market" | "limit">("limit");
  const [selectedSymbol, setSelectedSymbol] = useState(symbols[0]);
  const [symbolOpen, setSymbolOpen]   = useState(false);
  const [quantity, setQuantity]       = useState("0.25");
  const [price, setPrice]             = useState("67482.50");
  const [total, setTotal]             = useState("16870.63");

  const handleQuantityChange = (val: string) => {
    setQuantity(val);
    const q = parseFloat(val) || 0;
    const p = parseFloat(price) || 0;
    setTotal((q * p).toFixed(2));
  };
  const handlePriceChange = (val: string) => {
    setPrice(val);
    const q = parseFloat(quantity) || 0;
    const p = parseFloat(val) || 0;
    setTotal((q * p).toFixed(2));
  };

  const changeColor = selectedSymbol.change >= 0 ? "#22c55e" : "#ef4444";

  const inputRow = {
    background: ds.inputBg,
    border: `1px solid ${ds.inputBorder}`,
    borderRadius: "12px",
    padding: "12px 16px",
    display: "flex",
    alignItems: "center",
    gap: "8px",
  };

  return (
    <div
      className="rounded-2xl p-5 transition-colors duration-300"
      style={{ background: ds.card, boxShadow: ds.cardShadow }}
    >
      <h3 className="text-sm mb-3" style={{ color: ds.textMuted }}>Place Order</h3>

      {/* Symbol Selector */}
      <div className="relative mb-4">
        <p className="text-xs mb-1" style={{ color: ds.textMuted }}>Symbol</p>
        <button
          className="w-full flex items-center justify-between rounded-xl px-4 py-3 transition-colors"
          style={{ background: ds.inputBg, border: `1px solid ${ds.inputBorder}` }}
          onClick={() => setSymbolOpen(!symbolOpen)}
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold"
              style={{ background: "linear-gradient(135deg, #f59e0b, #ef4444)" }}>
              {selectedSymbol.icon}
            </div>
            <div className="text-left">
              <p className="text-sm font-semibold" style={{ color: ds.textPrimary }}>{selectedSymbol.ticker}/USDT</p>
              <p className="text-xs" style={{ color: ds.textMuted }}>{selectedSymbol.name}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium" style={{ color: changeColor }}>
              {selectedSymbol.change >= 0 ? "+" : ""}{selectedSymbol.change}%
            </span>
            <ChevronDown size={16} style={{ color: ds.textMuted }} />
          </div>
        </button>

        {symbolOpen && (
          <div
            className="absolute top-full left-0 right-0 mt-1 rounded-xl z-20 overflow-hidden"
            style={{ background: ds.card, border: `1px solid ${ds.border}`, boxShadow: "0 8px 32px rgba(0,0,0,0.16)" }}
          >
            {symbols.map((sym) => (
              <button
                key={sym.ticker}
                className="w-full flex items-center justify-between px-4 py-3 transition-colors"
                style={{ color: ds.textPrimary }}
                onMouseEnter={(e) => (e.currentTarget.style.background = ds.hoverBg)}
                onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                onClick={() => {
                  setSelectedSymbol(sym);
                  setPrice(sym.price.toFixed(2));
                  setTotal((parseFloat(quantity) * sym.price).toFixed(2));
                  setSymbolOpen(false);
                }}
              >
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-bold"
                    style={{ background: "linear-gradient(135deg, #f59e0b, #ef4444)" }}>
                    {sym.icon}
                  </div>
                  <div className="text-left">
                    <p className="text-sm font-semibold" style={{ color: ds.textPrimary }}>{sym.ticker}</p>
                    <p className="text-xs" style={{ color: ds.textMuted }}>{sym.name}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm" style={{ color: ds.textSecondary }}>${sym.price.toLocaleString()}</p>
                  <p className="text-xs" style={{ color: sym.change >= 0 ? "#22c55e" : "#ef4444" }}>
                    {sym.change >= 0 ? "+" : ""}{sym.change}%
                  </p>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Buy / Sell Tabs */}
      <div className="flex rounded-xl p-1 mb-4" style={{ background: ds.subBg }}>
        {(["buy", "sell"] as const).map((s) => (
          <button key={s} onClick={() => setSide(s)}
            className="flex-1 py-2 rounded-lg text-sm font-medium transition-all capitalize"
            style={side === s
              ? s === "buy"
                ? { background: "linear-gradient(90deg,#22c55e,#06b6d4)", color: "white" }
                : { background: "linear-gradient(90deg,#f43f5e,#ef4444)", color: "white" }
              : { color: ds.textMuted }}>
            {s.charAt(0).toUpperCase() + s.slice(1)}
          </button>
        ))}
      </div>

      {/* Order Type */}
      <div className="mb-4">
        <p className="text-xs mb-1" style={{ color: ds.textMuted }}>Order Type</p>
        <div className="flex gap-2">
          {(["market", "limit"] as const).map((type) => (
            <button key={type} onClick={() => setOrderType(type)}
              className="flex-1 py-2 rounded-xl text-sm border transition-all capitalize"
              style={orderType === type
                ? { borderColor: "#06b6d4", color: "#06b6d4", background: ds.isDark ? "rgba(6,182,212,0.1)" : "#ecfeff" }
                : { borderColor: ds.border, color: ds.textMuted, background: "transparent" }}>
              {type.charAt(0).toUpperCase() + type.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Quantity */}
      <div className="mb-4">
        <p className="text-xs mb-1" style={{ color: ds.textMuted }}>Quantity</p>
        <div style={inputRow}>
          <input type="number" value={quantity} onChange={(e) => handleQuantityChange(e.target.value)}
            className="flex-1 bg-transparent outline-none text-sm" placeholder="0.00" step="0.001" min="0"
            style={{ color: ds.textPrimary }} />
          <span className="text-xs font-medium px-2 py-0.5 rounded-md" style={{ background: ds.subBg2, color: ds.textMuted }}>
            {selectedSymbol.ticker}
          </span>
        </div>
        <div className="flex gap-1.5 mt-2">
          {[25, 50, 75, 100].map((pct) => (
            <button key={pct} onClick={() => handleQuantityChange(((pct / 100) * 0.5).toFixed(4))}
              className="flex-1 text-xs py-1 rounded-lg transition-colors"
              style={{ background: ds.subBg, color: ds.textMuted }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = "rgba(6,182,212,0.12)"; (e.currentTarget as HTMLElement).style.color = "#06b6d4"; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = ds.subBg; (e.currentTarget as HTMLElement).style.color = ds.textMuted; }}>
              {pct}%
            </button>
          ))}
        </div>
      </div>

      {/* Price */}
      {orderType === "limit" && (
        <div className="mb-4">
          <p className="text-xs mb-1" style={{ color: ds.textMuted }}>Limit Price</p>
          <div style={inputRow}>
            <input type="number" value={price} onChange={(e) => handlePriceChange(e.target.value)}
              className="flex-1 bg-transparent outline-none text-sm" placeholder="0.00" step="0.01" min="0"
              style={{ color: ds.textPrimary }} />
            <span className="text-xs font-medium px-2 py-0.5 rounded-md" style={{ background: ds.subBg2, color: ds.textMuted }}>
              USDT
            </span>
          </div>
        </div>
      )}

      {/* Total */}
      <div className="mb-5">
        <p className="text-xs mb-1" style={{ color: ds.textMuted }}>Total</p>
        <div style={inputRow}>
          <span className="flex-1 text-sm" style={{ color: ds.textSecondary }}>
            ${parseFloat(total || "0").toLocaleString("en-US", { minimumFractionDigits: 2 })}
          </span>
          <span className="text-xs font-medium px-2 py-0.5 rounded-md" style={{ background: ds.subBg2, color: ds.textMuted }}>
            USDT
          </span>
        </div>
      </div>

      {/* Submit */}
      <button
        onClick={() => toast.success(`${side === "buy" ? "Buy" : "Sell"} order placed for ${quantity} ${selectedSymbol.ticker}`)}
        className="w-full py-3.5 rounded-xl text-sm font-semibold text-white transition-all hover:opacity-90 active:scale-[0.98]"
        style={side === "buy"
          ? { background: "linear-gradient(90deg, #22c55e, #06b6d4)" }
          : { background: "linear-gradient(90deg, #f43f5e, #ef4444)" }}>
        {side === "buy" ? `Buy ${selectedSymbol.ticker}` : `Sell ${selectedSymbol.ticker}`}
      </button>

      <p className="text-center text-xs mt-3" style={{ color: ds.textMuted }}>
        Fee: 0.10% · Available: $75,000 USDT
      </p>
    </div>
  );
}
