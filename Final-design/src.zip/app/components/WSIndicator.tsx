import { useState, useEffect } from "react";
import { useDS } from "../context/ThemeContext";

type Status = "connected" | "reconnecting" | "disconnected";

export function WSIndicator() {
  const ds = useDS();
  const [status, setStatus] = useState<Status>("connected");

  // Simulate occasional brief disconnects for realism
  useEffect(() => {
    const cycle = () => {
      const delay = 18000 + Math.random() * 40000;
      setTimeout(() => {
        setStatus("reconnecting");
        setTimeout(() => {
          setStatus("connected");
          cycle();
        }, 1800);
      }, delay);
    };
    cycle();
  }, []);

  const config: Record<Status, { dot: string; label: string; bg: string }> = {
    connected:    { dot: "#22c55e", label: "Live",         bg: ds.isDark ? "rgba(34,197,94,0.12)"  : "rgba(34,197,94,0.08)"  },
    reconnecting: { dot: "#f59e0b", label: "Reconnecting", bg: ds.isDark ? "rgba(245,158,11,0.12)" : "rgba(245,158,11,0.08)" },
    disconnected: { dot: "#ef4444", label: "Offline",      bg: ds.isDark ? "rgba(239,68,68,0.12)"  : "rgba(239,68,68,0.08)"  },
  };

  const { dot, label, bg } = config[status];

  return (
    <div
      className="flex items-center gap-1.5 px-2.5 py-1 rounded-full"
      style={{ background: bg }}
      title={`WebSocket: ${label}`}
    >
      <span
        className={status === "connected" ? "ws-pulse" : ""}
        style={{
          display: "block",
          width: 6,
          height: 6,
          borderRadius: "50%",
          background: dot,
          flexShrink: 0,
        }}
      />
      <span className="text-xs font-medium" style={{ color: dot }}>
        {label}
      </span>
    </div>
  );
}
