import { Outlet } from "react-router";
import { Sidebar } from "./components/Sidebar";
import { useDS } from "./context/ThemeContext";

export function AppLayout() {
  const ds = useDS();
  return (
    <div
      className="flex min-h-screen transition-colors duration-300"
      style={{ background: ds.pageBg }}
    >
      <Sidebar />
      <div className="flex flex-col flex-1 min-w-0">
        <Outlet />
      </div>
    </div>
  );
}
