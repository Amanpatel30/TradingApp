import { createBrowserRouter } from "react-router";
import { LoginPage }             from "./components/auth/LoginPage";
import { SignUpPage }            from "./components/auth/SignUpPage";
import { ForgotPasswordPage }    from "./components/auth/ForgotPasswordPage";
import { AppLayout }             from "./AppLayout";
import { TradingApp }            from "./TradingApp";
import { DashboardPage }         from "./pages/DashboardPage";
import { WalletPage }            from "./pages/WalletPage";
import { NFTsPage }              from "./pages/NFTsPage";
import { InvoicesPage }          from "./pages/InvoicesPage";
import { DiscoverPage }          from "./pages/DiscoverPage";
import { SettingsPage }          from "./pages/SettingsPage";
import { LandingPage }           from "./pages/LandingPage";
import { OpenOrdersPage }        from "./pages/OpenOrdersPage";
import { TradeHistoryPage }      from "./pages/TradeHistoryPage";
import { PortfolioDetailPage }   from "./pages/PortfolioDetailPage";
import { AnalyticsPage }         from "./pages/AnalyticsPage";
import { AdminPage }             from "./pages/AdminPage";

export const router = createBrowserRouter([
  /* ── Public ── */
  { path: "/",                element: <LandingPage />        },
  { path: "/login",           element: <LoginPage />          },
  { path: "/signup",          element: <SignUpPage />         },
  { path: "/forgot-password", element: <ForgotPasswordPage /> },

  /* ── App (sidebar layout) ── */
  {
    element: <AppLayout />,
    children: [
      { path: "/dashboard",      element: <DashboardPage />       },
      { path: "/wallet",         element: <WalletPage />          },
      { path: "/portfolio/:symbol", element: <PortfolioDetailPage /> },
      { path: "/nfts",           element: <NFTsPage />            },
      { path: "/trade",          element: <TradingApp />          },
      { path: "/open-orders",    element: <OpenOrdersPage />      },
      { path: "/trade-history",  element: <TradeHistoryPage />    },
      { path: "/analytics",      element: <AnalyticsPage />       },
      { path: "/invoices",       element: <InvoicesPage />        },
      { path: "/discover",       element: <DiscoverPage />        },
      { path: "/settings",       element: <SettingsPage />        },
      { path: "/admin",          element: <AdminPage />           },
    ],
  },
]);
