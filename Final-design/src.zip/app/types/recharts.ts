/** Shared prop types for recharts custom shape renderers */
export interface BarShapeProps {
  x: number;
  y: number;
  width: number;
  height: number;
  value: number;
  index?: number;
  [key: string]: unknown;
}
