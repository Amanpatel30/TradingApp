import { useState } from "react";
import { OrderForm } from "./components/OrderForm";
import { PriceTicker } from "./components/PriceTicker";
import { MiniChart } from "./components/MiniChart";
import { OrderBook } from "./components/OrderBook";
import { OpenOrders } from "./components/OpenOrders";
import { PageHeader } from "./components/PageHeader";

export function TradingApp() {
  const [tf, setTf] = useState("1D");

  return (
    <>
      <PageHeader title="Exchange" />
      <main className="flex-1 px-6 pb-8 overflow-auto">
        <div className="mb-5"><PriceTicker /></div>
        <div className="flex gap-5 items-start">
          <div className="w-72 shrink-0"><OrderForm /></div>
          <div className="flex flex-col gap-5 flex-1 min-w-0">
            <MiniChart tf={tf} setTf={setTf} />
            <OrderBook />
          </div>
        </div>
        <div className="mt-5"><OpenOrders /></div>
      </main>
    </>
  );
}